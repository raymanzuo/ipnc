#if !defined(__AS3372_CMOS_H_)
#define __AS3372_CMOS_H_

#include <stdio.h>
#include <unistd.h>		// usleep
#include <string.h>

#include "hi_comm_sns.h"
#include "hi_sns_ctrl.h"
#include "mpi_isp.h"

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */


/****************************************************************************
 * local variables															*
 ****************************************************************************/

static cmos_inttime_t cmos_inttime;
static cmos_gains_t cmos_gains;


static cmos_isp_default_t st_coms_isp_default = 
{
    // color correction matrix
	{	0x017d, 0x804c, 0x8030,		
		0x8035, 0x01da, 0x80a3,		
		0x002a, 0x807d, 0x0154
	},

	// black level for R, Gr, Gb, B channels
	{0x100,0x100,0x100,0x100},

    // calibration reference color temperature 
    5000,

    //WB gain at 5000K, must keep consistent with calibration color temperature 
	{0x1CD, 0x100, 0x100, 0x19D},

    // WB curve parameters, must keep consistent with reference color temperature.
	{662, -1134, -728, 171942, 0x80, -115130},

	// hist_thresh
	{0x10,0x40,0xc0,0xf0},
	
	0x00,	// iridix_balck
	0x1,	// rggb

	// gain
	0x8,	0xff,

	// iridix space, intensity, slope_max, white level
	0x02,	0x08,	0x80, 	0x8ff,
	
	0x1, 	// balance_fe
	0x80,	// ae compensation
	0x15, 	// sinter threshold

	0x1,        //0: use default profile table; 1: use calibrated profile lut, the setting for nr0 and nr1 must be correct.
	0,  
	1528  
};

static HI_U8 dgain_fine[0x81] =
{
	0x40, 0x41, 0x41, 0x42, 0x43, 0x43, 0x44, 0x45, //0x80
	0x46, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4b, 
	0x4c, 0x4d, 0x4e, 0x4e, 0x4f, 0x50, 0x51, 0x52, //0x90
	0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x59, 
	0x5b, 0x5b, 0x5d, 0x5d, 0x5f, 0x60, 0x61, 0x62, //0xa0
	0x63, 0x63, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a,
	0x6b, 0x6c, 0x6e, 0x6f, 0x70, 0x72, 0x73, 0x74, //0xb0
	0x75, 0x76, 0x78, 0x79, 0x7a, 0x7c, 0x7d, 0x7e,
	0x80, 0x81, 0x83, 0x84, 0x86, 0x87, 0x89, 0x8a, //0xc0
	0x8c, 0x8d, 0x8e, 0x90, 0x91, 0x93, 0x95, 0x97,
	0x98, 0x9a, 0x9b, 0x9d, 0x9f, 0xa1, 0xa2, 0xa4, //0xd0
	0xa6, 0xa8, 0xaa, 0xab, 0xad, 0xaf, 0xb1, 0xb3,
	0xb5, 0xb7, 0xb9, 0xbb, 0xbd, 0xbf, 0xc1, 0xc3, //0xe0
	0xc5, 0xc7, 0xc9, 0xcc, 0xce, 0xd0, 0xd2, 0xd4,
	0xd7, 0xd9, 0xdc, 0xde, 0xe0, 0xe3, 0xe5, 0xe8, //0xf0
	0xeb, 0xed, 0xef, 0xf2, 0xf4, 0xf8, 0xfa, 0xfc,
	0xff,
};

/*
 * This function initialises an instance of cmos_inttime_t.
 */
static __inline cmos_inttime_const_ptr_t cmos_inttime_initialize()
{
	cmos_inttime.full_lines_std_30fps = 1125;
	cmos_inttime.full_lines_std_25fps = 1350;
	
	cmos_inttime.full_lines_std = 1125;
	cmos_inttime.full_lines = 1125;
	cmos_inttime.max_lines_target = 1123;

	cmos_inttime.full_lines_limit = 65535;
	cmos_inttime.min_lines_target = 1;
	cmos_inttime.vblanking_lines = 1125;

	cmos_inttime.exposure_ashort = 0;

	cmos_inttime.lines_per_500ms = cmos_inttime.full_lines_std*60/2; 
	cmos_inttime.flicker_freq = 0;//60*256;//50*256;

	return &cmos_inttime;
}

/*
 * This function applies the new integration time to the ISP registers.
 */
static __inline void cmos_inttime_update(cmos_inttime_ptr_t p_inttime) 
{
	
	HI_U32 eshort = p_inttime->exposure_ashort;
	HI_U32 exp_frames = eshort / p_inttime->full_lines_std;

	eshort = eshort - exp_frames * p_inttime->full_lines_std;
	eshort = p_inttime->full_lines_std - eshort; 
	   
	sensor_write_register(0x00A1, (eshort&0xffff));
	sensor_write_register(0x00A2, (0x2 + ((eshort&0x10000) >> 16) ));  //0x2 is the reserved bits value 
	sensor_write_register(0x00A5, exp_frames); 

}

/*
 * This function applies the new vert blanking porch to the ISP registers.
 */
static __inline void cmos_vblanking_update(cmos_inttime_const_ptr_t p_inttime)
{
	return;
	int full_lines_lo16 = p_inttime->full_lines & 0xffff;
	int full_lines_hi16= (p_inttime->full_lines >> 16) & 0x1;

	sensor_write_register(0x1A0, full_lines_lo16);
	sensor_write_register(0x1A1, full_lines_hi16);
	sensor_write_register(0x1A3, full_lines_lo16);
	sensor_write_register(0x1A4, full_lines_hi16);
	sensor_write_register(0x1A7, full_lines_lo16);
	sensor_write_register(0x1A8, full_lines_hi16);
}

static __inline HI_U16 vblanking_calculate(
		cmos_inttime_ptr_t p_inttime)
{
	if (p_inttime->exposure_ashort >= p_inttime->full_lines - 3)
	{
		p_inttime->exposure_ashort = p_inttime->full_lines - 3;
	}

	p_inttime->vblanking_lines = p_inttime->full_lines - p_inttime->full_lines_std;

	return p_inttime->exposure_ashort;
}

/* Set fps base */
static __inline void cmos_fps_set(
		cmos_inttime_ptr_t p_inttime,
		const HI_U8 fps
		)
{
}

/*
 * This function initialises an instance of cmos_gains_t.
 */
static __inline cmos_gains_ptr_t cmos_gains_initialize()
{
	cmos_gains.max_again = 0x8;
	cmos_gains.max_dgain = 0xff;

	cmos_gains.again_shift = 0;
	cmos_gains.dgain_shift = 6;
	cmos_gains.dgain_fine = 0;

	return &cmos_gains;
}

static __inline HI_U32 cmos_get_ISO(cmos_gains_ptr_t p_gains)
{
	HI_U32 _again = p_gains->again == 0 ? 1 : p_gains->again;
	HI_U32 _dgain = p_gains->dgain == 0 ? 1 : p_gains->dgain;

	p_gains->iso =  ((_again * _dgain * 100) >> (p_gains->again_shift + p_gains->dgain_shift));

	return p_gains->iso;
}

/*
 * This function applies the digital gain
 * input and output offset and correction
 */
static __inline void cmos_gains_update(cmos_gains_const_ptr_t p_gains)
{
	switch (p_gains->again_db)
    {
    case 0:

        //r_colgsw = 0dB, r_a_gain = 0dB
        sensor_write_register(0x20, 0x0080);
        break;
    case 6:

        //r_colgsw = 6dB, r_a_gain = 0dB
        sensor_write_register(0x20, 0x8080);
        break;
    case 12:

        //r_colgsw = 12dB, r_a_gain = 0dB
        sensor_write_register(0x20, 0xC080);
        break;
    case 18:

        //r_colgsw = 12dB, r_a_gain = 6dB
        sensor_write_register(0x20, 0xC0C0);
        break;
    default:
        break;
    }

    {
        int i;
        HI_U16 data16 = p_gains->dgain;

        for (i = 0; i < 0x80; i++)
        {
            if (data16 >= dgain_fine[i] && data16 <= dgain_fine[i+1])  
            {
                break;
            }    
        } 
        data16 = 0x80 + i;

        sensor_write_register(0x21, data16);
    }
}

/*
 * This function applies the new gains to the ISP registers.
 */
static __inline HI_U16 cmos_gains_update2(cmos_gains_const_ptr_t p_gains)
{
	return 0;
}

static __inline HI_U32 analog_gain_from_exposure_calculate(
		cmos_gains_ptr_t p_gains,
		HI_U32 exposure,
		HI_U32 exposure_max,
		HI_U32 exposure_shift)
{
	int _i;
	HI_U32 _again = (1 << p_gains->again_shift);
	HI_U32 _again_db = 0;
	HI_U32 exposure1;
	int shft = 0;
	
	// normalize
	while (exposure > (1<<22))
	{
		exposure >>= 1;
		exposure_max >>= 1;
		++shft;
	}

	for(_i = 0; _i <= 2; _i++)
	{
		exposure1 = (exposure>>1);
		if((exposure1 < exposure_max) || (_again >  p_gains->max_again_target))
			break;

		_again *= 2;
		_again_db += 6;
		exposure = exposure1;
	}
	
	p_gains->again = _again;
	p_gains->again_db = _again_db;
	
	return (exposure << shft);
}

//�Ƿ���Ҫ����������������
static HI_U32 mn34041_dgains_to_db_convert(HI_U32 data, HI_U32 shift_in)
{
	//HI_U32 _i;
	HI_U32 _res = 0;
	if(0 == data)
		return _res;

	for(;;)
	{
		data = (data*913 + (1<<9)) >> 10;
		if(data < (1<<shift_in))
			break;
		++_res;
	}
	return _res;
}


static __inline HI_U32 digital_gain_from_exposure_calculate(
		cmos_gains_ptr_t p_gains,
		HI_U32 exposure,
		HI_U32 exposure_max,
		HI_U32 exposure_shift)
{
	HI_U32 _dgain = (1 << p_gains->dgain_shift);
    //HI_U32 _dgain_db = 0;
	
    int shft = 0;

    while (exposure > (1 << 20))
    {
        exposure     >>= 1;
        exposure_max >>= 1;
        ++shft;
    }

    if (exposure > exposure_max)
    {
        //when setting manual exposure line, exposure_max>>shift should not be 0.
        exposure_max = DIV_0_TO_1(exposure_max);
        _dgain   = (exposure * _dgain) / exposure_max;
        exposure = exposure_max;
    }

    if (_dgain >= p_gains->max_dgain_target)
    {
        _dgain = p_gains->max_dgain_target;
    }

    p_gains->dgain = _dgain;
    p_gains->dgain_db = mn34041_dgains_to_db_convert(_dgain, p_gains->dgain_shift);
    p_gains->dgain_fine = 0;

    cmos_get_ISO(p_gains);

    return exposure << shft;
}

static void setup_sensor(int isp_mode)
{
	if(0 == isp_mode) /* setup for ISP 'normal mode' */
	{
		sensor_write_register(0x00A5,0x0000);
	}
	else if(1 == isp_mode) /* setup for ISP pixel calibration mode */
	{
        //set the gain to 0
		sensor_write_register(0x0020,0x0080);
		sensor_write_register(0x0021,0x0080);
		sensor_write_register(0x00A1,0x0400);
		sensor_write_register(0x00A2,0x0002);
		sensor_write_register(0x00A5,0x0005);
	}
}

static HI_U8 cmos_get_analog_gain(cmos_gains_ptr_t p_gains)
{
    return p_gains->again_db;
}

static HI_U8 cmos_get_digital_gain(cmos_gains_ptr_t p_gains)
{ 
	return p_gains->dgain_db;
}
/*
static HI_U8 cmos_get_digital_fine_gain(cmos_gains_ptr_t cmos_gains)
{
    return cmos_gains->dgain_fine;
}
*/
static HI_U32 cmos_get_isp_default(cmos_isp_default_ptr_t p_coms_isp_default)
{
	if (NULL == p_coms_isp_default)
	{
	    printf("null pointer when get isp default value!\n");
	    return -1;
	}
    memcpy(p_coms_isp_default, &st_coms_isp_default, sizeof(cmos_isp_default_t));
    return 0;
}

/****************************************************************************
 * callback structure                                                       *
 ****************************************************************************/

SENSOR_EXP_FUNC_S stSensorExpFuncs = 
{
    .pfn_cmos_inttime_initialize = cmos_inttime_initialize,
    .pfn_cmos_inttime_update = cmos_inttime_update,

    .pfn_cmos_gains_initialize = cmos_gains_initialize,
    .pfn_cmos_gains_update = cmos_gains_update,
    .pfn_cmos_gains_update2 = NULL,
    .pfn_analog_gain_from_exposure_calculate = analog_gain_from_exposure_calculate,
    .pfn_digital_gain_from_exposure_calculate = digital_gain_from_exposure_calculate,

    .pfn_cmos_fps_set = cmos_fps_set,
    .pfn_vblanking_calculate = vblanking_calculate,
    .pfn_cmos_vblanking_front_update = cmos_vblanking_update,

    .pfn_setup_sensor = setup_sensor,

    .pfn_cmos_get_analog_gain = cmos_get_analog_gain,
    .pfn_cmos_get_digital_gain = cmos_get_digital_gain,
    .pfn_cmos_get_digital_fine_gain = NULL,
    .pfn_cmos_get_iso = cmos_get_ISO,

    .pfn_cmos_get_isp_default = cmos_get_isp_default,
    .pfn_cmos_get_isp_special_alg = NULL,
	
};

int sensor_register_callback(void)
{
	int ret;
	ret = HI_MPI_ISP_SensorRegCallBack(&stSensorExpFuncs);
	if (ret)
	{
	    printf("sensor register callback function failed!\n");
	    return ret;
	}
	
	return 0;
}



#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */


#endif // __AS3372_CMOS_H_
