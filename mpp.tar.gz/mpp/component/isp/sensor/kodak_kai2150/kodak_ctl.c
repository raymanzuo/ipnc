#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include "hi_type.h"

#define  FPGA_BASE_ADDR        0x30100000
#define  FPGA_CFG_ADDR         0x40210000
#define  XIO2001_CFG_ADDR      0x40100000


#define  FPGA_READ32(a)        (*(volatile HI_U32*)(a+FPGA_virtual_addr))
#define  FPGA_WRITE32(a,b)     (*(volatile HI_U32*)(a+FPGA_virtual_addr)=(b))

#define  CHANNEL_SELECT        0x3C
#define  DAC_SELECT	       0x2C
#define  DAC_CLR_N_ADD	       0x30
#define  ESD_EN_ADD	       0x34
#define  OSC_EN_ADD	       0x38

#define  DAC_RESET         0x30
#define  ESD_ENABLE        0x34
#define  OSC_ENABLE        0x38

#define  VAB		   7.8


typedef struct{
    int   data    ;
    int   address ;
    int   command ;
    int   status  ;
}PORT_INFO ;


PORT_INFO   AFE_channel[2] = {
    { 0x08 , 0x0C , 0x10 , 0x14 },
    { 0x48 , 0x4C , 0x50 , 0x54 },
};
PORT_INFO  DAC_channel = { 0x18 , 0x1C , 0x20 , 0x24 } ;

//FPGA�������ַ
char *  FPGA_virtual_addr = NULL ;
int     memFd = -1 ;


void LTC1665_write( int addr , int data )
{
    PORT_INFO * port ;
    HI_U32 busy ;
    HI_U32 i;
    HI_U32 ltc1665_busy;
    HI_U32 ad9920a_a_busy;
    HI_U32 ad9920a_b_busy;
    
    port = &DAC_channel ;
    
    //����Ƿ����  
     for( i=0 ; i<1000; i++) {

    	ad9920a_a_busy = FPGA_READ32( AFE_channel[0].status ) ;
    	ad9920a_b_busy = FPGA_READ32( AFE_channel[1].status ) ;
    	ltc1665_busy = FPGA_READ32( DAC_channel.status ) ;
    	busy =(ad9920a_a_busy | ad9920a_b_busy | ltc1665_busy) & 0x01;
	
    	if(busy == 0 ) {
		FPGA_WRITE32( DAC_SELECT, 0x01 ) ;
		FPGA_WRITE32( port->address , addr ) ;
    		FPGA_WRITE32( port->data    , data ) ;    	
    		FPGA_WRITE32( port->command , 0x01 ) ;   //Start SPI command 
		break;
	}
	usleep( 1000 );
     }
        
   
}

void AD9920_write( int ch , int addr, int data)
{
    PORT_INFO * port ;
    HI_U32 busy ;
    HI_U32 i;
    HI_U32 ltc1665_busy;
    HI_U32 ad9920a_a_busy;
    HI_U32 ad9920a_b_busy;
    
    if( ch > 1 )
        return ;
    
    port = &AFE_channel[ch] ;
    
    //����Ƿ����   
 
    for( i=0 ; i<1000; i++) {

    	ad9920a_a_busy = FPGA_READ32( AFE_channel[0].status ) ;
    	ad9920a_b_busy = FPGA_READ32( AFE_channel[1].status ) ;
    	ltc1665_busy = FPGA_READ32( DAC_channel.status ) ;
    	busy =(ad9920a_a_busy | ad9920a_b_busy | ltc1665_busy) & 0x01;
	
    	if(busy == 0 ) {
       		FPGA_WRITE32( CHANNEL_SELECT, ch ) ;
		FPGA_WRITE32( DAC_SELECT, 0x0 ) ;
		FPGA_WRITE32( port->address , addr ) ;
    		FPGA_WRITE32( port->data    , data ) ;    	
    		FPGA_WRITE32( port->command , 0x01 ) ;   //Start SPI command 
		break;
	}
	usleep( 1000 );
     }
      
}

int sensor_read_register(int addr)
{        
	return -1 ;
}

int sensor_write_register(int addr, int data)
{
	AD9920_write(0, addr, data );
	return 0;
}

////////////////////////////////////////////////////////////////////
//����CCD Sensor
//
void ccd_sensor_init( )
{
    
    //1. Initialize Control Signals
    FPGA_WRITE32( DAC_RESET , 0 ) ; //reset it
    FPGA_WRITE32( ESD_ENABLE, 0 ) ; //disable
    FPGA_WRITE32( OSC_ENABLE, 0 ) ;
    
    usleep(1000);
    //2. Power up ESD and VAB
    FPGA_WRITE32( ESD_ENABLE, 1 ) ; //Enable  esd
    FPGA_WRITE32( DAC_RESET , 1 ) ; //Enable  vab
    LTC1665_write( 0x05, 0xda ) ; //VAB=7.8;
    LTC1665_write( 0x06, 0xFA);  // VoutF = VAB_EN = 6;
    
    //3.reset AFE
    AD9920_write( 0 , 0x10, 0x01);//reset AFE;
    
    //4.Power On prepare
    AD9920_write( 0 , 0xC3,0xA000);  // manually force GPO8/GPO6 to Low
    FPGA_WRITE32( OSC_ENABLE, 1);//OSC_EN = 1;
    AD9920_write( 0 , 0xC3,0xA000);  // manually force GPO8/GPO6 to Low
    AD9920_write( 0 , 0x7A,0x0ffff00); //make sure that VDR_EN is Low
    
    //4.1 SET VCLK SLOPE 
    FPGA_WRITE32( DAC_CLR_N_ADD, 0x01);   
    LTC1665_write(0x03,0x64);  //VoutC = VSlope_N = 3;
    LTC1665_write(0x04,0xA1);  //VoutD = VSlope_P = 4;
    
    //4.2 Set Reset Rails
    FPGA_WRITE32( DAC_CLR_N_ADD, 0x01);   
    LTC1665_write(0x01,0xB4);  //VoutA = Set_RH = 1;
    LTC1665_write(0x02,0x30);  //VoutB = Set_RL = 2;
    
    //4.3 Set HBIAS
    FPGA_WRITE32( DAC_CLR_N_ADD, 0x01 );
    LTC1665_write(0x08,0xFA);  //VoutH = HCLKBias = 8;
    
    //5. Init AFE_B;    
    AD9920_write( 1 , 0x12,0x0);  //RSTB_SYNC = SYNC
    AD9920_write( 1 , 0x11,0x0);  //make all output inactive
    AD9920_write( 1 , 0x10,0x01); //software reset
    
    //6. AFE_a initialization
    AD9920_write( 0 , 0x12,0x0);   //RSTB_SYNC = SYNC
    AD9920_write( 0 , 0x20,0x01);  //master mode = MASTER
    AD9920_write( 0 , 0x21,0x00);  //VDHD polarity = High
    
    ///////////A ���� B/////////////
    //7.AFE COMMON COMMANDS
    //7.1 Load Memory
    AD9920_write( 0 , 0x28,0x62);   //VSEQNUM<<5|VPATNUM
    
    //7.2 First Pattern
    AD9920_write( 0 , 0x400,0x03FFFFFF);  //XV1
    AD9920_write( 0 , 0x401,0x03FFFFFF);
    
    AD9920_write( 0 , 0x402,0x013C058);   //XV2
    AD9920_write( 0 , 0x403,0x03FFFFFF);
    
    AD9920_write( 0 , 0x404,0x013C058);  //XV3
    AD9920_write( 0 , 0x405,0x03FFFFFF);
    
    AD9920_write( 0 , 0x406,0x017806C);  //XV4
    AD9920_write( 0 , 0x407,0x03FFFFFF);
    
    AD9920_write( 0 , 0x408,0x03FFFFFF);  //XV5
    AD9920_write( 0 , 0x409,0x03FFFFFF);
    
    AD9920_write( 0 , 0x40A,0x03FFFFFF);  //XV6
    AD9920_write( 0 , 0x40B,0x03FFFFFF);
    
    AD9920_write( 0 , 0x40C,0x03FFFFFF);  //XV7
    AD9920_write( 0 , 0x40D,0x03FFFFFF);
    
    AD9920_write( 0 , 0x40E,0x013C062);  //XV8
    AD9920_write( 0 , 0x40F,0x03FFFFFF);
    
    AD9920_write( 0 , 0x410,0x03FFFFFF);  //XV9
    AD9920_write( 0 , 0x411,0x03FFFFFF);
    
    AD9920_write( 0 , 0x412,0x013C062);  //XV10
    AD9920_write( 0 , 0x413,0x03FFFFFF);
    
    AD9920_write( 0 , 0x414,0x03FFFFFF);  //XV11
    AD9920_write( 0 , 0x415,0x03FFFFFF);
    
    AD9920_write( 0 , 0x416,0x017806C);  //XV12
    AD9920_write( 0 , 0x417,0x03FFFFFF);
    
    AD9920_write( 0 , 0x418,0x164076);  //XV13
    AD9920_write( 0 , 0x419,0x03FFFFFF);
    
    AD9920_write( 0 , 0x41A,0x03FFFFFF);  //XV14
    AD9920_write( 0 , 0x41B,0x03FFFFFF);
    
    AD9920_write( 0 , 0x41C,0x03FFFFFF);  //XV15
    AD9920_write( 0 , 0x41D,0x03FFFFFF);
    
    AD9920_write( 0 , 0x41E,0x03FFFFFF);  //XV16
    AD9920_write( 0 , 0x41F,0x03FFFFFF);
    
    AD9920_write( 0 , 0x420,0x03FFFFFF);  //XV17
    AD9920_write( 0 , 0x421,0x03FFFFFF);
    
    AD9920_write( 0 , 0x422,0x03FFFFFF);  //XV18
    AD9920_write( 0 , 0x423,0x03FFFFFF);
    
    AD9920_write( 0 , 0x424,0x03FFFFFF);  //XV19
    AD9920_write( 0 , 0x425,0x03FFFFFF);
    
    AD9920_write( 0 , 0x426,0x03FFFFFF);  //XV20
    AD9920_write( 0 , 0x427,0x03FFFFFF);
    
    AD9920_write( 0 , 0x428,0x03FFFFFF);  //XV21
    AD9920_write( 0 , 0x429,0x03FFFFFF);
    
    AD9920_write( 0 , 0x42A,0x03FFFFFF);  //XV22
    AD9920_write( 0 , 0x42B,0x03FFFFFF);
    
    AD9920_write( 0 , 0x42C,0x164076);  //XV23
    AD9920_write( 0 , 0x42D,0x03FFFFFF);
    
    AD9920_write( 0 , 0x42E,0x03FFFFFF);  //XV24
    AD9920_write( 0 , 0x42F,0x03FFFFFF);
    
    //7.3 Second Pattern
    AD9920_write( 0 , 0x430,0x03FFFFFF);  //XV1
    AD9920_write( 0 , 0x431,0x03FFFFFF);  //XV1
    
    AD9920_write( 0 , 0x432,0x4A4082);    //XV2
    AD9920_write( 0 , 0x433,0x03FFFFFF);  //XV2
    
    AD9920_write( 0 , 0x434,0x4A4082);    //XV3
    AD9920_write( 0 , 0x435,0x03FFFFFF);  //XV3
    
    AD9920_write( 0 , 0x436,0x294096);  //XV4
    AD9920_write( 0 , 0x437,0x4C8192);  //XV4
    
    AD9920_write( 0 , 0x438,0x03FFFFFF);  //XV5
    AD9920_write( 0 , 0x439,0x03FFFFFF);  //XV5
    
    AD9920_write( 0 , 0x43A,0x03FFFFFF);  //XV6
    AD9920_write( 0 , 0x43B,0x03FFFFFF);  //XV6
    
    AD9920_write( 0 , 0x43C,0x03FFFFFF);  //XV7
    AD9920_write( 0 , 0x43D,0x03FFFFFF);  //XV7
    
    AD9920_write( 0 , 0x43E,0x49008C);    //XV8
    AD9920_write( 0 , 0x43F,0x03FFFFFF);  //XV8
    
    AD9920_write( 0 , 0x440,0x03FFFFFF);  //XV9
    AD9920_write( 0 , 0x441,0x03FFFFFF);  //XV9
    
    AD9920_write( 0 , 0x442,0x49008C);    //XV10
    AD9920_write( 0 , 0x443,0x03FFFFFF);  //XV10
    
    AD9920_write( 0 , 0x444,0x03FFFFFF);  //XV11
    AD9920_write( 0 , 0x445,0x03FFFFFF);  //XV11
    
    AD9920_write( 0 , 0x446,0x294096);  //XV12
    AD9920_write( 0 , 0x447,0x4C8192);  //XV12
    
    AD9920_write( 0 , 0x448,0x4B40A0);  //XV13
    AD9920_write( 0 , 0x449,0x03FFFFFF);  //XV13
    
    AD9920_write( 0 , 0x44A,0x03FFFFFF);  //XV14
    AD9920_write( 0 , 0x44B,0x03FFFFFF);  //XV14
    
    AD9920_write( 0 , 0x44C,0x03FFFFFF);  //XV15
    AD9920_write( 0 , 0x44D,0x03FFFFFF);  //XV15
    
    AD9920_write( 0 , 0x44E,0x31814A);  //XV16
    AD9920_write( 0 , 0x44F,0x03FFFFFF);  //XV16
    
    AD9920_write( 0 , 0x450,0x31814A);  //XV17
    AD9920_write( 0 , 0x451,0x03FFFFFF);  //XV17
    
    AD9920_write( 0 , 0x452,0x31814A);  //XV18
    AD9920_write( 0 , 0x453,0x03FFFFFF);  //XV18
    
    AD9920_write( 0 , 0x454,0x03FFFFFF);  //XV19
    AD9920_write( 0 , 0x455,0x03FFFFFF);  //XV19
    
    AD9920_write( 0 , 0x456,0x31814A);  //XV20
    AD9920_write( 0 , 0x457,0x03FFFFFF);  //XV20
    
    AD9920_write( 0 , 0x458,0x03FFFFFF);  //XV21
    AD9920_write( 0 , 0x459,0x03FFFFFF);  //XV21
    
    AD9920_write( 0 , 0x45A,0x03FFFFFF);  //XV22
    AD9920_write( 0 , 0x45B,0x03FFFFFF);  //XV22
    
    AD9920_write( 0 , 0x45C,0x04b40a0);  //XV23
    AD9920_write( 0 , 0x45D,0x03FFFFFF);  //XV23
    
    AD9920_write( 0 , 0x45E,0x03FFFFFF);  //XV24
    AD9920_write( 0 , 0x45F,0x03FFFFFF);  //XV24
    
    //7.4 Load Sequence 1
    AD9920_write( 0 , 0x460,0x00F0003);  //VSEQ_00
    AD9920_write( 0 , 0x461,0x898);  //VSEQ_01
    AD9920_write( 0 , 0x462,0x898);  //VSEQ_02
    AD9920_write( 0 , 0x463,0x0);  //VSEQ_03
    AD9920_write( 0 , 0x464,0x1B40DA);  //VSEQ_04
    AD9920_write( 0 , 0x465,0x1B40DA);  //VSEQ_05
    AD9920_write( 0 , 0x466,0x3F880E);  //VSEQ_06
    AD9920_write( 0 , 0x467,0x0);  //VSEQ_07
    AD9920_write( 0 , 0x468,0x0);  //VSEQ_08
    AD9920_write( 0 , 0x469,0x0);  //VSEQ_09
    AD9920_write( 0 , 0x46A,0x1C8000);  //VSEQ_0A
    AD9920_write( 0 , 0x46B,0x1);  //VSEQ_0B
    AD9920_write( 0 , 0x46C,0x0);  //VSEQ_0C
    AD9920_write( 0 , 0x46D,0x1C9FFF);  //VSEQ_0D
    AD9920_write( 0 , 0x46E,0x0);  //VSEQ_0E
    AD9920_write( 0 , 0x46F,0x1C9FFF);  //VSEQ_0F
    AD9920_write( 0 , 0x470,0x0);  //VSEQ_10
    AD9920_write( 0 , 0x471,0x1C9FFF);  //VSEQ_11
    AD9920_write( 0 , 0x472,0x0);  //VSEQ_12
    AD9920_write( 0 , 0x473,0x7FFEFFF);  //VSEQ_13
    AD9920_write( 0 , 0x474,0x0);  //VSEQ_14
    AD9920_write( 0 , 0x475,0x0);  //VSEQ_15
    AD9920_write( 0 , 0x476,0x0);  //VSEQ_16
    AD9920_write( 0 , 0x477,0x1D8050);  //VSEQ_17
    AD9920_write( 0 , 0x478,0x020209C);  //VSEQ_18
    AD9920_write( 0 , 0x479,0x1D8050);  //VSEQ_19
    AD9920_write( 0 , 0x47A,0x3FFFFFF);  //VSEQ_1A
    AD9920_write( 0 , 0x47B,0x3FFFFFF);  //VSEQ_1B
    AD9920_write( 0 , 0x47C,0x1D8050);  //VSEQ_1C
    AD9920_write( 0 , 0x47D,0x3FFFFFF);  //VSEQ_1D
    AD9920_write( 0 , 0x47E,0x3FFFFFF);  //VSEQ_1E
    AD9920_write( 0 , 0x47F,0x3FFFFFF);  //VSEQ_1F
    AD9920_write( 0 , 0x480,0x1FFF);  //VSEQ_20
    AD9920_write( 0 , 0x481,0x0);  //VSEQ_21
    AD9920_write( 0 , 0x482,0x2180F8);  //VSEQ_22
    AD9920_write( 0 , 0x483,0x3FFFFFF);  //VSEQ_23
    AD9920_write( 0 , 0x484,0x0);  //VSEQ_24
    AD9920_write( 0 , 0x485,0x0);  //VSEQ_25
    AD9920_write( 0 , 0x486,0x0);  //VSEQ_26
    AD9920_write( 0 , 0x487,0x0);  //VSEQ_27
    
    //7.5 LOAD SEQUENCE 2
    AD9920_write( 0 , 0x488,0x00F0003);  //VSEQ_00
    AD9920_write( 0 , 0x489,0x898);  //VSEQ_01
    AD9920_write( 0 , 0x48A,0x898);  //VSEQ_02
    AD9920_write( 0 , 0x48B,0x0);  //VSEQ_03
    AD9920_write( 0 , 0x48C,0x5dc2ee);  //VSEQ_04
    AD9920_write( 0 , 0x48D,0x5dc2ee);  //VSEQ_05
    AD9920_write( 0 , 0x48E,0x03F880E);  //VSEQ_06
    AD9920_write( 0 , 0x48F,0x0);  //VSEQ_07
    AD9920_write( 0 , 0x490,0x0);  //VSEQ_08
    AD9920_write( 0 , 0x491,0x01);  //VSEQ_09
    AD9920_write( 0 , 0x492,0x5f0000);  //VSEQ_0A
    AD9920_write( 0 , 0x493,0x01);  //VSEQ_0B
    AD9920_write( 0 , 0x494,0x0);  //VSEQ_0C
    AD9920_write( 0 , 0x495,0x5f1FFF);  //VSEQ_0D
    AD9920_write( 0 , 0x496,0x0);  //VSEQ_0E
    AD9920_write( 0 , 0x497,0x5f1FFF);  //VSEQ_0F
    AD9920_write( 0 , 0x498,0x0);  //VSEQ_10
    AD9920_write( 0 , 0x499,0x5f1FFF);  //VSEQ_11
    AD9920_write( 0 , 0x49A,0x0);  //VSEQ_12
    AD9920_write( 0 , 0x49B,0x7FFEFFF);  //VSEQ_13
    AD9920_write( 0 , 0x49C,0x0);  //VSEQ_14
    AD9920_write( 0 , 0x49D,0x0);  //VSEQ_15
    AD9920_write( 0 , 0x49E,0x0);  //VSEQ_16
    AD9920_write( 0 , 0x49F,0x6a0050);  //VSEQ_17
    AD9920_write( 0 , 0x4A0,0x0202260);  //VSEQ_18
    AD9920_write( 0 , 0x4A1,0x6a0050);  //VSEQ_19
    AD9920_write( 0 , 0x4A2,0x3FFFFFF);  //VSEQ_1A
    AD9920_write( 0 , 0x4A3,0x3FFFFFF);  //VSEQ_1B
    AD9920_write( 0 , 0x4A4,0x6a0050);  //VSEQ_1C
    AD9920_write( 0 , 0x4A5,0x3FFFFFF);  //VSEQ_1D
    AD9920_write( 0 , 0x4A6,0x3FFFFFF);  //VSEQ_1E
    AD9920_write( 0 , 0x4A7,0x3FFFFFF);  //VSEQ_1F
    AD9920_write( 0 , 0x4A8,0x1FFF);  //VSEQ_20
    AD9920_write( 0 , 0x4A9,0x0);  //VSEQ_21
    AD9920_write( 0 , 0x4AA,0x3FFFFFF);  //VSEQ_22
    AD9920_write( 0 , 0x4AB,0x3FFFFFF);  //VSEQ_23
    AD9920_write( 0 , 0x4AC,0x0);  //VSEQ_24
    AD9920_write( 0 , 0x4AD,0x0);  //VSEQ_25
    AD9920_write( 0 , 0x4AE,0x0);  //VSEQ_26
    AD9920_write( 0 , 0x4AF,0x0);  //VSEQ_27
    
    //7.6 LOAD SEQUENCE 3
    AD9920_write( 0 , 0x4B0,0x00F0003);  //VSEQ_00
    AD9920_write( 0 , 0x4B1,0x898);  //VSEQ_01
    AD9920_write( 0 , 0x4B2,0x898);  //VSEQ_02
    AD9920_write( 0 , 0x4B3,0x0);  //VSEQ_03
    AD9920_write( 0 , 0x4B4,0x1B40DA);  //VSEQ_04
    AD9920_write( 0 , 0x4B5,0x1B40DA);  //VSEQ_05
    AD9920_write( 0 , 0x4B6,0x3F880E);  //VSEQ_06
    AD9920_write( 0 , 0x4B7,0x0);  //VSEQ_07
    AD9920_write( 0 , 0x4B8,0x0);  //VSEQ_08
    AD9920_write( 0 , 0x4B9,0x0);  //VSEQ_09
    AD9920_write( 0 , 0x4BA,0x1C8000);  //VSEQ_0A
    AD9920_write( 0 , 0x4BB,0x04);  //VSEQ_0B
    AD9920_write( 0 , 0x4BC,0x0);  //VSEQ_0C
    AD9920_write( 0 , 0x4BD,0x1C9FFF);  //VSEQ_0D
    AD9920_write( 0 , 0x4BE,0x0);  //VSEQ_0E
    AD9920_write( 0 , 0x4BF,0x1C9FFF);  //VSEQ_0F
    AD9920_write( 0 , 0x4C0,0x0);  //VSEQ_10
    AD9920_write( 0 , 0x4C1,0x1C9FFF);  //VSEQ_11
    AD9920_write( 0 , 0x4C2,0x0);  //VSEQ_12
    AD9920_write( 0 , 0x4C3,0x7FFFFFF);  //VSEQ_13
    AD9920_write( 0 , 0x4C4,0x0);  //VSEQ_14
    AD9920_write( 0 , 0x4C5,0x0);  //VSEQ_15
    AD9920_write( 0 , 0x4C6,0x0);  //VSEQ_16
    AD9920_write( 0 , 0x4C7,0x1D8050);  //VSEQ_17
    AD9920_write( 0 , 0x4C8,0x020209C);  //VSEQ_18
    AD9920_write( 0 , 0x4C9,0x1D8050);  //VSEQ_19
    AD9920_write( 0 , 0x4CA,0x3FFFFFF);  //VSEQ_1A
    AD9920_write( 0 , 0x4CB,0x3FFFFFF);  //VSEQ_1B
    AD9920_write( 0 , 0x4CC,0x1D8050);  //VSEQ_1C
    AD9920_write( 0 , 0x4CD,0x3FFFFFF);  //VSEQ_1D
    AD9920_write( 0 , 0x4CE,0x3FFFFFF);  //VSEQ_1E
    AD9920_write( 0 , 0x4CF,0x3FFFFFF);  //VSEQ_1F
    AD9920_write( 0 , 0x4D0,0x1FFF);  //VSEQ_20
    AD9920_write( 0 , 0x4D1,0x0);  //VSEQ_21
    AD9920_write( 0 , 0x4D2,0x3FFFFFF);  //VSEQ_22
    AD9920_write( 0 , 0x4D3,0x3FFFFFF);  //VSEQ_23
    AD9920_write( 0 , 0x4D4,0x0);  //VSEQ_24
    AD9920_write( 0 , 0x4D5,0x0);  //VSEQ_25
    AD9920_write( 0 , 0x4D6,0x0);  //VSEQ_26
    AD9920_write( 0 , 0x4D7,0x0);  //VSEQ_27
    
    //7.7 FIELD REGISTER SETUP
    //FIELD 0 REGISTER FOR NORMAL READOUT
    AD9920_write( 0 , 0x4D8,0x1);  //FIELD_REG_00
    AD9920_write( 0 , 0x4D9,0x0);  //FIELD_REG_01
    AD9920_write( 0 , 0x4DA,0x898);  //FIELD_REG_02
    AD9920_write( 0 , 0x4DB,0x2000);  //FIELD_REG_03
    AD9920_write( 0 , 0x4DC,0x0);  //FIELD_REG_04
    AD9920_write( 0 , 0x4DD,0x0);  //FIELD_REG_05
    AD9920_write( 0 , 0x4DE,0x0);  //FIELD_REG_06
    AD9920_write( 0 , 0x4DF,0x908000);  //FIELD_REG_07
    AD9920_write( 0 , 0x4E0,0x3FFFFFF);  //FIELD_REG_08
    AD9920_write( 0 , 0x4E1,0x0);  //FIELD_REG_09
    AD9920_write( 0 , 0x4E2,0x3FFFFFF);  //FIELD_REG_0A
    AD9920_write( 0 , 0x4E3,0x3FFFFFF);  //FIELD_REG_0B
    AD9920_write( 0 , 0x4E4,0x3FFFFFF);  //FIELD_REG_0C
    AD9920_write( 0 , 0x4E5,0x3FFFFFF);  //FIELD_REG_0D
    AD9920_write( 0 , 0x4E6,0x3FFFFFF);  //FIELD_REG_0E
    AD9920_write( 0 , 0x4E7,0x3FFFFFF);  //FIELD_REG_0F
    
    //FIELD 1 REGISTER FOR NORMAL READOUT
    AD9920_write( 0 , 0x4E8,0x0);  //FIELD_REG_00
    AD9920_write( 0 , 0x4E9,0x0);  //FIELD_REG_01
    AD9920_write( 0 , 0x4EA,0x898);  //FIELD_REG_02
    AD9920_write( 0 , 0x4EB,0x0);  //FIELD_REG_03
    AD9920_write( 0 , 0x4EC,0x0);  //FIELD_REG_04
    AD9920_write( 0 , 0x4ED,0x0);  //FIELD_REG_05
    AD9920_write( 0 , 0x4EE,0x0);  //FIELD_REG_06
    AD9920_write( 0 , 0x4EF,0x908000);  //FIELD_REG_07
    AD9920_write( 0 , 0x4F0,0x3FFFFFF);  //FIELD_REG_08
    AD9920_write( 0 , 0x4F1,0x0);  //FIELD_REG_09
    AD9920_write( 0 , 0x4F2,0x3FFFFFF);  //FIELD_REG_0A
    AD9920_write( 0 , 0x4F3,0x3FFFFFF);  //FIELD_REG_0B
    AD9920_write( 0 , 0x4F4,0x3FFFFFF);  //FIELD_REG_0C
    AD9920_write( 0 , 0x4F5,0x3FFFFFF);  //FIELD_REG_0D
    AD9920_write( 0 , 0x4F6,0x3FFFFFF);  //FIELD_REG_0E
    AD9920_write( 0 , 0x4F7,0x3FFFFFF);  //FIELD_REG_0F
    
    //FIELD 2 REGISTER FOR NORMAL READOUT
    AD9920_write( 0 , 0x4F8,0x100041);  //FIELD_REG_00
    AD9920_write( 0 , 0x4F9,0x0);  //FIELD_REG_01
    AD9920_write( 0 , 0x4FA,0x898);  //FIELD_REG_02
    AD9920_write( 0 , 0x4FB,0x2000);  //FIELD_REG_03
    AD9920_write( 0 , 0x4FC,0x2001);  //FIELD_REG_04
    AD9920_write( 0 , 0x4FD,0x0);  //FIELD_REG_05
    AD9920_write( 0 , 0x4FE,0x0);  //FIELD_REG_06
    AD9920_write( 0 , 0x4FF,0x908000);  //FIELD_REG_07
    AD9920_write( 0 , 0x500,0x3FFFFFF);  //FIELD_REG_08
    AD9920_write( 0 , 0x501,0x0);  //FIELD_REG_09
    AD9920_write( 0 , 0x502,0x3FFFFFF);  //FIELD_REG_0A
    AD9920_write( 0 , 0x503,0x3FFFFFF);  //FIELD_REG_0B
    AD9920_write( 0 , 0x504,0x3FFFFFF);  //FIELD_REG_0C
    AD9920_write( 0 , 0x505,0x3FFFFFF);  //FIELD_REG_0D
    AD9920_write( 0 , 0x506,0x3FFFFFF);  //FIELD_REG_0E
    AD9920_write( 0 , 0x507,0x3FFFFFF);  //FIELD_REG_0F
    
    //8.AFE INITIALIZATION
    AD9920_write( 0 , 0x22,0x240080); //HDRISE/VDRISE ,ACTIVE_MODE VALUE=34/339,BE CAREFULL,VALUE DEPENDED ON MODE
    
    AD9920_write( 0 , 0x00,0x4C);
    
    //PROG_AFE_GAIN
    AD9920_write( 0 , 0x004,0x04);   //CDSGAIN=6 EQU. +3DB
    AD9920_write( 0 , 0x005,0x6e);  //VGAGAIN=35 EQU. 7.85DB
    AD9920_write( 0 , 0x006,0x78);   //CLAMPLEVEL = 10
    
    //SET OPERATION FREQUENCE
    AD9920_write( 0 , 0x00D,0x0);  //40MHZ
    
    //OSC_RSTB = POWERDOWN,EXTERNAL CLOCK USED
    AD9920_write( 0 , 0x015,0x0);
    
    AD9920_write( 0 , 0x076,0x01); //SUBCLK_POL = 1
    AD9920_write( 0 , 0x077,0x01F8036); //SUBCLK_TOG1/SUBCLK_TOG2 = 54/126
    AD9920_write( 0 , 0x024,0x04);  //HCLK_MODE = MODE 1
    AD9920_write( 0 , 0x014,0x0);   //TGCORE_RSTB
    AD9920_write( 0 , 0x014,0x1);   //RESUME TO OPERATION
    
    AD9920_write( 0 , 0x023,0x00F);  //NVR REGISTER 3.3V
    
    //CONFIGURE VCLOCKS
    AD9920_write( 0 , 0x25,0x3F880E); //SET DEFAULT STATE OF VCLOCK DRIVERS IN STDBY 1,2
    AD9920_write( 0 , 0x26,0x3F880E); //SET DEFAULT STATE OF VCLOCK DRIVERS IN STDBY 3
    AD9920_write( 0 , 0x1C,0x0);  //COFIGURE XV AND VSG SIGNALS
    
    //PROG_AFE_PIXEL_TIMING
    AD9920_write( 0 , 0x30,0x13F1F);//TCR_30,H1POSLOC=31,HINEGLOC=32+H1POSLOC
    AD9920_write( 0 , 0x31,0x12000);//TCR_31,H2POSLOC=0,H2NEGLOC=32+H2POSLOC
    AD9920_write( 0 , 0x32,0x12000);//TCR_32,HLPOSLOC=0,HLNEGLOC=32+HLPOSLOC
    AD9920_write( 0 , 0x33,0x12000);//TCR_33,H3P1POSLOC=0,H3P1NEGLOC=32+H3P1POSLOC
    AD9920_write( 0 , 0x34,0x10E08);//TCR_34,RGPOSLOC=0,RGNEGLOC=RGPOSLOC+RESET_WIDTH,RESET_WIDTH = Tr
    AD9920_write( 0 , 0x35,0x000020F);
    AD9920_write( 0 , 0x36,0x310022);//TCR_36,RGDRV=3,HLDRV=1,H4DRV=0,H3DRV=0,H2DRV=2,H1DRV=2
    AD9920_write( 0 , 0x37,0x110022);//TCR_37,H8DRV=0,H7DRV=0,H6DRV=2,H5DRV=2
    AD9920_write( 0 , 0x38,0x102D0D);  //TCR_38,SHDLOC=13,SHPLOC=45,
    AD9920_write( 0 , 0x39,0x082A0A); //TCR_39,DOUTPHASEP=10,DOUTPHASEN=42,DCLKMODE=0,DOUTDELAY=1-,DCLKINV=1
    
    //9.OTHER SETTINGS
    AD9920_write( 0 , 0xC3,0x2180);  //MANUALLY FORCE GPO8 TO HIGH
    AD9920_write( 0 , 0x73,0x0300920);
    AD9920_write( 0 , 0x7A,0x0CFCFCE);
    
    //SET VH_VL_EN
    LTC1665_write(0x7,0xFE);
       
    AD9920_write( 0 , 0x11,0x0001);    //OUT_CONTROL=ENABLE
    AD9920_write( 0 , 0x0D1,0x0100000);//STARTUP
    
    AD9920_write( 0 , 0x2A,0x01); //MODE = 1 TOTAL NUMBER OF FIELDS
    AD9920_write( 0 , 0x2B,0x0);  //FIELD F1=0,F2=0,F3=0,F4=0,F5=0;
    AD9920_write( 0 , 0x2C,0x0);  //FIELD F6=0,F7=0
    
    AD9920_write( 0 , 0x13,0x1000001); 
//#ES Disable
 	 AD9920_write( 0, 0x8e, 0x3e80001);
 	 AD9920_write( 0, 0x8f, 0x2050 );
 	 AD9920_write( 0, 0x90, 0xb5f40 );    
}





void sensor_init()
{    
    memFd = open("/dev/mem", O_RDWR | O_SYNC);
    if( memFd < 0 )
    {
        printf("Can't Open mem device !");
        return ;
    }
    
    FPGA_virtual_addr = (char*)mmap( NULL, 1024 , PROT_READ|PROT_WRITE , MAP_SHARED , memFd , FPGA_BASE_ADDR );
    if( FPGA_virtual_addr == (char*) -1 )
    {
        printf("FPGA map failed !");
        close( memFd ) ;
        return ;
    }
    
    ccd_sensor_init() ;        
}


