/******************************************************************************

  Copyright (C), 2001-2011, Hisilicon Tech. Co., Ltd.

 ******************************************************************************
  File Name     : i2c_write.c
  Version       : Initial Draft
  Author        : Hisilicon multimedia software group
  Created       : 2010/08/20
  Description   : GPIO-I2C for 8bit register and 16bit Data Transfer, eg. MT9P031
  History       :
  1.Date        : 2010/08/20
    Author      : x00100808
    Modification: Created file

******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "strfunc.h"
#include "gpioi2c_16.h"


int main(int argc , char* argv[])
{
	int fd = -1;
	int ret;
	unsigned int device_addr, reg_addr, reg_value, value;
		
	if(argc != 4)
    {
    	printf("usage: %s <device_addr> <reg_addr> <value>. sample: %s 0x56 0x0 0x28\n", argv[0], argv[0]);
        return -1;
    }
	
	fd = open("/dev/gpioi2c_16", 0);
    if(fd<0)
    {
    	printf("Open drvdbgdev error!\n");
    	return -1;
    }
    
    if (StrToNumber(argv[1], &device_addr))
    {    	
    	return 0;
    }
    
    
    if (StrToNumber(argv[2], &reg_addr))
    {    
    	return 0;
    }
    
    if (StrToNumber(argv[3], &reg_value))
    {    
    	return 0;
    }
    
    printf("device_addr:0x%2x; reg_addr:0x%2x; reg_value:0x%2x.\n", device_addr, reg_addr, reg_value);
    
    value = ((device_addr&0xff)<<24) | ((reg_addr&0xff)<<16) | (reg_value&0xffff);
    
    ret = ioctl(fd, GPIO_I2C_WRITE, &value);

	close(fd);
        
    return 0;
}

