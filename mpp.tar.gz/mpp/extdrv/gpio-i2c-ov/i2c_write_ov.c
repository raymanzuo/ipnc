/******************************************************************************

  Copyright (C), 2001-2011, Hisilicon Tech. Co., Ltd.

 ******************************************************************************
  File Name     : i2c_write_ov.c
  Version       : Initial Draft
  Author        : Hisilicon multimedia software group
  Created       : 2010/09/10
  Description   : GPIO-I2C for 16bit register and 8bit data Transfer, eg. OV2715
  History       :
  1.Date        : 2010/09/10
    Author      : x00100808
    Modification: Created file

******************************************************************************/

#include <stdio.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include "strfunc.h"
#include "gpioi2c_ov.h"


int main(int argc , char* argv[])
{
	int fd = -1;
	int ret =0;
	unsigned int device_addr, reg_addr, reg_value, value;
		
	if(argc != 4)
    {
    	printf("usage: %s <device_addr> <reg_addr> <value>. sample: %s 0x56 0x0 0x28\n", argv[0], argv[0]);
        return -1;
    }
	
	fd = open("/dev/gpioi2c_ov", 0);
    if(fd<0)
    {
    	printf("Open gpioi2c error!\n");
    	return -1;
    }
    
    if (StrToNumber(argv[1], &device_addr))
    {    	
    	return 0;
    }
    
    
    if (StrToNumber(argv[2], &reg_addr))
    {    
    	return 0;
    }
    
    if (StrToNumber(argv[3], &reg_value))
    {    
    	return 0;
    }
    
    printf("device_addr:0x%2x; reg_addr:0x%2x; reg_value:0x%2x.\n", device_addr, reg_addr, reg_value);
    
    value = ((device_addr&0xff)<<24) | ((reg_addr&0xffff)<<8) | (reg_value&0xff);
    
   
    ret = ioctl(fd, GPIO_I2C_WRITE, &value);
	if (ret)
	{
	    printf("ret :%d\n", ret);
	}
    
    close(fd);

    return 0;
}
