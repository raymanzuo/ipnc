/******************************************************************************

  Copyright (C), 2001-2011, Hisilicon Tech. Co., Ltd.

 ******************************************************************************
  File Name     : gpioi2c_ov.h
  Version       : Initial Draft
  Author        : Hisilicon multimedia software group
  Created       : 2010/09/10
  Description   : for 16bit register and 8bit data transfer
  History       :
  1.Date        : 2010/09/10
    Author      : x00100808
    Modification: Created file

******************************************************************************/

#ifndef __GPIO_I2C_OV_H__
#define __GPIO_I2C_OV_H__


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */


#define GPIO_I2C_READ   0x01
#define GPIO_I2C_WRITE  0x03

unsigned char gpio_i2c_read_ov(unsigned char devaddress, unsigned short address);
void gpio_i2c_write_ov(unsigned char devaddress, unsigned short address, unsigned char value);

unsigned char gpio_ip2986_read(unsigned char devaddress,unsigned int address);
void  gpio_ip2986_write(unsigned char devaddress,unsigned int address,unsigned char value);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */


#endif	/* __GPIO_I2C_OV_H__ */
