
#include <linux/kernel.h>

#include <linux/version.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/fcntl.h>
#include <linux/mm.h>
#include <linux/miscdevice.h>
#include <linux/proc_fs.h>

#include <linux/fs.h>
#include <linux/init.h>
#include <asm/uaccess.h>

#include <linux/string.h>
#include <linux/list.h>
#include <asm/delay.h>
#include <linux/timer.h>
#include <linux/delay.h>
#include <linux/moduleparam.h>

#ifdef HI_GPIO_I2C
#include "gpio_i2c.h"
#else
#include "i2c.h"
#endif

#include "adv7441.h"
#include "adv7441_def.h"


#define DEBUG_ADV7400 1

static int mode = DETECT_720_576_I50;
//static unsigned int ADV7400_dev_open_cnt =0;


unsigned char adv7400_cvbs_mode[]=
{
	DETECT_NTSC_M,				//NTSC_M
	DETECT_NTSC_443,			//NTSC_443
	DETECT_PAL_M,				//PAL_M
	DETECT_PAL_60,				//PAL_60
	DETECT_PAL_BGHID,			//PAL_BG
	DETECT_SECAM,				//SECAM
	DETECT_PAL_N,				//PAL_N
	DETECT_SECAM_525			//SECAM_525
};


MODEDETECTTB adv7400_ycbcr_mode[]=
{
	{DETECT_720_480_I60,		BL_480I,		SCF_480I_1,	SCF_480I_2},
	{DETECT_720_576_I50,		BL_576I,		SCF_576I_1,	SCF_576I_2},
	{DETECT_720_480_P60,	BL_480P,		SCF_480P_1,	SCF_480P_2},
	{DETECT_720_576_P50,	BL_576P,		SCF_576P_1,	SCF_576P_2},
	{DETECT_1280_720P,		BL_720P,		SCF_720P_1,	SCF_720P_2},
	{DETECT_1920_1080_I50,	BL_1080I50,	SCF_1080I50_1,	SCF_1080I50_2},
	{DETECT_1920_1080_I60,	BL_1080I60,	SCF_1080I60_1,	SCF_1080I60_2},
	{0xff,					0xffff,		0xffff},
};

int ADV7441_read(unsigned char MAP_ADDR,unsigned char sub_add)
{
	int value;	
#ifdef HI_GPIO_I2C    
	value = gpio_i2c_read(MAP_ADDR,sub_add);
#else
    value = i2c_read(MAP_ADDR,sub_add);
#endif
	return value;
}

void ADV7441_write(unsigned char MAP_ADDR,unsigned char sub_add,unsigned char data_para)
{
#ifdef HI_GPIO_I2C
    gpio_i2c_write(MAP_ADDR,sub_add,data_para);
#else
	i2c_write(MAP_ADDR,sub_add,data_para);
#endif
	return;
}

void Adv7400_Set_YcbcrMode(unsigned char videomode)
{
	unsigned char i;
	REGTABLE *reglink;
	i = 0;
	reglink = adi7401_initial_data;
	while(0xff != reglink[i].ucAddr || 0xff !=reglink[i].ucValue)
	{
		ADV7441_write(adv7441_I2C_ADDR_MAP,reglink[i].ucAddr,reglink[i].ucValue);
		i++;
	}

	switch(videomode)
	{
		case DETECT_720_576_I50:
			reglink = adi7401_YPbPr576i_data;	
			break;
		case DETECT_720_480_P60:
			reglink = adi7401_YPbPr480P_data;
		
			break;
		case DETECT_720_576_P50:
			reglink = adi7401_YPbPr576P_data;
	
			break;
		case DETECT_1280_720P:
		
			printk("ADV7400 driver select 720P successful!\n");

			reglink = adi7401_YPbPr720P_data;
		
			break;
		case DETECT_1920_1080_I50:
			reglink = adi7401_YPbPr1080i50_data;
			break;
		case DETECT_1920_1080_I60:
			reglink = adi7401_YPbPr1080i60_data;
			break;
		default:
			reglink = adi7401_YPbPr480i_data;
			break;
	}
	i = 0;
	while(0xff != reglink[i].ucAddr || 0xff !=reglink[i].ucValue)
	{
		ADV7441_write(adv7441_I2C_ADDR_MAP,reglink[i].ucAddr,reglink[i].ucValue);
		i++;
	}			

	return;
}




void Adc7400_Set_VgaMode(unsigned char video_mode)
{
	ADV7441_write(adv7441_I2C_ADDR_MAP,0x01,0xc8);
	//8BIT 656���
	ADV7441_write(adv7441_I2C_ADDR_MAP,0x03,0x0c);
	//ͨ��ѡ��
	ADV7441_write(adv7441_I2C_ADDR_MAP,0x05,0x02);
	switch(video_mode)
	{
		case DETECT_60XGA:
		case DETECT_NONE:
			//�����ź��������
		 	ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			//�����źŸ�ʽΪ1024*768*60
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0c);
			//ADI����
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);
			//PLL ��������Ϊ500UA
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5D);  //5B
			break;
		case DETECT_70XGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			//�����źŸ�ʽΪ1024*768*70
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0D);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5D);  
			break;					
		case DETECT_75XGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			//�����źŸ�ʽΪ1024*768*75
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0E);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5D);   //5B
			break;	
		case DETECT_85XGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			//�����źŸ�ʽΪ1024*768*85
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0F);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5D);  //5B
			break;			
		case DETECT_60SVGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x01);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5c);  
			break;
		case DETECT_72SVGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5c); 
 			break;
		case DETECT_75SVGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x03);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5c);  
		   	break;
		case DETECT_85SVGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x04);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5b);  
			break;
		case DETECT_60VGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x55);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x08);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x05);	
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5b);
			break;
		case DETECT_72VGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x09);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5b);
			break;
		case DETECT_75VGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0a);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5c);
			break;
		case DETECT_85VGA:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0b);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5b);
			break;
		case DETECT_DOS185:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0b);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5C);
			break;
		case DETECT_DOS285:
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x04,0x75);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x06,0x0b);//������
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x0f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3c,0x5C);//���໷����
			break;
		default:
			break;
	}		
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x17,0x01);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x27,0x58);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x31,0x12);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x38,0x80);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x39,0xc0);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3a,0x10);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3b,0x80);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x3d,0x33);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x41,0x41);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x4d,0xef);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x67,0x03);			
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x69,0x00);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x6a,0x00);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x6b,0xc2);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x73,0x90);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x77,0x3f);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x78,0xff);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x79,0xff);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x7a,0xff);			
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x7b,0x1c);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x85,0x42);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x86,0x02);
           	if(video_mode == DETECT_DOS185) //640x400
            {
        		ADV7441_write(adv7441_I2C_ADDR_MAP,0x87,0xE3);
    			ADV7441_write(adv7441_I2C_ADDR_MAP,0x88,0x40);
    			ADV7441_write(adv7441_I2C_ADDR_MAP,0x8A,0xB0);
            }
            else if(video_mode == DETECT_DOS285)//720x400
            {
        		ADV7441_write(adv7441_I2C_ADDR_MAP,0x87,0xE3);
    			ADV7441_write(adv7441_I2C_ADDR_MAP,0x88,0xA8);
    			ADV7441_write(adv7441_I2C_ADDR_MAP,0x8A,0xB0);
            }
            else
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x87,0x60);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x88,0x00);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x89,0x08);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xb5,0x03);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xbf,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xc0,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xc2,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xc3,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xc4,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xc9,0x10);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xcd,0x10);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xce,0x10);			
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xd0,0x46);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xd4,0x01);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xd6,0x3e);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xdc,0x7b);		
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xe2,0x80);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xe3,0x80);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xe4,0x80);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0xe8,0x65);
			if((video_mode == DETECT_85VGA)||(video_mode == DETECT_85SVGA)||(video_mode == DETECT_60XGA))
			{
				ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x80); 
				ADV7441_write(adv7441_I2C_ADDR_MAP,0x58,0xed); 
				ADV7441_write(adv7441_I2C_ADDR_MAP,0x0e,0x00); 
			}
}

void Adv7400_blue_screen(unsigned char enable)
{
    	unsigned char i, cp_i;
    	i = ADV7441_read(adv7441_I2C_ADDR_MAP,DEFAULT_VALUE_Y);
    	cp_i = ADV7441_read(adv7441_I2C_ADDR_MAP,CP_DEF_VAL_EN);
    	//
    	if(enable == 1)  //blue screen enable
    	{
        	ADV7441_write(adv7441_I2C_ADDR_MAP,0x36, 0x02);        
        	//����Y��CB = 0xE0��CR=0x60
        	ADV7441_write(adv7441_I2C_ADDR_MAP,0x0d, 0x6E); 
        	//FORCE TO OUTPUT DEFAULT YCBCR
        	i = i | DEF_VAL_EN;
        	ADV7441_write(adv7441_I2C_ADDR_MAP,DEFAULT_VALUE_Y, i);     
		//���������ɫ��ɫY��CB��CR
       	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc0, 35);        
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc1, 212);  
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc2, 114); 
        	//������õĵ�ɫ��ɫ
        	cp_i = cp_i | CP_DEF_COL_MAIN_VAL;
        	ADV7441_write( adv7441_I2C_ADDR_MAP,CP_DEF_VAL_EN, cp_i);     
    	}
    	else if(enable == 0)   //raw data enable
    	{
    		//�ر�FORCE���
       	i = i & (~DEF_VAL_EN);
        	ADV7441_write( adv7441_I2C_ADDR_MAP,DEFAULT_VALUE_Y, i);   
        	cp_i = cp_i & (~CP_DEF_COL_MAIN_VAL);
        	ADV7441_write( adv7441_I2C_ADDR_MAP,CP_DEF_VAL_EN, cp_i);              
    	}
    	else if(enable == 2) //black screen enable
    	{
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0x36, 0x00);        
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0x0d, 0x88);          
        	i = i | DEF_VAL_EN;
        	ADV7441_write( adv7441_I2C_ADDR_MAP,DEFAULT_VALUE_Y, i);     
       
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc0, 0x30);        
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc1, 0x80);  
        	ADV7441_write( adv7441_I2C_ADDR_MAP,0xc2, 0x80);        
        	cp_i = cp_i |(CP_DEF_COL_FORCE+CP_DEF_COL_MAIN_VAL);
        	ADV7441_write( adv7441_I2C_ADDR_MAP,CP_DEF_VAL_EN, cp_i);     
    	}
}

void Adv7400_channel(unsigned char video_in)
{
	switch(video_in)
	{
		//AV INPUT FORM A11 
		case AV_IN:
			ADV7441_write(adv7441_I2C_ADDR_MAP,PRIM_MODE,0x00);
			ADV7441_write(adv7441_I2C_ADDR_MAP,SDM_SEL,0x01);
			//ENABLE 	ADC0
			ADV7441_write(adv7441_I2C_ADDR_MAP,ADC_POWER_CONTROL,0x17);
			break;
		//YC INPUT FORM A10,A12 	
		case SVIDEO_IN:
			ADV7441_write(adv7441_I2C_ADDR_MAP,PRIM_MODE,0x00);
			ADV7441_write(adv7441_I2C_ADDR_MAP,SDM_SEL,0x02);		
			//ENABLE	ADC0,ADC1
			ADV7441_write(adv7441_I2C_ADDR_MAP,ADC_POWER_CONTROL,0x13);
			break;
		//Y CB CR FORM A6,A4,A5
		case YCBCR_IN:
			ADV7441_write(adv7441_I2C_ADDR_MAP,PRIM_MODE,0x01);
			ADV7441_write(adv7441_I2C_ADDR_MAP,ADC_POWER_CONTROL,0x21);
//			ADV7441_write(adv7441_I2C_ADDR_MAP,0x85,0x18);  // Turn off SSPD as SYNC is embedded on Y
			break;
		//R G B FORM A3,A2,A1
		case VGA_IN:
			ADV7441_write(adv7441_I2C_ADDR_MAP,PRIM_MODE,0x02);
			ADV7441_write(adv7441_I2C_ADDR_MAP,ADC_POWER_CONTROL,0x11);
			ADV7441_write(adv7441_I2C_ADDR_MAP,0x85,0x42);  
			break;
		default:
			break;
	}
}

#if 0
unsigned char Adv7400_detect(unsigned char video_in)
{	
	unsigned char status1,status3,SCVS;
	unsigned int BL,SCF;

	switch(video_in)
	{
		case AV_IN:
			 break;
		case SVIDEO_IN:
			status1 = i2c_read(adv7441_I2C_ADDR_MAP,STATUS1);
			status3 =  i2c_read(adv7441_I2C_ADDR_MAP,STATUS3);
	 		if(((status3&STATUS3_INST_HLOCK)== 0x01)&&((status1&STATUS1_IN_LOCK)== 0x01)&&(ErrorId == 0xff))
            		{	
//            		status1 = status1 & STATUS1_DETECT_SYSTEM;
            			status1 = status1>>4;
            			return adv7400_cvbs_mode[status1&0x07];
			 }
			 else
   			    	return DETECT_NONE;
			break;
		case YCBCR_IN:  
			 return YCBCR_IN;
			 break;
		case VGA_IN :			
			status1 = i2c_read(adv7441_I2C_ADDR_MAP,RB_STANDARD_IDENTIFICATION_1);
    		if(status1 & SDTI_DVALID)
			{
				//��ȡBL
				BL = (status1 & 0x3f) <<8;
				status1 = i2c_read(adv7441_I2C_ADDR_MAP,RB_STANDARD_IDENTIFICATION_2);
				BL = BL + status1;
				//��ȡSCVS
				status1 = i2c_read(adv7441_I2C_ADDR_MAP,RB_STANDARD_IDENTIFICATION_3);
				SCVS = status1>>3;
				//��ȡSCF
				SCF = (status1&0x07)<<8;
				status1 = i2c_read(adv7441_I2C_ADDR_MAP,RB_STANDARD_IDENTIFICATION_4);
				SCF = SCF + status1;
			}
    		if(video_in == YCBCR_IN)
    		{
    			status1 = 0;
    			while(adv7400_ycbcr_mode[status1].ucMode != 0xff)
    			{
    				if((BL >= (adv7400_ycbcr_mode[status1].bl-BL_DITHER))
    					&&(BL <= (adv7400_ycbcr_mode[status1].bl+BL_DITHER))
    					&&(SCF >= (adv7400_ycbcr_mode[status1].scf1))
    					&&(SCF <= (adv7400_ycbcr_mode[status1].scf2)))
    					return adv7400_ycbcr_mode[status1].ucMode;
    				status1++;
    			}
    			return DETECT_NONE;
    		}
			else
			{
				if(((BL > 6817)&&(BL < 6997))&&((SCF > 522)&&(SCF < 526))) 		return DETECT_DOS185;
	 			else if(((BL > 6817)&&(BL < 6997))&&((SCF > 522)&&(SCF < 526))) 	return DETECT_DOS285;        
	 			else if(((BL > 6817)&&(BL < 6997))&&((SCF > 522)&&(SCF < 526))) 	return DETECT_60VGA;
			    	else if(((BL > 5659)&&(BL < 5739))&&((SCF > 516)&&(SCF < 521)))	return DETECT_72VGA;	
				else if(((BL > 5720)&&(BL < 5800))&&((SCF > 496)&&(SCF < 501)))	return DETECT_75VGA;
				else if(((BL > 4948)&&(BL < 5028))&&((SCF > 505)&&(SCF < 510)))	return DETECT_85VGA;	
				else if(((BL > 5659)&&(BL < 5739))&&((SCF > 623)&&(SCF < 629)))	return DETECT_60SVGA;
				else if(((BL > 4451)&&(BL < 4531))&&((SCF > 659)&&(SCF < 667)))	return DETECT_72SVGA;	 
				else if(((BL > 4566)&&(BL < 4820))&&((SCF > 621)&&(SCF < 626)))	return DETECT_75SVGA;
				else if(((BL > 3982)&&(BL < 4062))&&((SCF > 627)&&(SCF < 632)))	return DETECT_85SVGA;	
				else if(((BL > 4323)&&(BL < 4503))&&((SCF > 799)&&(SCF < 807)))	return DETECT_60XGA;
				else if(((BL > 3783)&&(BL < 3963))&&((SCF > 799)&&(SCF < 807)))	return DETECT_70XGA;	
				else if(((BL > 3560)&&(BL < 3740))&&((SCF > 796)&&(SCF < 805)))	return DETECT_75XGA;
				else if(((BL > 3104)&&(BL < 3184))&&((SCF > 804)&&(SCF < 809)))	return DETECT_85XGA;	
		        	else															return DETECT_NONE;
			}
			break;
		default :
			return DETECT_NONE;
	  }
	  return -1;
}
#endif

int adv7441_720P_60HZ(void)
{
    ADV7441_write(0x42,0x03,0x0c);
    //ADV7441_write(0x42,0x03,0x04);
	ADV7441_write(0x42,0x05,0x01);
	ADV7441_write(0x42,0x06,0x0a);
	ADV7441_write(0x42,0x1d,0x40);
	ADV7441_write(0x42,0x3c,0xa8);
	ADV7441_write(0x42,0x47,0x0a);
	
    //ADV7441_write(0x42,0x68,0xf0);  // bit1 0: output YUV  1: output RGB 
	ADV7441_write(0x42,0x6b,0xd3); // set cpop_sel: 0xd1: for 8 bit 4:2:2 mode  0xd6: 16bit 4:2:2
	//ADV7441_write(0x42,0x6b,0xd7);
    
	ADV7441_write(0x42,0x7b,0x2f);
	
	ADV7441_write(0x42,0x85,0x19);
	ADV7441_write(0x42,0xba,0xa0);
	ADV7441_write(0x42,0xf4,0x3f);  // port highest driver.
	ADV7441_write(0x42,0x47,0x08);
	printk("720p/60Hz YPrPb In 1X1 30Bit 444 Out through DAC ok !\n");
    return 0;
}

int adv7441_1080I_60HZ(void)
{
    ADV7441_write(0x42,0x03,0x0c);
	ADV7441_write(0x42,0x05,0x01);     // Prim_Mode =001b COMP
	ADV7441_write(0x42,0x06,0x0c);    //VID_STD=1100b for 1125 1x1 
	ADV7441_write(0x42,0x1d,0x40);
	ADV7441_write(0x42,0x3c,0xa8);
	ADV7441_write(0x42,0x47,0x0a);
	ADV7441_write(0x42,0x6b,0xd3); // set cpop_sel: 0xd1: for 20 bit 4:2:2 mode  0xd3: 16bit 4:2:2
#if 0
	ADV7441_write(0x42,0x7b,0x0f); // bit4  1: channel a/b have the same AV code. bit5 0: output progressive timing  bit6,7 0: F /V bit as default polarity.
#else
	ADV7441_write(0x42,0x7b,0x2f);
#endif
	ADV7441_write(0x42,0x85,0x19);
	ADV7441_write(0x42,0xba,0xa0);
	ADV7441_write(0x42,0xf4,0x3f);  // port highest driver.
	ADV7441_write(0x42,0x47,0x08);
	printk("1080i 60Hz 1920x1080 YPrPb In 1x1 20Bit 422 Out through Encoder (AV Codes): is ok \n");	
    return 0;
}

void adv7441_576I_60HZ(void)
{
    // main profile
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x05, 0x00);	// Primary mode: standard definition, SDP, CVBS/YC/YPbPr
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x06, 0x02);	// Video standard: default: 0x2 SD 4x1 54MHz sampling		SDP

#if 0
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x00, 0x0E);	// CVBS INPUT ON Ain6 to suit VGA input.
#else
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x00, 0x04);	// CVBS INPUT ON Ain5 to suit YPbPr input.
#endif

#if 0
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x03, 0x00);	// 10 bit adv7441_I2C_ADDR_MAP2 out through P19-P10 
#else
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x03, 0x0c);	// 8-bit@LLC1 4:2:2 ITU-R BT.656 out through P19-P12 
#endif

	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x3C, 0xAD);	// Setup SOG Sync level for divided down SOG
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x04, 0x47);	// Enable SFL
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x17, 0x41);	// select SH1
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x1D, 0x40);	// Disable TRI_LLC.
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x31, 0x00);	// Clears NEWAV_MODE, SAV/EAV  to suit ADV video encoders
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x34, 0x01);	// H Sync position control
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x35, 0x22);	// H Sync position control
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x3A, 0x07);	// Power down ADC 1 & ADC2 & ADC3
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x3C, 0xA8);	// SOG Sync level for atenuated sync, PLL Qpump to default
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0x47, 0x0A);	// Enable Automatic PLL_Qpump and VCO Range
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0xBA, 0xA0);	// Enables Simultaneous Mode (certain HDMI sections kept Active)
	ADV7441_write(adv7441_I2C_ADDR_MAP, 0xF3, 0x0F);	// Enable Anti-Alias Filters

	printk("576i 50Hz 720x576 CVBS In : is ok!\n");
}

int adv7441_set_video_format(ADV7441_VIDEO_FORMAT_E enFormat)
{
    if (VIDEO_FORMAT_720P_60HZ == enFormat)
    {
        adv7441_720P_60HZ();
    }
    else if (VIDEO_FORMAT_1080I_60HZ == enFormat)
    {
        adv7441_1080I_60HZ();
    }
    else if(VIDEO_FORMAT_576I_60HZ == enFormat)
    {
        adv7441_576I_60HZ();
    }
    else
    {
        printk("not suppor this video format");
        return -1;
    }
    
    return 0;
}

int adv7441_device_init(void)
{
    if(mode == DETECT_1280_720P)
    {
        adv7441_720P_60HZ();
    }
/*
42 03 0C ; Disable TOD
42 05 01 ; Prim_Mode =001b COMP
42 06 0C ; VID_STD=1100b for 1125 1x1
42 1D 40 ; Disable TRI_LLC
42 3C A8 ; SOG Sync level for atenuated sync, PLL Qpump to default
42 47 0A ; Enable Automatic PLL_Qpump and VCO Range
42 6B D1 ; Setup CPOP_SEL for 20 Bit.656 Enable
42 85 19 ; Turn off SSPD and force SOY. For Eval Board.
42 BA A0 ; Enable HDMI and Analog in
*/
	else if (mode == DETECT_1920_1080_I60)
	{
		adv7441_1080I_60HZ();
	}	
	else if (mode == DETECT_720_576_I50)
	{
		adv7441_576I_60HZ();
	}
	else
    {
        return -1;
    }
    return 0;
}

int adv7441_open(struct inode * inode, struct file * file)
{
    return 0;
}
int adv7441_close(struct inode * inode, struct file * file)
{
    return 0;
}

int adv7441_ioctl(struct inode *inode, 
        struct file *file, unsigned int cmd, unsigned long arg)
{
    switch(cmd)
    {
        case ADV7441_SET_VIDEO_FORMAT:
        {
            ADV7441_VIDEO_FORMAT_E tmp = 0;
            if (copy_from_user(&tmp, (ADV7441_VIDEO_FORMAT_E*)arg, sizeof(tmp)))
            {
                return -ERESTARTSYS;
            }
            if (adv7441_set_video_format(tmp))
            {
                return -1;
            }
            break;
    	}
        default:
            break;
    }
    return 0;
}

static struct file_operations adv7441_fops = 
{
    .owner      = THIS_MODULE,
    .open       = adv7441_open,
    .release    = adv7441_close,
    .ioctl      = adv7441_ioctl,
};

static struct miscdevice adv7441_dev = 
{   
	.minor		= MISC_DYNAMIC_MINOR,
    .name		= "adv7441",
    .fops  		= &adv7441_fops,
};


static int __init adv7441_init(void)
{    
    if (misc_register(&adv7441_dev))
    {
        printk("ERROR: could not register adv7441 devices\n");
		return -1;
    }
    
    if (adv7441_device_init())
    {
        printk("adv7441_device_init fail \n");
        misc_deregister(&adv7441_dev);
        return -1;
    }
    
    printk("adv7441 driver init successful!\n");
    return 0;
}
static void __exit adv7441_exit(void)
{
    misc_deregister(&adv7441_dev);
}

module_init(adv7441_init);
module_exit(adv7441_exit);

module_param(mode, uint, S_IRUGO);      /* mode:1 BT656 576I;  mode:4 BT1120 720P;  mode:6 BT1120 1080I@60 */

MODULE_LICENSE("GPL");
