1.Module parameter description

	norm=5		1080i@50(default, i.e.,without parameter)
	norm=6		1080i@60
	norm=7		720p@60
	norm=8		720p@50
	norm=9		1080p@30
	norm=10		1080p@25
	norm=11		1080p@24


		
2.Sample

	insmod sil9034.ko norm=5
	
	
	
	       case 5 :
            printk("sil9034 init as 1080i@50\n");
            sil9034_1080i50_init();
            break;
        case 6 :
            printk("sil9034 init as 1080i@60\n");
            sil9034_1080i60_init();
            break;
        case 7 :
            printk("sil9034 init as 720p@60\n");
            sil9034_720p60_init();
            break;
        case 8 :
            printk("sil9034 init as 720p@50\n");
            sil9034_720p50_init();
            break;
        case 9 :
            printk("sil9034 init as 1080p@30\n");
            sil9034_1080p30_init();
            break;   
        case 10 :
            printk("sil9034 init as 1080p@25\n");
            sil9034_1080p25_init();
            break;    
        case 11 :
            printk("sil9034 init as 1080p@24\n");
            sil9034_1080p24_init();
            break;              
        default:
            printk("sil9034 init as 720p@50\n");
            sil9034_720p50_init();


