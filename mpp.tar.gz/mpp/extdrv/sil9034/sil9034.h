#ifndef __SIL9034_H__
#define __SIL9034_H__

#define SIL9034_I2C_ADDR_A  0x72
#define SIL9034_I2C_ADDR_B  0x7a

#endif  /* __SIL9034_H__ */

