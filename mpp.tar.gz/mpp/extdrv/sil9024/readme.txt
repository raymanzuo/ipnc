1.Module parameter description

	5:720p@60, 6:720p@50, 7:1080i@60, 8:1080i@50, 9:1080p@60(default), 10:1080p@50, 11:1080p@25, 12:1080p@30