#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include "hi_common.h"
#include "hi_comm_video.h"
#include "hi_comm_sys.h"
#include "hi_comm_vi.h"
#include "hi_comm_vo.h"
#include "mpi_vb.h"
#include "mpi_sys.h"
#include "mpi_vi.h"
#include "mpi_vo.h"

#include "hi_comm_isp.h"
#include "mpi_isp.h"
#include "hi_sns_ctrl.h"

#define MAX_FRM_CNT 256

pthread_t isp_pid;

/* The enCompMode of VI_DEV_ATTR_S should be VI_COMP_MODE_DOUBLE, 
and the au32CompMask array which is relative to the enCompMode should be configd,
and the isp should be disabled when we want to get the bayer RGB data. */
VI_DEV_ATTR_S stBayer9p031Attr1080P = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF0,    0xF},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_FALSE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1920,        0,
         0,            1080,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stBayer9p031Attr720P = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF0,    0xF},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_FALSE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1280,        0,
         0,            720,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stBayer9p031Attr5M = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF0,    0xF},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_FALSE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            2592,        0,
         0,            1944,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stBayerOv2715Attr = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF00,    0xFF},
    VI_CLK_EDGE_SINGLE_DOWN,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GBGB},
    /* Disable Isp */
     HI_FALSE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_NORM_PULSE,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1920,        0,
         0,            1080,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stBayerAltasenseAttr =
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF0,    0xF},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_FALSE,     
    {
    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
    {0,            1920,        0,
     0,            1080,        0,
     0,            0,            0}
    },
    {
     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stBayerImx036Attr =
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF0,    0xF},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_FALSE,     
    {
    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
    {0,            1920,        0,
     0,            1080,        0,
     0,            0,            0}
    },
    {
     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S st9p031Attr1080P = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_TRUE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1920,        0,
         0,            1080,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S st9p031Attr720P = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_TRUE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1280,        0,
         0,            720,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S st9p031Attr5M = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_TRUE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
        {0,            2592,        0,
         0,            1944,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stOv2715Attr = 
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_DOUBLE,
    /* Config the mask */
    {0xFF00,    0xFF},
    VI_CLK_EDGE_SINGLE_DOWN,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GBGB},
    /* Disable Isp */
     HI_FALSE,     
    {
        VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_NORM_PULSE,VI_VSYNC_VALID_NEG_HIGH,
        {0,            1920,        0,
         0,            1080,        0,
         0,            0,            0}
    },
    {
        BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stAltasenseAttr =
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_TRUE,     
    {
    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
    {0,            1920,        0,
     0,            1080,        0,
     0,            0,            0}
    },
    {
     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};

VI_DEV_ATTR_S stImx036Attr =
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_RGRG},
    /* Disable Isp */
     HI_TRUE,     
    {
    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
    {0,            1920,        0,
     0,            1080,        0,
     0,            0,            0}
    },
    {
     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};



VI_DEV_ATTR_S stMn34041Attr =
{
    VI_MODE_DIGITAL_CAMERA,
    VI_COMBINE_SEPARATE,
    /* The enCompMode should be VI_COMP_MODE_DOUBLE. */
    VI_COMP_MODE_SINGLE,
    /* Config the mask */
    {0xFFF,    0x0},
    VI_CLK_EDGE_SINGLE_UP,
    VI_SCAN_PROGRESSIVE,
    VI_DATA_TYPE_RGB,
    {VI_DATA_SEQ_GRGR},
    /* Disable Isp */
     HI_TRUE,     
    {
    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
    {0,            1920,        0,
     0,            1080,        0,
     0,            0,            0}
    },
    {
     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
    }
};
/*modified by d00181140, VI_CHN_ATTR_S  corresponded to specific sensor to 
avoid  OB pixel in rawdata*/

VI_CHN_ATTR_S stBayerImx036Chn1080PAttr = 
{
    {24,     26,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};

VI_CHN_ATTR_S stBayerImx122Chn1080PAttr = 
{
    {136,     26,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};

VI_CHN_ATTR_S stBayerMn34041Chn1080PAttr = 
{
    {64,     8,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0,
};

VI_CHN_ATTR_S stBayerOv2715Chn1080PAttr = 
{
    {0,     0,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0,
};

VI_CHN_ATTR_S stBayer9p031Chn1080PAttr = 
{
    {0,     0,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};

VI_CHN_ATTR_S stBayerAltasenseChn1080PAttr = 
{
    {128,     46,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};



VI_CHN_ATTR_S stBayerChn1080PAttr = 
{
    {0,     0,     1920,   1080 },  
    VI_CAPSEL_BOTH,
    {1920,  1080},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};


VI_CHN_ATTR_S stBayerChn720PAttr = 
{
    {0,     0,     1280,   720 },  
    VI_CAPSEL_BOTH,
    {1280,  720},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};

VI_CHN_ATTR_S stBayerChn5MAttr = 
{
    {0,     0,     2592,   1944 },  
    VI_CAPSEL_BOTH,
    {2592,  1944},
    PIXEL_FORMAT_YUV_SEMIPLANAR_422,
    0,      0
};

#ifdef SNS_9P031
#define DEV_ATTR           st9p031Attr1080P
#define DEV_BAYER_ATTR     stBayer9p031Attr1080P 
#define CHN_BAYER_ATTR     stBayerChn1080PAttr
#endif     
#ifdef SNS_OV2715
#define DEV_ATTR           stOv2715Attr
#define DEV_BAYER_ATTR     stBayerOv2715Attr
#define CHN_BAYER_ATTR     stBayerOv2715Chn1080PAttr
#endif 
#ifdef SNS_ALTA
#define DEV_ATTR           stAltasenseAttr
#define DEV_BAYER_ATTR     stBayerAltasenseAttr
#define CHN_BAYER_ATTR     stBayerAltasenseChn1080PAttr
#endif 
#ifdef SNS_9P031_5M
#define DEV_ATTR           st9p031Attr5M
#define DEV_BAYER_ATTR     stBayer9p031Attr5M
#define CHN_BAYER_ATTR     stBayerChn5MAttr
#endif
#ifdef SNS_9P031_720P
#define DEV_ATTR           st9p031Attr720P
#define DEV_BAYER_ATTR     stBayer9p031Attr720P
#define CHN_BAYER_ATTR     stBayerChn720PAttr
#endif
#ifdef SNS_9M034
#define DEV_ATTR           st9p031Attr720P
#define DEV_BAYER_ATTR     stBayer9p031Attr720P
#define CHN_BAYER_ATTR     stBayerChn720PAttr
#endif
#ifdef SNS_IMX036
#define DEV_ATTR           stImx036Attr
#define DEV_BAYER_ATTR     stBayerImx036Attr
#define CHN_BAYER_ATTR     stBayerImx036Chn1080PAttr
#endif

#ifdef SNS_IMX122
#define DEV_ATTR           stImx036Attr
#define DEV_BAYER_ATTR     stBayerImx036Attr
#define CHN_BAYER_ATTR     stBayerImx122Chn1080PAttr
#endif

#ifdef SNS_PANSO34041
#define DEV_ATTR           stMn34041Attr
#define DEV_BAYER_ATTR     stBayerImx036Attr
#define CHN_BAYER_ATTR     stBayerImx036Chn1080PAttr
#endif
#ifdef SNS_AR0331
#define DEV_ATTR           st9p031Attr1080P
#define DEV_BAYER_ATTR     stBayer9p031Attr1080P
#define CHN_BAYER_ATTR     stBayerChn1080PAttr
#endif

/* default */
#ifndef DEV_BAYER_ATTR
#define DEV_ATTR           st9p031Attr1080P
#define DEV_BAYER_ATTR     stBayer9p031Attr1080P
#define CHN_BAYER_ATTR     stBayerChn1080PAttr
#endif

void sample_bayer_dump(VIDEO_FRAME_S * pVBuf, HI_U32 u32Nbit, FILE *pfd)
{
    unsigned int w, h;
    HI_U8* pVBufVirt_Y;
    HI_U8* pVBufVirt_C;
    HI_U8  au8Data[2000];
    HI_U16 au16Data[2000];
    HI_U32 phy_addr,size, phy_addr2;
    HI_U8* pUserPageAddr[2];
    
    if (PIXEL_FORMAT_YUV_SEMIPLANAR_420 == pVBuf->enPixelFormat)
    {
        printf("Err! Bayer data can't be 420\n");
        return;
    }    
    
    size = (pVBuf->u32Stride[0])*(pVBuf->u32Height)*2; 
        
    phy_addr = pVBuf->u32PhyAddr[0];
    phy_addr2 = phy_addr+ 0x1fa400;

   fprintf(stderr, "the phy_addr is: 0x%x 0x%x \n", phy_addr,phy_addr2);
   

    pUserPageAddr[0] = (HI_U8 *) HI_MPI_SYS_Mmap(phy_addr, size);    
    if (NULL == pUserPageAddr[0])
    {
        return;
    }
    
    pVBufVirt_Y = pUserPageAddr[0]; 
    pVBufVirt_C = pVBufVirt_Y + (pVBuf->u32Stride[0])*(pVBuf->u32Height);

    fprintf(stderr, "the pvbufvirt_Y addr is: 0x%x \n", (HI_U32)pVBufVirt_Y);
    fprintf(stderr, "the pVBufVirt_C addr is: 0x%x \n", (HI_U32)pVBufVirt_C);
    

    /* save Y ----------------------------------------------------------------*/
    fprintf(stderr, "saving......Y......");
    fprintf(stderr, "saving......Raw data......");
    fflush(stderr);
    for(h=0; h<pVBuf->u32Height; h++)
    {
        HI_U16 u16Data;
        for (w=0; w<pVBuf->u32Width; w++)
        {
            if (8 == u32Nbit)
            {
                au8Data[w] = pVBufVirt_Y[h*pVBuf->u32Width + w];
            }
            else if (10 == u32Nbit)
            {
                u16Data = (pVBufVirt_Y[h*pVBuf->u32Width + w] & 0x00ff);
                u16Data = ((u16Data << 2) | ((pVBufVirt_C[h*pVBuf->u32Width + w] & 0xC0) >> 6));
                au16Data[w] = u16Data;
            }
            else if (12 == u32Nbit)
            {
                u16Data = (pVBufVirt_Y[h*pVBuf->u32Width + w] & 0x00ff);
             //   u16Data = ((u16Data << 4) | ((pVBufVirt_C[h*pVBuf->u32Width + w] & 0xF0) >> 4));
                u16Data = ((u16Data << 8) | ((pVBufVirt_C[h*pVBuf->u32Width + w] & 0x00ff)) );
                au16Data[w] = u16Data;
            }

           else if(16 == u32Nbit)
 	   {
                u16Data = (pVBufVirt_Y[h*pVBuf->u32Width + w] & 0x00ff);
            //   u16Data = ((u16Data << 4) | ((pVBufVirt_C[h*pVBuf->u32Width + w] & 0xF0) >> 4));
                u16Data = ((u16Data << 8) | ((pVBufVirt_C[h*pVBuf->u32Width + w] & 0x00ff)) );
                au16Data[w] = u16Data;
            }
            else
            {
                printf("Err! Bayer data can't support %d bits!eg: 8bits;10bits;12bits.\n", u32Nbit);
                return;
            }            
        }

        if (8 == u32Nbit)
        {
            fwrite(au8Data, pVBuf->u32Width, 1, pfd);
        }
        else
        {
            fwrite(au16Data, pVBuf->u32Width, 2, pfd);
        }
        
    }
    fflush(pfd);
    
    fprintf(stderr, "done %d!\n", pVBuf->u32TimeRef);
    fflush(stderr);
    
    HI_MPI_SYS_Munmap(pUserPageAddr[0], size); 
}

void* Proc_Isp(void *param)
{  
    /* Run loop, exit until HI_MPI_ISP_Exit() been called! */
    HI_MPI_ISP_Run();

    return NULL;
}

HI_S32 VIStartIspThrd(void)
{
    /* 8. isp create running thread                                            */
    if (0 != pthread_create(&isp_pid, 0, Proc_Isp, NULL))
    {
        printf("create isp running thread failed!\n");
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}

HI_S32 VIIspSensorInit(void)
{
    HI_S32 s32Ret;

    /* 1. sensor init */
    sensor_init();

    /* 2. sensor register callback */
    s32Ret = sensor_register_callback();
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: sensor_register_callback failed with %#x!\n", \
               __FUNCTION__, s32Ret);
        return s32Ret;
    }
    return HI_SUCCESS;
}

HI_S32 VIIspInit(void)
{
    HI_S32 s32Ret;
    ISP_IMAGE_ATTR_S stImageAttr;
    ISP_INPUT_TIMING_S stInputTiming;

    /* 1. isp init */
    s32Ret = HI_MPI_ISP_Init();
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_Init failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 2. isp set image attributes */
    /* note : different sensor, different ISP_IMAGE_ATTR_S define.
      if the sensor you used is different, you can change 
      ISP_IMAGE_ATTR_S definition */
    stImageAttr.enBayer         = BAYER_GRBG;
    stImageAttr.u16FrameRate     = 30;
    stImageAttr.u16Width         = 1920;
    stImageAttr.u16Height         = 1080;
#ifdef SNS_9P031_5M
    stImageAttr.u16FrameRate     = 14;
    stImageAttr.u16Width         = 2592;
    stImageAttr.u16Height         = 1944;
#endif
#ifdef SNS_9P031_720P
    stImageAttr.u16FrameRate     = 60;
    stImageAttr.u16Width         = 1280;
    stImageAttr.u16Height         = 720;
#endif
#ifdef SNS_9M034
    stImageAttr.u16FrameRate    = 60;
    stImageAttr.u16Width        = 1280;
    stImageAttr.u16Height       = 720;
#endif
#ifdef SNS_IMX036
    stImageAttr.enBayer         = BAYER_RGGB;
#endif
#ifdef SNS_IMX122
    stImageAttr.enBayer         = BAYER_RGGB;
#endif
    s32Ret = HI_MPI_ISP_SetImageAttr(&stImageAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_SetImageAttr failed with %#x!\n", __FUNCTION__, s32Ret);
        return s32Ret;
    }

    /* 3. isp set timing */
#ifdef SNS_9P031    
    stInputTiming.enWndMode = ISP_WIND_NONE;
#endif
#ifdef SNS_OV2715
    stInputTiming.enWndMode = ISP_WIND_NONE;
#endif
#ifdef SNS_PANSO34041
    stInputTiming.enWndMode = ISP_WIND_ALL;
    stInputTiming.u16HorWndStart  = 60 ;
    stInputTiming.u16HorWndLength = 1930 ;
    stInputTiming.u16VerWndStart  = 20 ;
    stInputTiming.u16VerWndLength = 1090 ;
#endif
#ifdef SNS_ALTA
    stInputTiming.enWndMode = ISP_WIND_ALL;
    stInputTiming.u16HorWndStart  = 141;
    stInputTiming.u16HorWndLength = 1930 ;
    stInputTiming.u16VerWndStart  = 45;
    stInputTiming.u16VerWndLength = 1090 ;
#endif
#ifdef SNS_IMX036
    stInputTiming.enWndMode = ISP_WIND_ALL;
    stInputTiming.u16HorWndStart  = 200 ;
    stInputTiming.u16HorWndLength = 1920 ;
    stInputTiming.u16VerWndStart  = 12 ;
    stInputTiming.u16VerWndLength = 1080 ;
#endif
#ifdef SNS_IMX122
    stInputTiming.enWndMode = ISP_WIND_ALL;
    stInputTiming.u16HorWndStart  = 200 ;
    stInputTiming.u16HorWndLength = 1920 ;
    stInputTiming.u16VerWndStart  = 12 ;
    stInputTiming.u16VerWndLength = 1080 ;
#endif
#ifdef SNS_9M034
    stInputTiming.enWndMode = ISP_WIND_NONE;
#endif
#ifdef SNS_AR0331
	stInputTiming.enWndMode = ISP_WIND_NONE;
#endif

    s32Ret = HI_MPI_ISP_SetInputTiming(&stInputTiming);    
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_SetInputTiming failed with %#x!\n", __FUNCTION__, s32Ret);
        return s32Ret;
    }
    
    return HI_SUCCESS;
}

HI_S32 VIStopIsp()
{
    /* 11. isp exit and main programme exit                                    */
    printf("Isp will exit!\n");
    HI_MPI_ISP_Exit();
    pthread_join(isp_pid, 0);

    return 0;
}

HI_S32 ViDumpBayer(VI_CHN ViChn, HI_U32 u32Nbit, HI_U32 u32Cnt)
{    
    int i, j;
    VI_FRAME_INFO_S stFrame;
    VI_FRAME_INFO_S astFrame[MAX_FRM_CNT];
    HI_CHAR szYuvName[128];
    FILE *pfd;  
    
    printf("\nNOTICE: This tool only can be used for TESTING !!!\n");
    printf("usage: ./vi_bayerdump [nbit] [frmcnt]. sample: ./vi_dump 10 5\n\n");

    if (HI_MPI_VI_SetFrameDepth(ViChn, 1))
    {        
        printf("HI_MPI_VI_SetFrameDepth err, vi chn %d \n", ViChn);
        return -1;
    }

    usleep(5000);
    
    if (HI_MPI_VI_GetFrame(ViChn, &stFrame))
    {        
        printf("HI_MPI_VI_GetFrame err, vi chn %d \n", ViChn);
        return -1;
    } 
    
    /* make file name */
    sprintf(szYuvName, "./vi_chn_%d_%d_%d_%d.raw", ViChn,
        stFrame.stVFrmInfo.stVFrame.u32Width, stFrame.stVFrmInfo.stVFrame.u32Height,u32Cnt);        
    printf("Dump YUV frame of vi chn %d  to file: \"%s\"\n", ViChn, szYuvName);
    
    /* open file */
    pfd = fopen(szYuvName, "wb");    
    if (NULL == pfd)
    {
        return -1;
    }
    
    /* get VI frame  */    
    for (i=0; i<u32Cnt; i++)
    {        
        if (HI_MPI_VI_GetFrame(ViChn, &astFrame[i])<0)
        {        
            printf("get vi chn %d frame err\n", ViChn);
            printf("only get %d frame\n", i);
            break;
        }
    }
        
    for(j=0; j<i; j++)
    {     
        /* save VI frame to file */
        sample_bayer_dump(&astFrame[j].stVFrmInfo.stVFrame, u32Nbit, pfd);
        
        /* release frame after using */
        HI_MPI_VI_ReleaseFrame(ViChn, &astFrame[j]);    
    }
   
    fclose(pfd);
    HI_MPI_VI_ReleaseFrame(ViChn, &stFrame);     
    
    return 0;
}

int InitMpp()
{
    MPP_SYS_CONF_S stSysConf = {0};
    VB_CONF_S stVbConf ={0};

    HI_MPI_SYS_Exit();
    HI_MPI_VB_Exit();
    stVbConf.astCommPool[0].u32BlkSize = 1920*1088*2;
    stVbConf.astCommPool[0].u32BlkCnt =30;
#ifdef SNS_9P031_5M
    stVbConf.astCommPool[0].u32BlkSize = 2624*1944*2;
    stVbConf.astCommPool[0].u32BlkCnt = 10;
#endif
#ifdef SNS_9P031_720P
    stVbConf.astCommPool[0].u32BlkSize = 1280*720*2;
    stVbConf.astCommPool[0].u32BlkCnt = 40;
#endif
#ifdef SNS_9M034
    stVbConf.astCommPool[0].u32BlkSize = 1280*720*2;
    stVbConf.astCommPool[0].u32BlkCnt = 40;
#endif
    
    if ( HI_MPI_VB_SetConf(&stVbConf))
    {
        printf("HI_MPI_VB_SetConf failed!\n");
        return HI_FAILURE;
    }

    if(HI_MPI_VB_Init())
    {
        printf("InitMpp HI_MPI_VB_Init failed!\n");
        return HI_SUCCESS;
    }

    stSysConf.u32AlignWidth = 16;
    if ( HI_MPI_SYS_SetConf(&stSysConf))
    {
        printf("conf : system config failed!\n");
        return HI_SUCCESS;
    }
    
    if (HI_MPI_SYS_Init())
    {
        printf("sys init failed!\n");
        return HI_SUCCESS;
    }
    return HI_SUCCESS;   
}

HI_S32 StartBayerData(VI_DEV_ATTR_S *pstDevAttr, VI_DEV_ATTR_S *pstBayerDevAttr, 
    VI_DEV_EX_ATTR_S *pstExDevAttr, VI_CHN_ATTR_S *pstChnAttr)
{
    HI_S32 s32Ret = 0;
    VI_CHN_BIND_ATTR_S stChnBind;

    VIIspSensorInit();

    s32Ret = HI_MPI_VI_SetDevAttr(0, pstDevAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_SetDevAttr failed!\n");
        return s32Ret;
    }
    
    s32Ret = HI_MPI_VI_EnableDev(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableDev failed!\n");
        return s32Ret;
    }

    VIIspInit();
    VIStartIspThrd();

    stChnBind.enBindType = VI_CHN_BIND_PHYCHN;
    stChnBind.unBindAttr.stBindPhyChn.s32PhyChn = 0;
    stChnBind.unBindAttr.stBindPhyChn.ViDev = 0;
    stChnBind.unBindAttr.stBindPhyChn.ViWay = 0;
    s32Ret = HI_MPI_VI_ChnBind(0,&stChnBind);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_ChnBind failed!\n");
        return s32Ret;
    }
    
    s32Ret = HI_MPI_VI_SetChnAttr(0, pstChnAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_SetChnAttr failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_EnableChn(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableChn failed!\n");
        return s32Ret;
    }

    printf("wait isp adjust\n");
   getchar();
 //  sleep(3);

    //HI_MPI_ISP_Exit();
    //pthread_join(isp_pid, 0);

    s32Ret = HI_MPI_VI_DisableChn(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableChn failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_ChnUnBind(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_ChnBind failed!\n");
        return s32Ret;
    }
    
    s32Ret = HI_MPI_VI_DisableDev(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableDev failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_SetDevAttr(0, pstBayerDevAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_SetDevAttr failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_SetDevExAttr(0, pstExDevAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_SetDevExAttr failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_EnableDev(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableDev failed!\n");
        return s32Ret;
    }

    stChnBind.enBindType = VI_CHN_BIND_PHYCHN;
    stChnBind.unBindAttr.stBindPhyChn.s32PhyChn = 0;
    stChnBind.unBindAttr.stBindPhyChn.ViDev = 0;
    stChnBind.unBindAttr.stBindPhyChn.ViWay = 0;
    s32Ret = HI_MPI_VI_ChnBind(0,&stChnBind);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_ChnBind failed!\n");
        return s32Ret;
    }
    
    s32Ret = HI_MPI_VI_SetChnAttr(0, pstChnAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_SetChnAttr failed!\n");
        return s32Ret;
    }

    s32Ret = HI_MPI_VI_EnableChn(0);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VI_EnableChn failed!\n");
        return s32Ret;
    }
    
    //VIStartIspThrd();
    
    return HI_SUCCESS;
}


HI_S32 main(int argc, char *argv[])
{     
    HI_S32 s32Ret = 0;
    HI_U32 u32Nbit = 8;
    HI_U32 u32FrmCnt = 1;
    VI_DEV_EX_ATTR_S  stDevExAttr;    
    
    HI_MPI_SYS_Exit();
    HI_MPI_VB_Exit();

    s32Ret = InitMpp();
    if (HI_SUCCESS != s32Ret)
    {
        printf("Init Mpp failed!\n");
        return s32Ret;
    }    

    if (argc > 1)
    {
        u32Nbit = atoi(argv[1]);    /* nbit of Raw data:8bit;10bit;12bit */
    }
    if (argc > 2)
    {
        u32FrmCnt = atoi(argv[2]);/* the frame number */
    }
    
    stDevExAttr.bCdsEn = HI_FALSE;
    stDevExAttr.bCscEn = HI_FALSE;
    stDevExAttr.enDsacMode = DSAC_MODE_CUT_OFF;

    s32Ret = StartBayerData(&DEV_ATTR, &DEV_BAYER_ATTR, &stDevExAttr, &CHN_BAYER_ATTR);
    if (HI_SUCCESS != s32Ret)
    {
        printf("StartBayerData failed!\n");
        return s32Ret;
    } 

    s32Ret = ViDumpBayer(0, u32Nbit, u32FrmCnt);
    if (HI_SUCCESS != s32Ret)
    {
        printf("StartBayerData failed!\n");
        return s32Ret;
    }

    VIStopIsp();
    HI_MPI_SYS_Exit();
    HI_MPI_VB_Exit();

    return HI_SUCCESS;
}



