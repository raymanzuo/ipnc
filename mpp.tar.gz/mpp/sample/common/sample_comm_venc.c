/******************************************************************************
  Some simple Hisilicon HI3516 video encode functions.

  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#include "sample_comm.h"
 
const HI_U8 g_SOI[2] = {0xFF, 0xD8};
const HI_U8 g_EOI[2] = {0xFF, 0xD9};
static pthread_t gs_VencPid;
static SAMPLE_VENC_GETSTREAM_PARA_S gs_stPara;
static HI_S32 gs_s32SnapCnt = 0;
VENC_CHN g_StartVencChn = 0;

/******************************************************************************
* funciton : get file postfix according palyload_type.
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_GetFilePostfix(PAYLOAD_TYPE_E enPayload, char *szFilePostfix)
{
    if (PT_H264 == enPayload)
    {
        strcpy(szFilePostfix, ".h264");
    }
    else if (PT_JPEG == enPayload)
    {
        strcpy(szFilePostfix, ".jpg");
    }
    else if (PT_MJPEG == enPayload)
    {
        strcpy(szFilePostfix, ".mjp");
    }
    else if (PT_MP4VIDEO == enPayload)
    {
        strcpy(szFilePostfix, ".mp4");
    }
    else
    {
        printf("payload type err!\n");
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}

/******************************************************************************
* funciton : save mjpeg stream
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SaveMJpeg(FILE* fpJpegFile, VENC_STREAM_S *pstStream)
{
    VENC_PACK_S*  pstData;
    HI_U32 i;

    fwrite(g_SOI, 1, sizeof(g_SOI), fpJpegFile);

    for (i = 0; i < pstStream->u32PackCount; i++)
    {
        pstData = &pstStream->pstPack[i];
        fwrite(pstData->pu8Addr[0], pstData->u32Len[0], 1, fpJpegFile);
        fwrite(pstData->pu8Addr[1], pstData->u32Len[1], 1, fpJpegFile);
    }

    fwrite(g_EOI, 1, sizeof(g_EOI), fpJpegFile);

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : save H264 stream
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SaveH264(FILE* fpH264File, VENC_STREAM_S *pstStream)
{
    HI_S32 i;

    
    for (i = 0; i < pstStream->u32PackCount; i++)
    {
        fwrite(pstStream->pstPack[i].pu8Addr[0],
               pstStream->pstPack[i].u32Len[0], 1, fpH264File);

        fflush(fpH264File);

        if (pstStream->pstPack[i].u32Len[1] > 0)
        {
            fwrite(pstStream->pstPack[i].pu8Addr[1],
                   pstStream->pstPack[i].u32Len[1], 1, fpH264File);

            fflush(fpH264File);
        }
    }
    

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : save jpeg stream
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SaveJPEG(FILE *fpJpegFile, VENC_STREAM_S *pstStream)
{
    VENC_PACK_S*  pstData;
    HI_U32 i;

    for (i = 0; i < pstStream->u32PackCount; i++)
    {
        pstData = &pstStream->pstPack[i];
        fwrite(pstData->pu8Addr[0], pstData->u32Len[0], 1, fpJpegFile);
        fwrite(pstData->pu8Addr[1], pstData->u32Len[1], 1, fpJpegFile);
    }

    return HI_SUCCESS;
}
/******************************************************************************
* funciton : save snap stream
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SaveSnap(VENC_STREAM_S *pstStream)
{
    char acFile[128]  = {0};
    FILE *pFile;
    HI_S32 s32Ret;

    sprintf(acFile, "snap_%d.jpg", gs_s32SnapCnt);
    pFile = fopen(acFile, "wb");
    if (pFile == NULL)
    {
        printf("open file err\n");
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_VENC_SaveJPEG(pFile, pstStream);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: save snap picture failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }
    fclose(pFile);
    gs_s32SnapCnt++;
    return HI_SUCCESS;
}

/******************************************************************************
* funciton : save stream
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SaveStream(PAYLOAD_TYPE_E enType,FILE *pFd, VENC_STREAM_S *pstStream)
{
    HI_S32 s32Ret;

    if (PT_H264 == enType || PT_MP4VIDEO)
    {
        s32Ret = SAMPLE_COMM_VENC_SaveH264(pFd, pstStream);
    }
    else if (PT_MJPEG == enType)
    {
        s32Ret = SAMPLE_COMM_VENC_SaveMJpeg(pFd, pstStream);
    }
    else
    {
        return HI_FAILURE;
    }
    return s32Ret;
}


/******************************************************************************
* funciton : Start venc snap mode 
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SnapStart(VENC_CHN VencChn, VI_CHN ViChn, PIC_SIZE_E enSize)
{
    HI_S32 s32Ret;
    VENC_GRP VencGrp = VencChn;
    VENC_CHN_ATTR_S stVencChnAttr;
    SIZE_S stPicSize;
    VENC_ATTR_JPEG_S stJpegAttr;

    s32Ret = SAMPLE_COMM_SYS_GetPicSize(SAMPLE_GLOBAL_NORM, enSize, &stPicSize);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Get picture size failed!\n", __FUNCTION__);
        return HI_FAILURE;        
    }
    /******************************************
     step 1: Greate Venc Group
    ******************************************/
    s32Ret = HI_MPI_VENC_CreateGroup(VencGrp);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_CreateGroup[%d] failed with %#x!\n",\
                 __FUNCTION__, VencGrp, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 2:  Create Venc Channel
    ******************************************/
    stVencChnAttr.stVeAttr.enType = PT_JPEG;
    stJpegAttr.u32PicWidth  = stPicSize.u32Width;
    stJpegAttr.u32PicHeight = stPicSize.u32Height;
    stJpegAttr.u32BufSize = stPicSize.u32Width * stPicSize.u32Height * 2;
    stJpegAttr.bByFrame = HI_TRUE;/*get stream mode is field mode  or frame mode*/
    stJpegAttr.bVIField = HI_FALSE;/*the sign of the VI picture is field or frame?*/
    stJpegAttr.u32Priority = 0;/*channels precedence level*/
    memcpy(&stVencChnAttr.stVeAttr.stAttrJpeg, &stJpegAttr, sizeof(VENC_ATTR_JPEG_S));

    s32Ret = HI_MPI_VENC_CreateChn(VencChn, &stVencChnAttr, HI_NULL);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_CreateChn [%d] faild with %#x!\n",\
                __FUNCTION__, VencChn, s32Ret);
        return s32Ret;
    }
    return HI_SUCCESS;
}

/******************************************************************************
* funciton : Stop venc ( snap mode )
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_SnapStop(VENC_CHN VencChn)
{
    HI_S32 s32Ret;
    VENC_GRP VencGrp = VencChn;

    /******************************************
     step 4:  Distroy Venc Channel
    ******************************************/
    s32Ret = HI_MPI_VENC_DestroyChn(VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_DestroyChn vechn[%d] failed with %#x!\n", __FUNCTION__,\
               VencChn, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 5:  Distroy Venc Group
    ******************************************/
    s32Ret = HI_MPI_VENC_DestroyGroup(VencGrp);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_DestroyGroup group[%d] failed with %#x!\n",\
               __FUNCTION__, VencGrp, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}


/******************************************************************************
* funciton : Start venc stream mode (h264, mjpeg)
* note      : rate control parameter need adjust, according your case.
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_StreamStart(VENC_CHN VencChn, VI_CHN ViChn, 
                                                   PAYLOAD_TYPE_E enType, PIC_SIZE_E enSize,
                                                   HI_BOOL bVppEnable, SAMPLE_RC_E enRcMode)
{
    HI_S32 s32Ret;
    VENC_GRP VencGrp = VencChn;
    VENC_CHN_ATTR_S stVencChnAttr;
    VENC_ATTR_H264_S stH264Attr;
    VENC_ATTR_H264_CBR_S    stH264Cbr;
    VENC_ATTR_H264_VBR_S    stH264Vbr;
    VENC_ATTR_H264_FIXQP_S  stH264FixQp;
    VENC_ATTR_MJPEG_S stMjpegAttr;
    VENC_ATTR_MJPEG_FIXQP_S stMjpegeFixQp;
    VENC_ATTR_MPEG4_S stMpeg4Attr;
    VENC_ATTR_MPEG4_CBR_S   stMpeg4Cbr;
    VENC_ATTR_MPEG4_FIXQP_S stMpeg4FixQp;
    VENC_ATTR_MPEG4_VBR_S   stMpeg4Vbr;
    SIZE_S stPicSize;
    VENC_ATTR_JPEG_S stJpegAttr;
    MPP_CHN_S stSrcChn, stDestChn;
    GROUP_VPP_CFG_S stVencGrpVppCfg;

    s32Ret = SAMPLE_COMM_SYS_GetPicSize(SAMPLE_GLOBAL_NORM, enSize, &stPicSize);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Get picture size failed!\n", __FUNCTION__);
        return HI_FAILURE;        
    }
    /******************************************
     step 1: Greate Venc Group
    ******************************************/
    s32Ret = HI_MPI_VENC_CreateGroup(VencGrp);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_CreateGroup[%d] failed with %#x!\n",\
                 __FUNCTION__, VencGrp, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 2:  Create Venc Channel
    ******************************************/
    stVencChnAttr.stVeAttr.enType = enType;
    switch(enType)
    {
        case PT_H264:
        {
            stH264Attr.u32PicWidth = stPicSize.u32Width;/*the picture width*/
            stH264Attr.u32PicHeight = stPicSize.u32Height;/*the picture height*/
            stH264Attr.u32BufSize  = stPicSize.u32Width * stPicSize.u32Height * 2;/*stream buffer size*/
            stH264Attr.u32Profile  = 2;/*0: baseline; 1:MP; 2:HP   ? */
            stH264Attr.bByFrame = HI_TRUE;/*get stream mode is slice mode or frame mode?*/
            stH264Attr.bField = HI_FALSE;  /* surpport frame code only for hi3516, bfield = HI_FALSE */
            stH264Attr.bMainStream = HI_TRUE; /* surpport main stream only for hi3516, bMainStream = HI_TRUE */
            stH264Attr.u32Priority = 0; /*channels precedence level. invalidate for hi3516*/
            stH264Attr.bVIField = HI_FALSE;/*the sign of the VI picture is field or frame. Invalidate for hi3516*/
            memcpy(&stVencChnAttr.stVeAttr.stAttrH264e, &stH264Attr, sizeof(VENC_ATTR_H264_S));

            if(SAMPLE_RC_CBR == enRcMode)
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_H264CBR;
                stH264Cbr.u32Gop            = 30;
                stH264Cbr.u32StatTime       = 1; /* stream rate statics time(s) */
                stH264Cbr.u32ViFrmRate      = 30;/* input (vi) frame rate */
                stH264Cbr.fr32TargetFrmRate = 30;/* target frame rate */
                switch (enSize)
                {
                  case PIC_QCIF:
                	   stH264Cbr.u32BitRate = 256; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:	
                  case PIC_480H:
                	   stH264Cbr.u32BitRate = 512;
                       break;
                  case PIC_960H:
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                	   stH264Cbr.u32BitRate = 1024*2;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stH264Cbr.u32BitRate = 1024*3;
                	   break;
                  case PIC_HD1080:  /* 1920 * 1080 */
                  	   stH264Cbr.u32BitRate = 1024*6;
                	   break;
                  default :
                       stH264Cbr.u32BitRate = 1024*4;
                       break;
                }
                
                stH264Cbr.u32FluctuateLevel = 0; /* average bit rate */
                memcpy(&stVencChnAttr.stRcAttr.stAttrH264Cbr, &stH264Cbr, sizeof(VENC_ATTR_H264_CBR_S));
            }
            else if (SAMPLE_RC_FIXQP == enRcMode) 
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_H264FIXQP;
                stH264FixQp.u32Gop = 30;
                stH264FixQp.u32ViFrmRate = 30;
                stH264FixQp.fr32TargetFrmRate = 30;
                stH264FixQp.u32IQp = 20;
                stH264FixQp.u32PQp = 23;
                memcpy(&stVencChnAttr.stRcAttr.stAttrH264FixQp, &stH264FixQp,sizeof(VENC_ATTR_H264_FIXQP_S));
            }
            else if (SAMPLE_RC_VBR == enRcMode) 
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_H264VBR;
                stH264Vbr.u32Gop = 30;
                stH264Vbr.u32StatTime = 1;
                stH264Vbr.u32ViFrmRate = 30;
                stH264Vbr.fr32TargetFrmRate = 30;
                stH264Vbr.u32MinQp = 24;
                stH264Vbr.u32MaxQp = 32;
                switch (enSize)
                {
                  case PIC_QCIF:
                	   stH264Vbr.u32MaxBitRate= 256*3; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:
                  case PIC_480H:
                	   stH264Vbr.u32MaxBitRate = 512*3;
                       break;
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                  case PIC_960H:
                	   stH264Vbr.u32MaxBitRate = 1024*2*3;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stH264Vbr.u32MaxBitRate = 1024*3*3;
                	   break;
                  case PIC_HD1080:  /* 1920 * 1080 */
                  	   stH264Vbr.u32MaxBitRate = 1024*6*3;
                	   break;
                  default :
                       stH264Vbr.u32MaxBitRate = 1024*4*3;
                       break;
                }
                memcpy(&stVencChnAttr.stRcAttr.stAttrH264Vbr, &stH264Vbr, sizeof(VENC_ATTR_H264_VBR_S));
            }
            else
            {
                return HI_FAILURE;
            }
        }
        break;


        case PT_MP4VIDEO:
        {
            stMpeg4Attr.u32PicWidth = stPicSize.u32Width;/*the picture width*/
            stMpeg4Attr.u32PicHeight = stPicSize.u32Height;/*the picture height*/
            stMpeg4Attr.u32BufSize  = stPicSize.u32Width * stPicSize.u32Height * 2;/*stream buffer size*/
            stMpeg4Attr.bByFrame = HI_TRUE;/*get stream mode is slice mode or frame mode?*/
            stMpeg4Attr.bField = HI_FALSE;  /* surpport frame code only for hi3516, bfield = HI_FALSE */
            stMpeg4Attr.bMainStream = HI_TRUE; /* surpport main stream only for hi3516, bMainStream = HI_TRUE */
            stMpeg4Attr.u32Priority = 0; /*channels precedence level. invalidate for hi3516*/
            stMpeg4Attr.bVIField = HI_FALSE;/*the sign of the VI picture is field or frame. Invalidate for hi3516*/
            memcpy(&stVencChnAttr.stVeAttr.stAttrMpeg4, &stMpeg4Attr, sizeof(VENC_ATTR_MPEG4_S));

            if(SAMPLE_RC_CBR == enRcMode)
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MPEG4CBR;
                stMpeg4Cbr.u32Gop            = 30;
                stMpeg4Cbr.u32StatTime       = 1; /* stream rate statics time(s) */
                stMpeg4Cbr.u32ViFrmRate      = 30;/* input (vi) frame rate */
                stMpeg4Cbr.fr32TargetFrmRate = 30;/* target frame rate */
                stMpeg4Cbr.u32FluctuateLevel = 0; 

                switch (enSize)
                {
                  case PIC_QCIF:
                	   stMpeg4Cbr.u32BitRate = 256; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:	
                  case PIC_480H:
                	   stMpeg4Cbr.u32BitRate = 512;
                       break;
                  case PIC_960H:
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                	   stMpeg4Cbr.u32BitRate = 1024*2;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stMpeg4Cbr.u32BitRate = 1024*4;
                	   break;
                  default :
                       stH264Cbr.u32BitRate = 1024*4;
                       break;
                }
                
                memcpy(&stVencChnAttr.stRcAttr.stAttrMpeg4Cbr, &stMpeg4Cbr, sizeof(VENC_ATTR_MPEG4_CBR_S));
            }
            else if (SAMPLE_RC_FIXQP == enRcMode) 
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MPEG4FIXQP;
                stMpeg4FixQp.u32Gop = 30;
                stMpeg4FixQp.u32ViFrmRate = 30;
                stMpeg4FixQp.fr32TargetFrmRate = 30;
                stMpeg4FixQp.u32IQp = 5;
                stMpeg4FixQp.u32PQp = 6;
                memcpy(&stVencChnAttr.stRcAttr.stAttrMpeg4FixQp, &stMpeg4FixQp,sizeof(VENC_ATTR_MPEG4_FIXQP_S));
            }
            else if (SAMPLE_RC_VBR == enRcMode) 
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MPEG4VBR;
                stMpeg4Vbr.u32Gop = 30;
                stMpeg4Vbr.u32StatTime = 1;
                stMpeg4Vbr.u32ViFrmRate = 30;
                stMpeg4Vbr.fr32TargetFrmRate = 30;
                stMpeg4Vbr.u32MinQp = 1;
                stMpeg4Vbr.u32MaxQp = 20;
                switch (enSize)
                {
                  case PIC_QCIF:
                	   stMpeg4Vbr.u32MaxBitRate= 256*3; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:
                  case PIC_480H:
                	   stMpeg4Vbr.u32MaxBitRate = 512*3;
                       break;
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                  case PIC_960H:
                	   stMpeg4Vbr.u32MaxBitRate = 1024*2*3;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stMpeg4Vbr.u32MaxBitRate = 1024*4*3;
                	   break;
                  default :
                       stMpeg4Vbr.u32MaxBitRate = 1024*4*3;
                       break;
                }
                memcpy(&stVencChnAttr.stRcAttr.stAttrMpeg4Vbr, &stMpeg4Vbr, sizeof(VENC_ATTR_MPEG4_VBR_S));
            }
            
            else
            {
                return HI_FAILURE;
            }
        }
        break;
        case PT_MJPEG:
        {
            stMjpegAttr.u32PicWidth = stPicSize.u32Width;
            stMjpegAttr.u32PicHeight = stPicSize.u32Height;
            stMjpegAttr.u32BufSize = stPicSize.u32Width * stPicSize.u32Height * 2;
            stMjpegAttr.bByFrame = HI_TRUE;  /*get stream mode is field mode  or frame mode*/
            stMjpegAttr.bMainStream = HI_TRUE;  /*main stream or minor stream types?*/
            stMjpegAttr.bVIField = HI_FALSE;  /*the sign of the VI picture is field or frame?*/
            stMjpegAttr.u32Priority = 0;/*channels precedence level*/
            memcpy(&stVencChnAttr.stVeAttr.stAttrMjpeg, &stMjpegAttr, sizeof(VENC_ATTR_MJPEG_S));

            if(SAMPLE_RC_FIXQP == enRcMode)
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MJPEGFIXQP;
                stMjpegeFixQp.u32Qfactor        = 90;
                stMjpegeFixQp.u32ViFrmRate      = 30;
                stMjpegeFixQp.fr32TargetFrmRate = 30;
                memcpy(&stVencChnAttr.stRcAttr.stAttrMjpegeFixQp, &stMjpegeFixQp,
                       sizeof(VENC_ATTR_MJPEG_FIXQP_S));
            }
            else if (SAMPLE_RC_CBR == enRcMode)
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MJPEGCBR;
                stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32StatTime       = 1;
                stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32ViFrmRate      = 30;
                stVencChnAttr.stRcAttr.stAttrMjpegeCbr.fr32TargetFrmRate = 15;
                stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32FluctuateLevel = 0;
                switch (enSize)
                {
                  case PIC_QCIF:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 384*3; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:
                  case PIC_480H:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 768*3;
                       break;
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                  case PIC_960H:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 1024*3*3;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 1024*5*3;
                	   break;
                  case PIC_HD1080:  /* 1920 * 1080 */
                  	   stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 1024*10*3;
                	   break;
                  default :
                       stVencChnAttr.stRcAttr.stAttrMjpegeCbr.u32BitRate = 1024*7*3;
                       break;
                }
            }
            else if (SAMPLE_RC_VBR == enRcMode) 
            {
                stVencChnAttr.stRcAttr.enRcMode = VENC_RC_MODE_MJPEGVBR;
                stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32StatTime = 1;
                stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32ViFrmRate = 30;
                stVencChnAttr.stRcAttr.stAttrMjpegeVbr.fr32TargetFrmRate = 5;
                stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MinQfactor = 50;
                stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxQfactor = 95;
                switch (enSize)
                {
                  case PIC_QCIF:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate= 256*3; /* average bit rate */
                	   break;
                  case PIC_QVGA:    /* 320 * 240 */
                  case PIC_CIF:
                  case PIC_480H:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate = 512*3;
                       break;
                  case PIC_D1:
                  case PIC_VGA:	   /* 640 * 480 */
                  case PIC_960H:
                	   stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate = 1024*2*3;
                       break;
                  case PIC_HD720:   /* 1280 * 720 */
                	   stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate = 1024*3*3;
                	   break;
                  case PIC_HD1080:  /* 1920 * 1080 */
                  	   stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate = 1024*6*3;
                	   break;
                  default :
                       stVencChnAttr.stRcAttr.stAttrMjpegeVbr.u32MaxBitRate = 1024*4*3;
                       break;
                }
            }
            else 
            {
                printf("%s: cann't support other mode in this version!\n", 
                       __FUNCTION__);

                return HI_FAILURE;
            }
        }
        break;
            
        case PT_JPEG:
            stJpegAttr.u32PicWidth  = stPicSize.u32Width;
            stJpegAttr.u32PicHeight = stPicSize.u32Height;
            stJpegAttr.u32BufSize = stPicSize.u32Width * stPicSize.u32Height * 2;
            stJpegAttr.bByFrame = HI_TRUE;/*get stream mode is field mode  or frame mode*/
            stJpegAttr.bVIField = HI_FALSE;/*the sign of the VI picture is field or frame?*/
            stJpegAttr.u32Priority = 0;/*channels precedence level*/
            memcpy(&stVencChnAttr.stVeAttr.stAttrMjpeg, &stMjpegAttr, sizeof(VENC_ATTR_MJPEG_S));
            break;
        default:
            return HI_ERR_VENC_NOT_SUPPORT;
    }

    s32Ret = HI_MPI_VENC_CreateChn(VencChn, &stVencChnAttr, HI_NULL);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_CreateChn [%d] faild with %#x!\n",\
                __FUNCTION__, VencChn, s32Ret);
        return s32Ret;
    }

    /******************************************
     step 3:  Regist Venc Channel to VencGrp
    ******************************************/
    s32Ret = HI_MPI_VENC_RegisterChn(VencGrp, VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_RegisterChn faild with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 4:  enable vpp 
    ******************************************/
    if(HI_TRUE == bVppEnable && PT_H264 == enType)
    {
	s32Ret = HI_MPI_VENC_GetVppCfg(VencGrp, &stVencGrpVppCfg);
	if (HI_SUCCESS != s32Ret)
	{
            printf("%s: HI_MPI_VENC_GetVppCfg failed with %#x!\n",\
                   __FUNCTION__, s32Ret);
            return HI_FAILURE;
	}

    stVencGrpVppCfg.stVppCfg.bVppEn  = HI_TRUE;
    stVencGrpVppCfg.stVppCfg.bIencEn = HI_TRUE;
    stVencGrpVppCfg.stVppCfg.bSpEn   = HI_TRUE;
    stVencGrpVppCfg.stVppCfg.bDnEn   = HI_TRUE;    

    stVencGrpVppCfg.stVppCfg.s32SpSth = 0;	   /* SP Strength [-4,5] */
    stVencGrpVppCfg.stVppCfg.s32DnSfCosSth = 2;  /* coarse DN sf Strength [0,3] */
    stVencGrpVppCfg.stVppCfg.s32DnSfIncSth = 128;  /* Inching of DN sf Strength [0,255] */
    stVencGrpVppCfg.stVppCfg.s32DnTfSth= 2;	   /* DN tf Strength [0,4] */
    s32Ret = HI_MPI_VENC_SetVppCfg(VencGrp, &stVencGrpVppCfg);
    if (HI_SUCCESS != s32Ret)
	{
            printf("%s: HI_MPI_VENC_SetVppCfg failed with %#x!\n",\
                   __FUNCTION__, s32Ret);
            return HI_FAILURE;
	}
    }

    /******************************************
     step 5:  Venc Group bind Vi Channel
    ******************************************/
    stSrcChn.enModId = HI_ID_VIU;
    stSrcChn.s32ChnId = ViChn;

    stDestChn.enModId = HI_ID_GROUP;
    stDestChn.s32ChnId = VencGrp;

    s32Ret = HI_MPI_SYS_Bind(&stSrcChn, &stDestChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_RegisterChn failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 6:  Start Recv Venc Pictures
    ******************************************/
    s32Ret = HI_MPI_VENC_StartRecvPic(VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_StartRecvPic faild with%#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;

}

/******************************************************************************
* funciton : Stop venc ( stream mode -- H264, MJPEG )
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_StreamStop(VENC_CHN VencChn)
{
    HI_S32 s32Ret;
    VENC_GRP VencGrp = VencChn;
    MPP_CHN_S stDestChn;

    /******************************************
     step 1:  Stop Recv Pictures
    ******************************************/
    s32Ret = HI_MPI_VENC_StopRecvPic(VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_StopRecvPic vechn[%d] failed with %#x!\n", __FUNCTION__,\
               VencChn, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 2:  Venc Group UnBind Vi Channel
    ******************************************/
    stDestChn.enModId = HI_ID_GROUP;
    stDestChn.s32ChnId = VencGrp;

    s32Ret = HI_MPI_SYS_UnBind(NULL, &stDestChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_SYS_UnBind[%d] failed with %#x!\n", __FUNCTION__,
            VencGrp, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 3:  UnRegist Venc Channel
    ******************************************/
    s32Ret = HI_MPI_VENC_UnRegisterChn(VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_UnRegisterChn vechn[%d] failed with %#x!\n", __FUNCTION__,\
               VencChn, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 4:  Distroy Venc Channel
    ******************************************/
    s32Ret = HI_MPI_VENC_DestroyChn(VencChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_DestroyChn vechn[%d] failed with %#x!\n", __FUNCTION__,\
               VencChn, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 5:  Distroy Venc Group
    ******************************************/
    s32Ret = HI_MPI_VENC_DestroyGroup(VencGrp);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_DestroyGroup group[%d] failed with %#x!\n",\
               __FUNCTION__, VencGrp, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : get snap and save it to file 
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_GetSnapProc(VENC_CHN SnapChn, VI_CHN ViChn, PIC_SIZE_E enSize)
{
    MPP_CHN_S stSrcChn, stDestChn;
    VENC_GRP VencGrp;
    struct timeval TimeoutVal;
    fd_set read_fds;
    HI_S32 s32VencFd;
    VENC_CHN_STAT_S stStat;
    VENC_STREAM_S stStream;
    HI_S32 s32Ret;

    /******************************************
     step 1:  Regist Venc Channel to VencGrp
    ******************************************/
    VencGrp = SnapChn;
    s32Ret = HI_MPI_VENC_RegisterChn(VencGrp, SnapChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_RegisterChn faild with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 2:  Venc Group bind Vi Channel
    ******************************************/
    stSrcChn.enModId = HI_ID_VIU;
    stSrcChn.s32ChnId = ViChn;

    stDestChn.enModId = HI_ID_GROUP;
    stDestChn.s32ChnId = VencGrp;

    s32Ret = HI_MPI_SYS_Bind(&stSrcChn, &stDestChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_RegisterChn failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 3:  Start Recv Venc Pictures
    ******************************************/
    s32Ret = HI_MPI_VENC_StartRecvPic(SnapChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VENC_StartRecvPic faild with%#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

   s32VencFd = HI_MPI_VENC_GetFd(SnapChn);
    if (s32VencFd < 0)
    {
    	 printf("%s: HI_MPI_VENC_GetFd faild with%#x!\n", __FUNCTION__, s32VencFd);
        return HI_FAILURE;
    }

    FD_ZERO(&read_fds);
    FD_SET(s32VencFd, &read_fds);
    
    TimeoutVal.tv_sec  = 2;
    TimeoutVal.tv_usec = 0;
    s32Ret = select(s32VencFd+1, &read_fds, NULL, NULL, &TimeoutVal);
    if (s32Ret < 0) 
    {
        printf("%s: snap select failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }
    else if (0 == s32Ret) 
    {
        printf("%s: snap time out!\n", __FUNCTION__);
        return HI_FAILURE;
    }
    else
    {
        if (FD_ISSET(s32VencFd, &read_fds))
        {
            s32Ret = HI_MPI_VENC_Query(SnapChn, &stStat);
            if (s32Ret != HI_SUCCESS)
            {
                printf("%s: HI_MPI_VENC_Query failed with %#x!\n", __FUNCTION__, s32Ret);
                return HI_FAILURE;
            }

            stStream.pstPack = (VENC_PACK_S*)malloc(sizeof(VENC_PACK_S) * stStat.u32CurPacks);
            if (NULL == stStream.pstPack)
            {
                printf("%s: malloc memory failed!\n", __FUNCTION__);
                return HI_FAILURE;
            }

            stStream.u32PackCount = stStat.u32CurPacks;
            s32Ret = HI_MPI_VENC_GetStream(SnapChn, &stStream, HI_TRUE);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: HI_MPI_VENC_GetStream failed with %#x!\n", __FUNCTION__, s32Ret);
                free(stStream.pstPack);
                stStream.pstPack = NULL;
                return HI_FAILURE;
            }

            s32Ret = SAMPLE_COMM_VENC_SaveSnap(&stStream);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: HI_MPI_VENC_GetStream failed with %#x!\n", __FUNCTION__, s32Ret);
                free(stStream.pstPack);
                stStream.pstPack = NULL;
                return HI_FAILURE;
            }

            s32Ret = HI_MPI_VENC_ReleaseStream(SnapChn, &stStream);
            if (s32Ret)
            {
                printf("%s: HI_MPI_VENC_ReleaseStream failed with %#x!\n", __FUNCTION__, s32Ret);
                free(stStream.pstPack);
                stStream.pstPack = NULL;
                return HI_FAILURE;
            }

            free(stStream.pstPack);
            stStream.pstPack = NULL;
	}
    }
	
    s32Ret = HI_MPI_VENC_StopRecvPic(SnapChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VENC_StopRecvPic failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_SYS_UnBind(NULL, &stDestChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_SYS_UnBind[%d] failed with %#x!\n", __FUNCTION__,
            VencGrp, s32Ret);
        return HI_FAILURE;
    }
	
    s32Ret = HI_MPI_VENC_UnRegisterChn(SnapChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VENC_UnRegisterChn failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    stDestChn.enModId = HI_ID_GROUP;
    stDestChn.s32ChnId = VencGrp;

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : get stream from each channels and save them
******************************************************************************/
HI_VOID* SAMPLE_COMM_VENC_GetVencStreamProc(HI_VOID *p)
{
    HI_S32 i;
    HI_S32 s32ChnTotal;
    VENC_CHN_ATTR_S stVencChnAttr;
    SAMPLE_VENC_GETSTREAM_PARA_S *pstPara;
    HI_S32 maxfd = 0;
    struct timeval TimeoutVal;
    fd_set read_fds;
    HI_S32 VencFd[VENC_MAX_CHN_NUM];
    HI_CHAR aszFileName[VENC_MAX_CHN_NUM][64];
    FILE *pFile[VENC_MAX_CHN_NUM];
    char szFilePostfix[10];
    VENC_CHN_STAT_S stStat;
    VENC_STREAM_S stStream;
    HI_S32 s32Ret;
    VENC_CHN VencChn;
    PAYLOAD_TYPE_E enPayLoadType[5];
    
    pstPara = (SAMPLE_VENC_GETSTREAM_PARA_S*)p;
    s32ChnTotal = pstPara->s32Cnt;

    /******************************************
     step 1:  check & prepare save-file & venc-fd
    ******************************************/
    if (s32ChnTotal > 5)
    {
        printf("%s: input count invaild\n", __FUNCTION__);
        return NULL;
    }
    for (i = g_StartVencChn; i < s32ChnTotal; i++)
    {
        /* decide the stream file name, and open file to save stream */
        VencChn = i;
        s32Ret = HI_MPI_VENC_GetChnAttr(VencChn, &stVencChnAttr);
        if(s32Ret != HI_SUCCESS)
        {
            printf("%s: HI_MPI_VENC_GetChnAttr chn[%d] failed with %#x!\n", \
                   __FUNCTION__, VencChn, s32Ret);
            return NULL;
        }
        enPayLoadType[i] = stVencChnAttr.stVeAttr.enType;

        s32Ret = SAMPLE_COMM_VENC_GetFilePostfix(enPayLoadType[i], szFilePostfix);
        if(s32Ret != HI_SUCCESS)
        {
            printf("%s: SAMPLE_COMM_VENC_GetFilePostfix [%d] failed with %#x!\n", \
                   __FUNCTION__, stVencChnAttr.stVeAttr.enType, s32Ret);
            return NULL;
        }
        sprintf(aszFileName[i], "stream_%s%d%s", "chn", i, szFilePostfix);
        pFile[i] = fopen(aszFileName[i], "wb");
        if (!pFile[i])
        {
            printf("%s: open file[%s] failed!\n", 
                   __FUNCTION__, aszFileName[i]);
            return NULL;
        }

        /* Set Venc Fd. */
        VencFd[i] = HI_MPI_VENC_GetFd(i);
        if (VencFd[i] < 0)
        {
            printf("%s: HI_MPI_VENC_GetFd failed with %#x!\n", 
                   __FUNCTION__, VencFd[i]);
            return NULL;
        }
        if (maxfd <= VencFd[i])
        {
            maxfd = VencFd[i];
        }
    }

    /******************************************
     step 2:  Start to get streams of each channel.
    ******************************************/
    while (HI_TRUE == pstPara->bThreadStart)
    {
        FD_ZERO(&read_fds);
        for (i = g_StartVencChn; i < s32ChnTotal; i++)
        {
            FD_SET(VencFd[i], &read_fds);
        }

        TimeoutVal.tv_sec  = 2;
        TimeoutVal.tv_usec = 0;
        s32Ret = select(maxfd + 1, &read_fds, NULL, NULL, &TimeoutVal);
        if (s32Ret < 0)
        {
            printf("%s: select failed!\n", __FUNCTION__);
            break;
        }
        else if (s32Ret == 0)
        {
            printf("%s: get venc stream time out, exit thread\n", __FUNCTION__);
            break;
        }
        else
        {
            for (i = g_StartVencChn; i < s32ChnTotal; i++)
            {
                if (FD_ISSET(VencFd[i], &read_fds))
                {
                    /*******************************************************
                     step 2.1 : query how many packs in one-frame stream.
                    *******************************************************/
                    memset(&stStream, 0, sizeof(stStream));
                    s32Ret = HI_MPI_VENC_Query(i, &stStat);
                    if (HI_SUCCESS != s32Ret)
                    {
                        printf("%s: HI_MPI_VENC_Query chn[%d] failed with %#x!\n", __FUNCTION__, i, s32Ret);
                        break;
                    }

                    /*******************************************************
                     step 2.2 : malloc corresponding number of pack nodes.
                    *******************************************************/
                    stStream.pstPack = (VENC_PACK_S*)malloc(sizeof(VENC_PACK_S) * stStat.u32CurPacks);
                    if (NULL == stStream.pstPack)
                    {
                        printf("%s: malloc stream pack failed!\n", __FUNCTION__);
                        break;
                    }
                    
                    /*******************************************************
                     step 2.3 : call mpi to get one-frame stream
                    *******************************************************/
                    stStream.u32PackCount = stStat.u32CurPacks;
                    s32Ret = HI_MPI_VENC_GetStream(i, &stStream, HI_TRUE);
                    if (HI_SUCCESS != s32Ret)
                    {
                        free(stStream.pstPack);
                        stStream.pstPack = NULL;
                        printf("%s: HI_MPI_VENC_GetStream failed with %#x!\n", \
                               __FUNCTION__, s32Ret);
                        break;
                    }

                    /*******************************************************
                     step 2.4 : save frame to file
                    *******************************************************/
                    s32Ret = SAMPLE_COMM_VENC_SaveStream(enPayLoadType[i], pFile[i], &stStream);
                    if (HI_SUCCESS != s32Ret)
                    {
                        free(stStream.pstPack);
                        stStream.pstPack = NULL;
                        printf("%s: save stream failed!\n", \
                               __FUNCTION__);
                        break;
                    }
                    /*******************************************************
                     step 2.5 : release stream
                    *******************************************************/
                    s32Ret = HI_MPI_VENC_ReleaseStream(i, &stStream);
                    if (HI_SUCCESS != s32Ret)
                    {
                        free(stStream.pstPack);
                        stStream.pstPack = NULL;
                        break;
                    }
                    /*******************************************************
                     step 2.6 : free pack nodes
                    *******************************************************/
                    free(stStream.pstPack);
                    stStream.pstPack = NULL;
                }
            }
        }
    }

    /*******************************************************
    * step 3 : close save-file
    *******************************************************/
    for (i = g_StartVencChn; i < s32ChnTotal; i++)
    {
        fclose(pFile[i]);
    }

    return NULL;
}

/******************************************************************************
* funciton : start get venc stream process thread
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_StartGetStream(HI_S32 s32Cnt)
{
    gs_stPara.bThreadStart = HI_TRUE;
    gs_stPara.s32Cnt = s32Cnt;

    return pthread_create(&gs_VencPid, 0, SAMPLE_COMM_VENC_GetVencStreamProc, (HI_VOID*)&gs_stPara);
}

/******************************************************************************
* funciton : stop get venc stream process.
******************************************************************************/
HI_S32 SAMPLE_COMM_VENC_StopGetStream()
{
    if (HI_TRUE == gs_stPara.bThreadStart)
    {
        gs_stPara.bThreadStart = HI_FALSE;
        pthread_join(gs_VencPid, 0);
    }
    return HI_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
