/******************************************************************************
  Some simple Hisilicon HI3516 video output functions.

  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/

#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#include "sample_comm.h"

/******************************************************************************
* functon : according vo_intf_sync get picture size. 
******************************************************************************/
HI_S32 SAMPLE_COMM_Vo_GetPicSize(VO_INTF_SYNC_E enIntfSync, SIZE_S *pstPicSize)
{
    switch (enIntfSync)
    {
        case VO_OUTPUT_PAL:
            pstPicSize->u32Width = 704;
            pstPicSize->u32Height = 576;
            break;
        case VO_OUTPUT_NTSC:
            pstPicSize->u32Width = 704;
            pstPicSize->u32Height = 480;
            break;
        case VO_OUTPUT_720P60:
            pstPicSize->u32Width = 1280;
            pstPicSize->u32Height = 720;
            break;
        case VO_OUTPUT_1080I50:
        case VO_OUTPUT_1080I60:
        case VO_OUTPUT_1080P25:
        case VO_OUTPUT_1080P30:
            pstPicSize->u32Width = 1920;
            pstPicSize->u32Height = 1080;
            break;
        case VO_OUTPUT_800x600_60:
        case VO_OUTPUT_800x600_75:
            pstPicSize->u32Width = 800;
            pstPicSize->u32Height = 600;
            break;
        case VO_OUTPUT_1024x768_60:
            pstPicSize->u32Width = 1024;
            pstPicSize->u32Height = 768;
            break;
        case VO_OUTPUT_1280x1024_60:
            pstPicSize->u32Width = 1280;
            pstPicSize->u32Height = 1024;
            break;
        case VO_OUTPUT_1366x768_60:
            pstPicSize->u32Width = 1366;
            pstPicSize->u32Height = 768;
            break;
        case VO_OUTPUT_1440x900_60:
            pstPicSize->u32Width = 1440;
            pstPicSize->u32Height = 900;
            break;
        case VO_OUTPUT_1024x768_75:
            pstPicSize->u32Width = 1024;
            pstPicSize->u32Height = 768;
            break;
        default:
            return HI_FAILURE;
    }
    return HI_SUCCESS;
}

/******************************************************************************
* functon : Star vo. 
                dev : 0 -- (HD) 720p
                dev : 2 -- (SD) CVBS (p/n according sample_common.h macro define )
******************************************************************************/
HI_S32 SAMPLE_COMM_VO_Start(VO_DEV VoDev)
{
    VO_PUB_ATTR_S stPubAttr;
    VO_VIDEO_LAYER_ATTR_S stLayerAttr;
    VO_CHN_ATTR_S stChnAttr;
    VO_CHN VoChn = 0; /* we only use vo chn 0 */
    SIZE_S stPicSize;
    HI_S32 s32Ret;

    HI_MPI_VO_Disable(VoDev);

    /* if dev0(hd)-Bt1120;720p60   if dev1(sd)-cvbs;p||n) */
    stPubAttr.enIntfType = (0==VoDev)? VO_INTF_BT1120: VO_INTF_CVBS;
	
	/*HI_FPGA defined in Makefile.param*/
#ifdef HI_FPGA 
    stPubAttr.enIntfSync = (0==VoDev)? VO_OUTPUT_720P60: SAMPLE_GLOBAL_NORM;
#else
    stPubAttr.enIntfSync = (0==VoDev)? VO_OUTPUT_1080P30: SAMPLE_GLOBAL_NORM;
    if (APTINA_9M034_DC_720P_CONTINUES == SENSOR_TYPE)
    {
        stPubAttr.enIntfSync = (0==VoDev)? VO_OUTPUT_720P60: SAMPLE_GLOBAL_NORM;
    }
#endif
    stPubAttr.u32BgColor = 0xFF0000;

    if (SAMPLE_COMM_Vo_GetPicSize(stPubAttr.enIntfSync, &stPicSize))
    {
        printf("%s: Vo get picture size failed!\n", __FUNCTION__);
        return HI_FAILURE ;
    }
       
    /* Attr of video layer */
    stLayerAttr.stDispRect.s32X      = 0;
    stLayerAttr.stDispRect.s32Y      = 0;
    stLayerAttr.stDispRect.u32Width   = stPicSize.u32Width;
    stLayerAttr.stDispRect.u32Height  = stPicSize.u32Height;

    /* NOTE: ImageSize always is vi chn capture size, but here is a sample process */ 
    stLayerAttr.stImageSize.u32Width  = stPicSize.u32Width;
    stLayerAttr.stImageSize.u32Height = stPicSize.u32Height;
                
    stLayerAttr.u32DispFrmRt        = 30;
    if (APTINA_9M034_DC_720P_CONTINUES == SENSOR_TYPE)
    {
        stLayerAttr.u32DispFrmRt	= 60;
    }
    stLayerAttr.enPixFormat			= SAMPLE_PIXEL_FORMAT;
    stLayerAttr.s32PiPChn			= 0;

    /* Attr of vo chn */    
    stChnAttr.stRect.s32X = 0;
    stChnAttr.stRect.s32Y = 0;
    stChnAttr.stRect.u32Width = stPicSize.u32Width;
    stChnAttr.stRect.u32Height = stPicSize.u32Height;
    stChnAttr.bZoomEnable = HI_TRUE;
    stChnAttr.bDeflicker = HI_FALSE;
    stChnAttr.u32Priority = 1;

    /* set public attr of VO*/
    s32Ret = HI_MPI_VO_SetPubAttr(VoDev, &stPubAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VO_SetPubAttr(dev=%d,IntfType=%d,IntfSync=%d) failed with %#x!\n", __FUNCTION__, VoDev,\
             stPubAttr.enIntfType, stPubAttr.enIntfSync, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_Enable(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VO_Enable failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_SetVideoLayerAttr(VoDev, &stLayerAttr);
    if (HI_SUCCESS != s32Ret )
    {
        printf("%s: HI_MPI_VO_SetVideoLayerAttr failed with %#x!\n", \
               __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_EnableVideoLayer(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VO_EnableVideoLayer failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* set channel attr of VO*/
    s32Ret = HI_MPI_VO_SetChnAttr(VoDev, VoChn, &stChnAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VO_SetChnAttr failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* enable VO channel*/
    s32Ret = HI_MPI_VO_EnableChn(VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VO_EnableChn failed with %#x!\n",\
               __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }
    
    return HI_SUCCESS;
}

/******************************************************************************
* functon : Stop vo
******************************************************************************/
HI_S32 SAMPLE_COMM_VO_Stop(VO_DEV VoDev)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    VO_CHN VoChn = 0;

    s32Ret = HI_MPI_VO_DisableChn(VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("func:%s,line:%d err(0x%x)!!!!\n",__FUNCTION__,__LINE__,s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_DisableVideoLayer(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("func:%s,line:%d err(0x%x)!!!!\n",__FUNCTION__,__LINE__,s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_Disable(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("func:%s,line:%d err(0x%x)!!!!\n",__FUNCTION__,__LINE__,s32Ret);
        return HI_FAILURE;
    } 

    return HI_SUCCESS;    
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
