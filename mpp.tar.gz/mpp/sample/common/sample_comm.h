/******************************************************************************
  Hisilicon HI3516 sample programs head file.

  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/

#ifndef __SAMPLE_COMM_H__
#define __SAMPLE_COMM_H__

#include "hi_common.h"
#include "hi_comm_sys.h"
#include "mpi_sys.h"
#include "hi_comm_vb.h"
#include "mpi_vb.h"
#include "hi_sns_ctrl.h"
#include "hi_comm_isp.h"
#include "mpi_isp.h"
#include "hi_comm_vi.h"
#include "mpi_vi.h"
#include "hi_comm_vo.h"
#include "mpi_vo.h"
#include "hi_comm_venc.h"
#include "mpi_venc.h"
#include "hi_comm_region.h"
#include "mpi_region.h"
#include "hi_comm_vda.h"
#include "mpi_vda.h"
#include "hi_comm_adec.h"
#include "mpi_adec.h"
#include "hi_comm_aenc.h"
#include "mpi_aenc.h"
#include "hi_comm_ai.h"
#include "mpi_ai.h"
#include "hi_comm_ao.h"
#include "mpi_ao.h"


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

/* if you want to load isp_reg_file, then define SAMPLE_LOAD_ISPREGFILE */
//#define SAMPLE_LOAD_ISPREGFILE
#define SAMPLE_ISPCFG_FILE      "../ispcfg/ispreg.cfg"

#define SAMPLE_GLOBAL_NORM	    VIDEO_ENCODING_MODE_PAL
#define SAMPLE_SYS_ALIGN_WIDTH      16
#define SAMPLE_PIXEL_FORMAT         PIXEL_FORMAT_YUV_SEMIPLANAR_422

#define SAMPLE_VO_DEV_HD            0
#define SAMPLE_VO_DEV_SD            2

/* for init global parameter */
#define SAMPLE_ENABLE 		    1
#define SAMPLE_DISABLE 		    0
#define SAMPLE_NOUSE 		    -1

typedef enum sample_rc_e
{
    SAMPLE_RC_CBR = 0,
    SAMPLE_RC_VBR,
    SAMPLE_RC_FIXQP
}SAMPLE_RC_E;

typedef enum sample_ispcfg_opt_e
{
    CFG_OPT_NONE	= 0,
    CFG_OPT_SAVE	= 1,
    CFG_OPT_LOAD	= 2,
    CFG_OPT_BUTT
}SAMPLE_CFG_OPT_E;

typedef enum sample_vi_dev_type_e
{
    APTINA_9P031_DC_1080P_CONTINUES = 0,
    APTINA_9P031_DC_1080P_DEFAULT,
    ALTASENS_DC_1080P,
    OV_2715_DC_1080P,
    OV_10630_DC_800P,
    PANASONIC_34041_1080P,
    PANASONIC_34041_1080P_60FPS,
    SONY_IMX036_DC_1080P,
    SONY_IMX122_DC_1080P,
    APTINA_9M034_DC_720P_CONTINUES,
    APTINA_AR0331_DC_1080P_30FPS,
    APTINA_AR0331_DC_3M_20FPS,
    APTINA_AR0331_DC_1080P_60FPS,
    
    OV_2715_BT601_1080P,
    BT656_D1P,
    BT1120_720P,
    KODAK_KAI2150,
    KODAK_KAI4050
}SAMPLE_VI_DEV_TYPE_E;

typedef enum sample_vi_chn_set_e
{
    VI_CHN_SET_NORMAL = 0, /* mirror, filp close */
    VI_CHN_SET_MIRROR,      /* open MIRROR */
    VI_CHN_SET_FILP		/* open filp */
}SAMPLE_VI_CHN_SET_E;

typedef enum sample_osd_change_type_e
{
    OSD_CHANGE_TYPE_FGALPHA = 0,
    OSD_CHANGE_TYPE_BGALPHA,
    OSD_CHANGE_TYPE_LAYER
}SAMPLE_OSD_CHANGE_TYPE_EN;

typedef struct sample_venc_getstream_s
{
     HI_BOOL bThreadStart;
     HI_S32  s32Cnt;
}SAMPLE_VENC_GETSTREAM_PARA_S;

HI_S32 SAMPLE_COMM_VI_StartTypical(HI_S32 s32Cnt, PIC_SIZE_E *penViChnSize);
HI_VOID SAMPLE_COMM_VI_StopTypical(HI_S32 s32Cnt);
HI_S32 SAMPLE_COMM_VI_StartDev(VI_DEV ViDev, SAMPLE_VI_DEV_TYPE_E enViDevType);
HI_S32 SAMPLE_COMM_VI_StopDev(VI_DEV ViDev);
HI_S32 SAMPLE_COMM_VI_StartBaseChn(VI_DEV ViDev, VI_CHN ViChn, SAMPLE_VI_DEV_TYPE_E enViDevType, PIC_SIZE_E enDesPicSize, SAMPLE_VI_CHN_SET_E enViChnSet);
HI_S32 SAMPLE_COMM_VI_StartExtChn(VI_CHN ViBaseChn, VI_CHN ViExtChn, HI_BOOL bVppEnable, PIC_SIZE_E enPicSize);
HI_S32 SAMPLE_COMM_VI_StopChn(VI_CHN ViChn);
HI_S32 SAMPLE_COMM_VI_BindViVo(VI_DEV ViDev, VI_CHN ViChn, VO_DEV VoDev, VO_CHN VoChn);
HI_S32 SAMPLE_COMM_VI_UnBindViVo(VI_DEV ViDev, VI_CHN ViChn, VO_DEV VoDev, VO_CHN VoChn);

HI_S32 SAMPLE_COMM_VO_Start(VO_DEV VoDev);
HI_S32 SAMPLE_COMM_VO_Stop(VO_DEV VoDev);

HI_S32 SAMPLE_COMM_ISP_IspInit(void);
HI_VOID SAMPLE_COMM_ISP_IspStop(void);
HI_S32 SAMPLE_COMM_ISP_IspRun(void);
HI_S32 SAMPLE_COMM_ISP_SensorInit(void);
HI_S32 SAMPLE_COMM_ISP_SaveRegFile(SAMPLE_CFG_OPT_E enCfgOpt, char *pcIspCfgFile);

HI_S32 SAMPLE_COMM_SYS_GetPicSize(VIDEO_NORM_E enNorm, PIC_SIZE_E enPicSize, SIZE_S *pstSize);
HI_VOID SAMPLE_COMM_SYS_Exit(void);
HI_S32 SAMPLE_COMM_SYS_Init(VB_CONF_S *pstVbConf);
HI_S32 SAMPLE_COMM_SYS_DefVb(HI_S32 s32VbNum1, HI_S32 s32VbNum2, PIC_SIZE_E enPicSize, VB_CONF_S *pstVbConf);

HI_S32 SAMPLE_COMM_VENC_SnapStart(VENC_CHN VencChn, VI_CHN ViChn, PIC_SIZE_E enSize);
HI_S32 SAMPLE_COMM_VENC_SnapStop(VENC_CHN VencChn);
HI_S32 SAMPLE_COMM_VENC_GetSnapProc(VENC_CHN SnapChn, VI_CHN ViChn, PIC_SIZE_E enSize);
HI_S32 SAMPLE_COMM_VENC_StreamStart(VENC_CHN VencChn, VI_CHN ViChn, PAYLOAD_TYPE_E enType, PIC_SIZE_E enSize, HI_BOOL bVppEnable, SAMPLE_RC_E enRcMode);
HI_S32 SAMPLE_COMM_VENC_StreamStop(VENC_CHN VencChn);
HI_VOID* SAMPLE_COMM_VENC_GetVencStreamProc(HI_VOID *p);
HI_S32 SAMPLE_COMM_VENC_StartGetStream(HI_S32 s32Cnt);
HI_S32 SAMPLE_COMM_VENC_StopGetStream();

HI_S32 SAMPLE_COMM_VDA_MdStart(VDA_CHN VdaChn, VI_CHN ViChn, PIC_SIZE_E enPicSize);
HI_S32 SAMPLE_COMM_VDA_OdStart(VDA_CHN VdaChn, VI_CHN ViChn, PIC_SIZE_E enPicSize);
HI_VOID SAMPLE_COMM_VDA_MdStop(VDA_CHN VdaChn, VI_CHN ViChn);
HI_VOID SAMPLE_COMM_VDA_OdStop(VDA_CHN VdaChn, VI_CHN ViChn);

HI_S32 SAMPLE_COMM_AUDIO_CreatTrdAiAo(AUDIO_DEV AiDev, AI_CHN AiChn, AUDIO_DEV AoDev, AO_CHN AoChn);
HI_S32 SAMPLE_COMM_AUDIO_CreatTrdAiAenc(AUDIO_DEV AiDev, AI_CHN AiChn, AENC_CHN AeChn);
HI_S32 SAMPLE_COMM_AUDIO_CreatTrdAencAdec(AENC_CHN AeChn, ADEC_CHN AdChn, FILE *pAecFd);
HI_S32 SAMPLE_COMM_AUDIO_CreatTrdFileAdec(ADEC_CHN AdChn, FILE *pAdcFd);
HI_S32 SAMPLE_COMM_AUDIO_DestoryTrdAi(AUDIO_DEV AiDev, AI_CHN AiChn);
HI_S32 SAMPLE_COMM_AUDIO_DestoryTrdAencAdec(AENC_CHN AeChn);
HI_S32 SAMPLE_COMM_AUDIO_DestoryTrdFileAdec(ADEC_CHN AdChn);
HI_S32 SAMPLE_COMM_AUDIO_AoBindAdec(AUDIO_DEV AoDev, AO_CHN AoChn, ADEC_CHN AdChn);
HI_S32 SAMPLE_COMM_AUDIO_AoUnbindAdec(AUDIO_DEV AoDev, AO_CHN AoChn, ADEC_CHN AdChn);
HI_S32 SAMPLE_COMM_AUDIO_AoBindAi(AUDIO_DEV AiDev, AI_CHN AiChn, AUDIO_DEV AoDev, AO_CHN AoChn);
HI_S32 SAMPLE_COMM_AUDIO_AoUnbindAi(AUDIO_DEV AiDev, AI_CHN AiChn, AUDIO_DEV AoDev, AO_CHN AoChn);
HI_S32 SAMPLE_COMM_AUDIO_AencBindAi(AUDIO_DEV AiDev, AI_CHN AiChn, AENC_CHN AeChn);
HI_S32 SAMPLE_COMM_AUDIO_AencUnbindAi(AUDIO_DEV AiDev, AI_CHN AiChn, AENC_CHN AeChn);
HI_S32 SAMPLE_COMM_AUDIO_CfgAcodec(AUDIO_SAMPLE_RATE_E enSample, HI_BOOL bMicIn);
HI_S32 SAMPLE_COMM_AUDIO_DisableAcodec();
HI_S32 SAMPLE_COMM_AUDIO_StartAi(AUDIO_DEV AiDevId, HI_S32 s32AiChnCnt,
        AIO_ATTR_S *pstAioAttr, HI_BOOL bAnrEn, AUDIO_RESAMPLE_ATTR_S *pstAiReSmpAttr);
HI_S32 SAMPLE_COMM_AUDIO_StopAi(AUDIO_DEV AiDevId, HI_S32 s32AiChnCnt,
        HI_BOOL bAnrEn, HI_BOOL bResampleEn);
HI_S32 SAMPLE_COMM_AUDIO_StartAo(AUDIO_DEV AoDevId, AO_CHN AoChn,
        AIO_ATTR_S *pstAioAttr, AUDIO_RESAMPLE_ATTR_S *pstAiReSmpAttr);
HI_S32 SAMPLE_COMM_AUDIO_StopAo(AUDIO_DEV AoDevId, AO_CHN AoChn, HI_BOOL bResampleEn);
HI_S32 SAMPLE_COMM_AUDIO_StartAenc(HI_S32 s32AencChnCnt, PAYLOAD_TYPE_E enType);
HI_S32 SAMPLE_COMM_AUDIO_StopAenc(HI_S32 s32AencChnCnt);
HI_S32 SAMPLE_COMM_AUDIO_StartAdec(ADEC_CHN AdChn, PAYLOAD_TYPE_E enType);
HI_S32 SAMPLE_COMM_AUDIO_StopAdec(ADEC_CHN AdChn);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */


#endif /* End of #ifndef __SAMPLE_COMMON_H__ */
