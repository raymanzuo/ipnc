/******************************************************************************
  Some simple Hisilicon HI3516 video input functions.

  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <math.h>
#include <unistd.h>
#include <signal.h>

#include "sample_comm.h"

/*****************************************************************************
* function : star vi dev (cfg vi_dev_attr; set_dev_cfg; enable dev)
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StartDev(VI_DEV ViDev, SAMPLE_VI_DEV_TYPE_E enViDevType)
{
    HI_S32 s32Ret;
    VI_DEV_ATTR_S    stViDevAttr;

    switch (enViDevType)
    {
        case APTINA_9P031_DC_1080P_CONTINUES:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case APTINA_9M034_DC_720P_CONTINUES:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
		case APTINA_AR0331_DC_1080P_60FPS:
        case APTINA_AR0331_DC_1080P_30FPS:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
			
		case APTINA_AR0331_DC_3M_20FPS:
			stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
			stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
			stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
			stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
			stViDevAttr.au32CompMask[1] = 0x0;	/* comp mask */
			stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
			stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
			stViDevAttr.enDataType = VI_DATA_TYPE_RGB;	  /* Date type (RGB or YUV */
			stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;	 /* input data seq (Bayer patten) */
			stViDevAttr.bUseInterISP = HI_TRUE; 		/* inside isp or not */
		
			/* syn timing cfg. BT601/DC interface must config! */
			stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
			stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
			stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
			stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
			stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
			stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
			stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
			stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 2048; /* horizontal valid width */
			stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1536; /* frame or interleaved odd picture's vertical valid blanking width */
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
			stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
		
			stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
			stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
			break;

        case APTINA_9P031_DC_1080P_DEFAULT:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH; /* difference */
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case PANASONIC_34041_1080P:
        case PANASONIC_34041_1080P_60FPS:
        case ALTASENS_DC_1080P:
        case SONY_IMX036_DC_1080P:
   //     case SONY_IMX122_DC_1080P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
            case SONY_IMX122_DC_1080P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            //stViDevAttr.enClkEdge =  VI_CLK_EDGE_DOUBLE ; /* clock edge define */
            stViDevAttr.enClkEdge =  VI_CLK_EDGE_SINGLE_UP;
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_RGRG;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case OV_2715_DC_1080P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_DOWN; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;   /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_BGBG;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
	    stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;// VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH; // LOW;
            /* syn timing cfg. BT601/DC interface must config! */
   /*         stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH; */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case OV_10630_DC_800P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_COMPOSITE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFF00;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_YUV;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enYuvSeq = VI_INPUT_DATA_YUYV;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_FALSE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1280; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 720; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case OV_2715_BT601_1080P:
            stViDevAttr.enInputMode = VI_MODE_BT601; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFC;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_PULSE;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 50; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 450; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 12; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 12;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case BT656_D1P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA;  /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_COMPOSITE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0x00FF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x00;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE; /* INTERLACED;   input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_YUV;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enYuvSeq = VI_INPUT_DATA_UYVY;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_LOW;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 704; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 576; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct =0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case BT1120_720P:
            stViDevAttr.enInputMode = VI_MODE_BT656; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_DOUBLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFF00;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x00;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_YUV;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enYuvSeq = VI_INPUT_DATA_UVUV;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_FALSE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        default:
            printf("vi input type[%d] is invalid!\n", enViDevType);
            return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_SetDevAttr(ViDev, &stViDevAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_SetDevAttr failed with %#x!\n",\
               __FUNCTION__,  s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_EnableDev(ViDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_EnableDev failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}
/*****************************************************************************
* function : disable vi dev
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StopDev(VI_DEV ViDev)
{
    return (HI_MPI_VI_DisableDev(ViDev));
}

/*****************************************************************************
* function : star vi ext chn
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StartExtChn(VI_CHN ViBaseChn, VI_CHN ViExtChn, HI_BOOL bVppEnable, PIC_SIZE_E enPicSize)
{
    VI_CHN_BIND_ATTR_S stChnBindAttr;
    VI_VPP_CFG_S stVppCfg;
    HI_S32 s32Ret;
    SIZE_S stSize;

    stChnBindAttr.enBindType = VI_CHN_BIND_VICHN;
    stChnBindAttr.unBindAttr.stBindViChn.ViChn = ViBaseChn;

    s32Ret = HI_MPI_VI_ChnBind(ViExtChn, &stChnBindAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_ChnBind(ext=%d,base=%d) failed with %#x!\n", \
              __FUNCTION__, ViExtChn, ViBaseChn, s32Ret);
        return HI_FAILURE;
    }
    s32Ret = HI_MPI_VI_EnableChn(ViExtChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_EnableChn(%d) failed with %#x!\n", \
              __FUNCTION__, ViExtChn, s32Ret);
        HI_MPI_VI_ChnUnBind(ViExtChn);
        return HI_FAILURE;
    }

    if (HI_TRUE == bVppEnable)
    {
        s32Ret = SAMPLE_COMM_SYS_GetPicSize(SAMPLE_GLOBAL_NORM, enPicSize, &stSize);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: get picture size[%d] failed!\n", __FUNCTION__, enPicSize);
            return HI_FAILURE;
        }

/**
        s32Ret = HI_MPI_VI_GetVppCfg(ViExtChn, &stVppCfg);
        if (s32Ret != HI_SUCCESS)
        {
            printf("%s: HI_MPI_VI_GetVppCfg(%d) failed with %#x!\n", \
                  __FUNCTION__, ViExtChn, s32Ret);
            HI_MPI_VI_ChnUnBind(ViExtChn);
            HI_MPI_VI_DisableChn(ViExtChn);
            return HI_FAILURE;
        }
**/
        stVppCfg.stVppCfg.bVppEn = HI_TRUE;  /* vpp global enable */
        stVppCfg.stVppCfg.bDnEn = HI_TRUE;   /* De-Noise enable */
        stVppCfg.stVppCfg.bSpEn = HI_TRUE;   /* shapen enable */
        stVppCfg.stVppCfg.bIencEn = HI_FALSE; /* not support now */
        stVppCfg.stVppCfg.s32DnSfCosSth = 2;
        stVppCfg.stVppCfg.s32DnSfIncSth = 200;
        stVppCfg.stVppCfg.s32DnTfSth = 2;
        stVppCfg.stVppCfg.s32SpSth = -3;

        s32Ret = HI_MPI_VI_SetVppCfg(ViExtChn, &stVppCfg);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: HI_MPI_VI_SetVppCfg(%d) failed with %#x!\n",\
                    __FUNCTION__, ViExtChn, s32Ret);
            HI_MPI_VI_ChnUnBind(ViExtChn);
            HI_MPI_VI_DisableChn(ViExtChn);
            return HI_FAILURE;
        }
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : star vi base chn
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StartBaseChn(VI_DEV ViDev, VI_CHN ViChn, SAMPLE_VI_DEV_TYPE_E enViDevType, PIC_SIZE_E enDesPicSize, SAMPLE_VI_CHN_SET_E enViChnSet)
{
    HI_S32 s32Ret;
    SIZE_S stDesSize, stCapSize;
    VI_CHN_ATTR_S stChnAttr;
    VI_CHN_BIND_ATTR_S stChnBindAttr;
    
    switch(enViDevType)
    {
        case APTINA_AR0331_DC_1080P_30FPS:
		case APTINA_AR0331_DC_1080P_60FPS:
        case APTINA_9P031_DC_1080P_CONTINUES:
        case APTINA_9P031_DC_1080P_DEFAULT:
        case ALTASENS_DC_1080P:
        case OV_2715_DC_1080P:
        case PANASONIC_34041_1080P:
        case PANASONIC_34041_1080P_60FPS:
        case OV_2715_BT601_1080P:
        case SONY_IMX036_DC_1080P:
        case SONY_IMX122_DC_1080P:
            stCapSize.u32Width = 1920;
            stCapSize.u32Height = 1080;
            break;
        case APTINA_9M034_DC_720P_CONTINUES:
            stCapSize.u32Width = 1280;
            stCapSize.u32Height = 720;
            break;
        case BT656_D1P:
            stCapSize.u32Width = 704;
            stCapSize.u32Height = (VIDEO_ENCODING_MODE_PAL==SAMPLE_GLOBAL_NORM)?576:480;
            break;
        case BT1120_720P:
            stCapSize.u32Width = 1280;
            stCapSize.u32Height = 720;
            break;
        case OV_10630_DC_800P:
            stCapSize.u32Width = 1280;
            stCapSize.u32Height = 720;
            break;
        case APTINA_AR0331_DC_3M_20FPS:
            stCapSize.u32Width = 2048;
            stCapSize.u32Height = 1536;
            break;

        default:
            printf("%s: get capture picture size[%d] failed!\n", \
                   __FUNCTION__, enViDevType);
            return HI_FAILURE;
    }

    s32Ret = SAMPLE_COMM_SYS_GetPicSize(SAMPLE_GLOBAL_NORM, enDesPicSize, &stDesSize);
    if (s32Ret)
    {
        printf("%s: get picture size[%d] failed!\n", __FUNCTION__, enDesPicSize);
        return HI_FAILURE;
    }

    /* step  5: config & start vicap dev */
    stChnAttr.stCapRect.s32X = 0;
    stChnAttr.stCapRect.s32Y = 0;
    stChnAttr.stCapRect.u32Width = stCapSize.u32Width;
    stChnAttr.stCapRect.u32Height = stCapSize.u32Height;
    stChnAttr.enCapSel = VI_CAPSEL_BOTH;
    /* to show scale. this is a sample only, we want to show dist_size = D1 onley */
    stChnAttr.stDestSize.u32Width = stDesSize.u32Width;
    stChnAttr.stDestSize.u32Height = stDesSize.u32Height;
    stChnAttr.enPixFormat = SAMPLE_PIXEL_FORMAT;   /* sp420 or sp422 */
    stChnAttr.bMirror = HI_TRUE;  //(VI_CHN_SET_MIRROR == enViChnSet)?HI_TRUE:HI_FALSE;
    stChnAttr.bFilp = HI_TRUE; //(VI_CHN_SET_FILP == enViChnSet)?HI_TRUE:HI_FALSE;

    /* we only use phy chn, and phychnid=vichn */
    stChnBindAttr.enBindType = VI_CHN_BIND_PHYCHN;
    stChnBindAttr.unBindAttr.stBindPhyChn.s32PhyChn = ViChn;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViDev = ViDev;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViWay = 0;

    s32Ret = HI_MPI_VI_ChnBind(ViChn, &stChnBindAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_ChnBind(%d,%d) failed with %#x!\n", \
              __FUNCTION__, ViDev, ViChn, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_SetChnAttr(ViChn, &stChnAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_SetChnAttr failed with %#x!\n", \
               __FUNCTION__, s32Ret);
        HI_MPI_VI_ChnUnBind(ViChn);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_EnableChn(ViChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_EnableChn failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        HI_MPI_VI_ChnUnBind(ViChn);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : star vi chn
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StopChn(VI_CHN ViChn)
{
    HI_S32 s32Ret = HI_FAILURE;

    s32Ret = HI_MPI_VI_DisableChn(ViChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_DisableChn [%d] failed with %#x!\n",\
            __FUNCTION__, ViChn, s32Ret);
        return HI_FAILURE;
    }
    
    s32Ret = HI_MPI_VI_ChnUnBind(ViChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_ChnUnBind [%d] failed with %#x!\n",\
            __FUNCTION__, ViChn, s32Ret);
           return HI_FAILURE;
    }
    
    return HI_SUCCESS;
}
/*****************************************************************************
* function : star vi.     1080p DC -> ViDev[0]. s32Cnt is vi-chn number. 
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_StartTypical(HI_S32 s32Cnt, PIC_SIZE_E *penViChnSize)
{
    HI_S32 i;
    VI_DEV ViDev = 0;
    VI_CHN ViChn;
    HI_S32 s32Ret;
    SAMPLE_VI_DEV_TYPE_E  enViDevType = SENSOR_TYPE; /* SENSOR_TYPE defined in Makefile.para */;
    SAMPLE_VI_CHN_SET_E enViChnSet = VI_CHN_SET_NORMAL;

    if (s32Cnt > 5)
    {
        printf("%s: vi chn cnt[%d] input error!\n", __FUNCTION__, s32Cnt);
        return HI_FAILURE;
    }
    /******************************************
     step 1: configure sensor.
    ******************************************/
    s32Ret = SAMPLE_COMM_ISP_SensorInit();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Sensor init failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    /******************************************************
     step 2 : config & start vicap dev - port A & B
    ******************************************************/
    s32Ret = SAMPLE_COMM_VI_StartDev(ViDev, enViDevType);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: start vi dev[%d] failed!\n", __FUNCTION__, ViDev);
        return HI_FAILURE;
    }
    /******************************************
     step 3: configure & run isp thread
    ******************************************/
    s32Ret = SAMPLE_COMM_ISP_IspRun();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: ISP init failed!\n", __FUNCTION__);
        /* disable videv */
        HI_MPI_VI_DisableDev(ViDev);
        return HI_FAILURE;
    }

    /******************************************************
    * Step 2: config & start vicap chn (max 5)
    ******************************************************/
    for (i=0; i<s32Cnt; i++)
    {
        ViChn = i;
        s32Ret = SAMPLE_COMM_VI_StartBaseChn(ViDev, ViChn, enViDevType, penViChnSize[i], enViChnSet);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: start vi chn[%d,%d] failed!\n", __FUNCTION__,\
                   ViDev, ViChn);
            for(i=i-1;i>=0;i--)
            {
                HI_MPI_VI_DisableChn(ViChn);
                HI_MPI_VI_ChnUnBind(ViChn);
            }
            SAMPLE_COMM_ISP_IspStop();
            HI_MPI_VI_DisableDev(ViDev);
            return HI_FAILURE;
        }
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : star vi chn
*****************************************************************************/
HI_VOID SAMPLE_COMM_VI_StopTypical(HI_S32 s32Cnt)
{
    VI_DEV ViDev = 0;
    VI_CHN ViChn = 0;
    HI_S32 s32Ret;
    HI_S32 i;

    /******************************************
     step 1: stop vi chn
    ******************************************/
    for (i=0; i<s32Cnt; i++)
    {
        ViChn = i;

        s32Ret = SAMPLE_COMM_VI_StopChn(ViChn);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: SAMPLE_COMM_VI_StopChn [%d] failed with %#x!\n",\
                __FUNCTION__, ViChn, s32Ret);
        }  
    }

    /******************************************
     step 2: stop ISP thread
    ******************************************/
    SAMPLE_COMM_ISP_IspStop();

    /******************************************
     step 3: stop vi dev
    ******************************************/
    s32Ret = HI_MPI_VI_DisableDev(ViDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_DisableDev [%d] failed with %#x!\n",\
                __FUNCTION__, ViDev, s32Ret);
    }
    return;
}
/*****************************************************************************
* function : star vi chn
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_BindViVo(VI_DEV ViDev, VI_CHN ViChn, VO_DEV VoDev, VO_CHN VoChn)
{
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    HI_S32 s32Ret;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = VoChn;
    stBindDest.s32DevId = VoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = ViChn;
    stBindSrc.s32DevId = ViDev;
    
    s32Ret = HI_MPI_SYS_Bind(&stBindSrc, &stBindDest);
    if (s32Ret)
    {
        printf("%s: HI_MPI_SYS_Bind: (dev-%d,chn-%d)-(dev-%d,chn-%d) faild with %#x!\n", __FUNCTION__, ViDev, ViChn, VoDev, VoChn, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : vi-chn bind vo-chn
*****************************************************************************/
HI_S32 SAMPLE_COMM_VI_UnBindViVo(VI_DEV ViDev, VI_CHN ViChn, VO_DEV VoDev, VO_CHN VoChn)
{
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = VoChn;
    stBindDest.s32DevId = VoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = ViChn;
    stBindSrc.s32DevId = ViDev;
    
    if (HI_MPI_SYS_UnBind(&stBindSrc, &stBindDest))
    {
        printf("%s: HI_MPI_SYS_UnBind faild!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
