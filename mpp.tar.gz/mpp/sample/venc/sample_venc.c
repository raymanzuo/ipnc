/******************************************************************************
  A simple program of Hisilicon HI3516 video encode implementation.
  the case of stream process and snap process is different.  the flow as follows:
  1. the case of stream process:
    1) init mpp system.
    2) start vi & vo ( internal isp, ViDev 0, Vo-HD);                  
        note : vo bind the first vi-chn.
    3) start venc
       3.1) Greate Venc Group
       3.2) Create Venc Channel
       3.3) Regist Venc Channel to Venc Group
       3.4) Venc Group bind Vi Channel
       3.5) Start Recv Venc Pictures
    4) create venc process thread:
       4.1) GetStream
       4.2) save it to file.
    5) stop venc
       5.1) stop recv venc pictrues
       5.2) unbind venc group to vi channel
       5.3) unregist venc channel to venc group
       5.4) destroy venc cannel
       5.5) destroy venc group
    6) stop vo, vi and system.
2. the case of Snap process:
    1) init mpp system.
    2) start vi & vo ( internal isp, ViDev 0, Vo-HD);                  
        note : vo bind the first vi-chn.
    3) start snap venc
       3.1) Greate Venc Group
       3.2) Create Venc Channel
    4) create snap process thread.
       4.1) Regist Venc Channel to Venc Group
       4.2) Venc Group bind Vi Channel
       4.3) Start Recv Venc Pictures
       4.4) GetStream
       4.5) save it to file.
       4.6) stop recv venc pictures
       4.7) unbind venc group and vi channel
       4.8) unregister venc channel
    5) stop snap venc
       5.1) destroy venc channel
       5.2) destroy venc group.
    6) stop vo, vi and system.   
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include "sample_comm.h"

static VB_CONF_S gs_stVbConf ={0};/* vb config define */
static VI_DEV gs_ViDevBnd_curr;	/* which vi-dev is binded to vo-chn */
static VI_CHN gs_ViChnBnd_curr;	/* which vi-chn is binded to vo-chn */
static HI_S32 gs_s32Cnt; 	/* use venc chn count.
			 one vi chn -- one venc grp -- one venc chn */ 
static PAYLOAD_TYPE_E gs_enPayLoad[5];  /* venc payload type */
static PIC_SIZE_E gs_enSize[5];		/* venc picture size */

extern VENC_CHN g_StartVencChn;

/******************************************************************************
* function : show usage
******************************************************************************/
void SAMPLE_VENC_Usage(char *sPrgNm)
{
    printf("Usage : %s <index>\n", sPrgNm);
    printf("index:\n");
    printf("\t 0) H264 1080p video encode\n");
    printf("\t    DC -> VI-PortA VI-Chn0 -> H264 Venc\n");
    printf("\t 1) MJPEG 1080p video encode\n");
    printf("\t    DC:(P031 -> VI-PortA VI-Chn0 -> MJPEG Venc(FPGA version not support)\n");
    printf("\t 2) JPEG snap video encode\n");
    printf("\t    DC -> VI-PortA Vi-Chn0 -> JPEG Snap\n");
    printf("\t 3) mixer vpp + video encode\n");
    printf("\t    DC -> VI-PortA Multi-ViChn -> 1080p@30+720p@30+D1@30+CIF@30+1080pSnap\n");
    printf("\t 4) MPEG4 D1 video encode\n");
    printf("\t    DC -> VI-PortA VI-Chn0 -> mpeg4 Venc\n");

    return;
}

/******************************************************************************
* function : to process abnormal case - the case of stream venc                                        
******************************************************************************/
void SAMPLE_VENC_StreamHandleSig(HI_S32 signo)
{
    HI_S32 i;
    VENC_CHN VencChn;

    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_COMM_VENC_StopGetStream();
        for (i=0; i<gs_s32Cnt; i++)
        {
            VencChn = i;
            SAMPLE_COMM_VENC_StreamStop(VencChn);
        }
        SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
        SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
        SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}
/******************************************************************************
* function : to process abnormal case  - the case of snap                                          
******************************************************************************/
void SAMPLE_VENC_SnapHandleSig(HI_S32 signo)
{
    VENC_CHN VencChn;

    if (SIGINT == signo || SIGTSTP == signo)
    {
        VencChn = 0;
        SAMPLE_COMM_VENC_SnapStop(VencChn);
        SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
        SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
        SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function : to process abnormal case - the case of mixer                                        
******************************************************************************/
void SAMPLE_VENC_MixerHandleSig(HI_S32 signo)
{
    HI_S32 i;
    VENC_CHN VencChn;
    VENC_CHN SnapVencChn = 4;
    VI_CHN SnapExtViChn = 4;

    SAMPLE_COMM_VI_StopChn(SnapExtViChn);
    SAMPLE_COMM_VENC_SnapStop(SnapVencChn);

    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_COMM_VENC_StopGetStream();
        for (i=0; i<gs_s32Cnt; i++)
        {
            VencChn = i;
            SAMPLE_COMM_VENC_StreamStop(VencChn);
        }
#ifdef SAMPLE_VENC_MIXER_VO_ENABLE
        SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
        SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
#endif
        SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function : the case of stream venc:  h264, mjpeg or mpeg4.  
*               cChoose = 0 -- H264, cChoose = 1 -- MJPEG, cChoose = 4 -- MPEG4
******************************************************************************/
HI_S32 SAMPLE_VENC_StreamProcess(HI_CHAR cChoose)
{
    HI_S32 i, s32Ret;
    VI_DEV ViDev = 0;
    VO_DEV VoDev = SAMPLE_VO_DEV_HD;
    VO_CHN VoChn = 0;
    VI_CHN ViChn = 0;
    VENC_CHN VencChn;
    SAMPLE_RC_E enRcMode;
    HI_CHAR ch;

    /******************************************
     step  1: init global  variable 
    ******************************************/
    switch (cChoose)
    {
        case '0':
        /**********************************************************
         DC,1080p -> ViDev0,Chn0 -> Venc(H264) -> file
                                        Chn0 -> Vo(HD)
        **********************************************************/
            gs_s32Cnt = 1; /* venc chn = 1 */
            gs_enPayLoad[0] = PT_H264;
            gs_enSize[0] = PIC_HD1080;

            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;

        case '1':
        /**********************************************************
         DC,1080p -> ViDev0,Chn0 -> Venc(MJPEG) -> file
                                        Chn0 -> Vo
        **********************************************************/
            gs_s32Cnt = 1; /* venc chn = 1 */
            gs_enPayLoad[0] = PT_MJPEG;
            gs_enSize[0] = PIC_HD1080;

            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;

        case '4':
        /**********************************************************
         DC,1080p -> ViDev0,Chn0(1080p) -> Vo(HD)
         DC,1080p -> ViDev0,Chn1(D1) -> Venc(Mpeg4) -> file
                                        
        **********************************************************/
            gs_s32Cnt = 2;
            gs_enPayLoad[1] = PT_MP4VIDEO;
            gs_enSize[0] = PIC_HD1080;
            gs_enSize[1] = PIC_D1;

            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            s32Ret = SAMPLE_COMM_SYS_DefVb(2, 3, PIC_D1, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;
            
        default:
            printf("the index is invaild!\n");
            return HI_FAILURE;
    }

    while(1)
    {
        printf("please choose rc mode:\n"); 
        printf("\t0) CBR\n"); 
        printf("\t1) VBR\n"); 
        printf("\t2) FIXQP\n"); 
        ch = getchar();
        if ('0' == ch)
        {
            enRcMode = SAMPLE_RC_CBR;
        
            break;
        }
        else if ('1' == ch)
        {
            enRcMode = SAMPLE_RC_VBR;
	        break;
        }
        else if ('2' == ch)
        {
            enRcMode = SAMPLE_RC_FIXQP;
            break;
        }
        else
        {
            printf("rc mode invaild! please try again.\n");
            continue;
        }
    }

    /******************************************
     step  2: process abnormal case 
    ******************************************/
    signal(SIGINT, SAMPLE_VENC_StreamHandleSig);
    signal(SIGTERM, SAMPLE_VENC_StreamHandleSig);

    /******************************************
     step 3: mpp system init. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&gs_stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        exit(HI_FAILURE);
    }

    /******************************************
     step 4: start vi dev & chn to capture
    ******************************************/
    s32Ret = SAMPLE_COMM_VI_StartTypical(gs_s32Cnt, gs_enSize);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Vi failed!\n", __FUNCTION__);
        goto END_STREAM_6;
    }

    /******************************************
     step 5: start VO to preview 
    ******************************************/
    s32Ret = SAMPLE_COMM_VO_Start(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start VO failed!\n", __FUNCTION__);
        goto END_STREAM_5;
    }
    /******************************************
     step 6: vichn 0 bind vo (0,0) for vo preview
    ******************************************/
    ViChn = 0; /* the first vi chn */
    gs_ViDevBnd_curr = ViDev;
    gs_ViChnBnd_curr = ViChn;
    s32Ret = SAMPLE_COMM_VI_BindViVo(ViDev, ViChn, VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: vichn vochn bind failed!\n", __FUNCTION__);
        goto END_STREAM_4;
    }

    /******************************************
     step 7: start stream venc
    ******************************************/
    /* vi chn0 can't scale or crop, mpeg4(largest chn size is 720p) chn start from chn1 */
    if ('4' == cChoose)
    {
        g_StartVencChn = 1;
    }
    else
    {
        g_StartVencChn = 0;
    }
    for (i=g_StartVencChn; i<gs_s32Cnt; i++)
    {
        VencChn = i;
        ViChn = i;
        s32Ret = SAMPLE_COMM_VENC_StreamStart(VencChn, ViChn, gs_enPayLoad[i],\
                                        gs_enSize[i], HI_FALSE, enRcMode);

        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: Start Venc failed!\n", __FUNCTION__);
            goto END_STREAM_2;
        }
    }

    /******************************************
     step 8: stream venc process -- get stream, then save it to file. 
    ******************************************/
    s32Ret = SAMPLE_COMM_VENC_StartGetStream(gs_s32Cnt);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END_STREAM_1;
    }

    printf("please press twice ENTER to exit this sample\n");
    getchar();
    getchar();
END_STREAM_1:	
    SAMPLE_COMM_VENC_StopGetStream();
	
   /******************************************
     step 9: stop venc 
    ******************************************/
END_STREAM_2:
    for (i=g_StartVencChn; i<gs_s32Cnt; i++)
    {
        VencChn = i;
        SAMPLE_COMM_VENC_StreamStop(VencChn);
    }

    /******************************************
     step 10: stop vi vo & sys
    ******************************************/
    SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
END_STREAM_4:
    SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
END_STREAM_5:
    SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
END_STREAM_6:
    SAMPLE_COMM_SYS_Exit();
    
    return HI_SUCCESS;
}

/******************************************************************************
* function : the case of sanp venc: jpeg
*               DC,1080p -> ViDev0,Chn0 -> Jpeg Snap -> file
                                                Chn0 -> Vo(HD)
******************************************************************************/
HI_S32 SAMPLE_VENC_SnapProcess(HI_CHAR cChoose)
{
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;;
    VI_DEV ViDev = 0;
    VO_DEV VoDev = SAMPLE_VO_DEV_HD;
    VO_CHN VoChn = 0;
    VI_CHN ViChn = 0;
    VENC_CHN VencChn=0;
    HI_CHAR ch;

    /**********************************************************
     step  1: init global  variable 
              DC,1080p -> ViDev0,Chn0 -> Venc Snap(JPEG) -> file
                                 Chn0 -> Vo(HD)
    **********************************************************/
    gs_s32Cnt = 1; /* venc chn = 1 */
    gs_enPayLoad[0] = PT_JPEG;
    gs_enSize[0] = PIC_HD1080;
    if(APTINA_AR0331_DC_3M_20FPS == SENSOR_TYPE)
        gs_enSize[0] = PIC_QXGA;  
        
    s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, gs_enSize[0], &gs_stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }

    /******************************************
     step  2: process abnormal case 
    ******************************************/
    signal(SIGINT, SAMPLE_VENC_SnapHandleSig);
    signal(SIGTERM, SAMPLE_VENC_SnapHandleSig);

    /******************************************
     step 3: mpp system init. note: in this case, vb cfg is ineffective. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&gs_stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 4: start vi dev & chn to capture
    ******************************************/
    s32Ret = SAMPLE_COMM_VI_StartTypical(gs_s32Cnt, gs_enSize);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_COMM_SYS_Exit();
        printf("%s: Start Vi failed!\n", __FUNCTION__);
        goto END_SNAP_4;
    }

    /******************************************
     step 5: start VO to preview 
    ******************************************/
    s32Ret = SAMPLE_COMM_VO_Start(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start VO failed!\n", __FUNCTION__);
        goto END_SNAP_3;
    }
    /******************************************
     step 6: vichn 0 bind vo (0,0) for vo preview
    ******************************************/
    gs_ViDevBnd_curr = ViDev;
    gs_ViChnBnd_curr = ViChn;
    s32Ret = SAMPLE_COMM_VI_BindViVo(ViDev, ViChn, VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: vichn vochn bind failed!\n", __FUNCTION__);
        goto END_SNAP_2;
    }

    /******************************************
     step 7: start snap venc .
    ******************************************/
    s32Ret = SAMPLE_COMM_VENC_SnapStart(VencChn, ViChn, gs_enSize[0]);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END_SNAP_1;
    }

    /******************************************
     step 8: snap process - save picture.
    ******************************************/
    printf("press 'q' to exit sample!\nperess ENTER to capture one picture to file\n");

    i = 0;
    while ((ch = getchar()) != 'q')
    {
        s32Ret = SAMPLE_COMM_VENC_GetSnapProc(VencChn, ViChn, gs_enSize[0]);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: sanp process failed!\n", __FUNCTION__);
            break;
        }
        printf("snap %d success!\n", i);
        i++;
    }

    /******************************************
     step 9: stop venc 
    ******************************************/
    SAMPLE_COMM_VENC_SnapStop(VencChn);

    /******************************************
     step 10: stop vi vo & sys
    ******************************************/
END_SNAP_1:
    SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
END_SNAP_2:
    SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
END_SNAP_3:
    SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
END_SNAP_4:	
    SAMPLE_COMM_SYS_Exit();
    if (HI_SUCCESS != s32Ret)
    {
	printf("program exit abnormally!\n");
    }
    else
    {
        printf("program exit normally!\n");
    }
    return s32Ret;
}

/******************************************************************************
  function : the case of mixer venc
                DC,1080p -> ViDev0,Chn0(1080p) -> Jpeg Snap -> file
                                               -> H264 Venc -> file
                                   Chn1(720p)  -> H264 Venc -> file
                                   Chn2(D1)    -> H264 Venc -> file
                                   Chn3(CIF)   -> H264 Venc -> file
******************************************************************************/
HI_S32 SAMPLE_VENC_MixerProcess(HI_CHAR cChoose)
{
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;	
#ifdef SAMPLE_VENC_MIXER_VO_ENABLE
    VI_DEV ViDev = 0;
    VO_DEV VoDev = SAMPLE_VO_DEV_HD;
    VO_CHN VoChn = 0;
#endif
    VI_CHN ViChn = 0;
    VI_CHN ViChn_SnapExt = 4;
    VENC_CHN VencChn = 0;
    VENC_CHN VencChn_Snap = 4;
    HI_CHAR ch;

    /**********************************************************
     step  1: init process
    **********************************************************/
    /* step 1.1:  init global  variable */
    gs_s32Cnt = 4; /* venc chn count */
    gs_enPayLoad[0] = PT_H264;
    gs_enPayLoad[1] = PT_H264;
    gs_enPayLoad[2] = PT_H264;
    gs_enPayLoad[3] = PT_H264;

    gs_enSize[0] = PIC_HD1080;
    gs_enSize[1] = PIC_960H;
    gs_enSize[2] = PIC_480H;
    gs_enSize[3] = PIC_480H;

    s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_SYS_DefVb(2, 3, PIC_960H, &gs_stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_SYS_DefVb(4, 5, PIC_480H, &gs_stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_SYS_DefVb(6, 7, PIC_480H, &gs_stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }

    /* step  1.2: process abnormal case */
    signal(SIGINT, SAMPLE_VENC_MixerHandleSig);
    signal(SIGTERM, SAMPLE_VENC_MixerHandleSig);

    /******************************************
     step 2: mpp system init. note: in this case, vb cfg is ineffective. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&gs_stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 3: start vi dev & chn to capture
    ******************************************/
    s32Ret = SAMPLE_COMM_VI_StartTypical(gs_s32Cnt, gs_enSize);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_COMM_SYS_Exit();
        printf("%s: Start Vi failed!\n", __FUNCTION__);
        goto END_MIXER_6;
    }
	
    /******************************************
     step 4: start VO to preview 
    ******************************************/
#ifdef SAMPLE_VENC_MIXER_VO_ENABLE
    s32Ret = SAMPLE_COMM_VO_Start(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start VO failed!\n", __FUNCTION__);
        goto END_MIXER_5;
    }

    gs_ViDevBnd_curr = ViDev;
    gs_ViChnBnd_curr = ViChn;
    s32Ret = SAMPLE_COMM_VI_BindViVo(ViDev, ViChn, VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: vichn vochn bind failed!\n", __FUNCTION__);
        goto END_MIXER_4;
    }
#endif

    /******************************************
     step 5: stream venc start & create process thread 
    ******************************************/
    /* step 5.1 start stream venc */
    for (i=0; i<gs_s32Cnt; i++)
    {
        VencChn = i;
        ViChn = i;
        s32Ret = SAMPLE_COMM_VENC_StreamStart(VencChn, ViChn, gs_enPayLoad[i],\
                                        gs_enSize[i], HI_TRUE, SAMPLE_RC_FIXQP);

        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: Start Venc failed!\n", __FUNCTION__);
            goto END_MIXER_3;
        }
    }
	
    /* step 5.2 start venc process thread to save stream to file */
    s32Ret = SAMPLE_COMM_VENC_StartGetStream(gs_s32Cnt);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END_MIXER_2;
    }

    /******************************************
     step 6: snap venc process.
    ******************************************/
    /* step 6.1 start vi_ext_chn(bind to vichn0)*/
    s32Ret = SAMPLE_COMM_VI_StartExtChn(0, ViChn_SnapExt, HI_FALSE, gs_enSize[0]);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END_MIXER_1;
    }

    /* step 6.2 start snap venc */
    s32Ret = SAMPLE_COMM_VENC_SnapStart(VencChn_Snap, ViChn_SnapExt, gs_enSize[0]);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END_MIXER_0;
    }

    /* step 6.3 snap venc process */
    printf("press 'q' to exit sample!\nperess ENTER to capture one picture to file\n");

    i = 0;
    while ((ch = getchar()) != 'q')
    {
        s32Ret = SAMPLE_COMM_VENC_GetSnapProc(VencChn_Snap, ViChn_SnapExt, gs_enSize[0]);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: sanp process failed!\n", __FUNCTION__);
            break;
        }
        printf("snap %d success!\n", i);
        i++;
    }

    /******************************************
     step 7: stop stream venc & snap venc 
    ******************************************/
END_MIXER_0:
    SAMPLE_COMM_VI_StopChn(ViChn_SnapExt);
    SAMPLE_COMM_VENC_SnapStop(VencChn_Snap);

END_MIXER_1:	
    SAMPLE_COMM_VENC_StopGetStream();
	
END_MIXER_2:
    for (i=0; i<gs_s32Cnt; i++)
    {
        VencChn = i;
        SAMPLE_COMM_VENC_StreamStop(VencChn);
    }

    /******************************************
     step 8: stop vi vo & sys
    ******************************************/
END_MIXER_3:
#ifdef SAMPLE_VENC_MIXER_VO_ENABLE
    SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBnd_curr, gs_ViChnBnd_curr, SAMPLE_VO_DEV_HD, 0);
END_MIXER_4:
    SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
END_MIXER_5:
#endif
    SAMPLE_COMM_VI_StopTypical(gs_s32Cnt);
END_MIXER_6:
    SAMPLE_COMM_SYS_Exit();
    
    return HI_SUCCESS;
}

/******************************************************************************
* function    : main()
* Description : video venc sample
*      0) H264 1080p video encode
*         DC -> VI-PortA VI-CHN0 -> H264 Venc
*      1) MJPEG 1080p video encode
*         DC -> VI-PortA VI-CHN0 -> MJPEG Venc
*      2) JPEG snap video encode
*         DC -> VI-PortA Vi-CHN0 -> JPEG Snap
*      3) mixer vpp + venc
*         DC -> VI-PortA Multi-ViChn -> 1080p@30+720p@30+D1@30+CIF@30+1080pSnap
*      4) mpeg4 d1 video encode
*         DC -> VI-PortA VI-CHN0 -> MPEG4 Venc
******************************************************************************/
int main(int argc, char *argv[])
{
    if ( (argc < 2) || (1 != strlen(argv[1])))
    {
        SAMPLE_VENC_Usage(argv[0]);
        return HI_FAILURE;
    }
    switch (*argv[1])
    {
        case '0':/* 0) H264 1080p video encode */
        case '1':/* 1) MJPEG 1080p video encode */
        case '4':/* 4) MPEG4 D1 video encode */
            SAMPLE_VENC_StreamProcess(*argv[1]);
            break;
        case '2':/* 2) JPEG snap video encode */
            SAMPLE_VENC_SnapProcess(*argv[1]);
            break;
        case '3':/* 2) JPEG snap video encode */
            SAMPLE_VENC_MixerProcess(*argv[1]);
            break;
        default:
            printf("the index is invaild!\n");
            SAMPLE_VENC_Usage(argv[0]);
            return HI_FAILURE;
    }
    return HI_SUCCESS;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
