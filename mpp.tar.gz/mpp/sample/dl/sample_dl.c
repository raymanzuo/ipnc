/******************************************************************************
  A simple program of how to use Hisilicon HI3516 dynamic library.
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-9 Created
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <pthread.h>
#include <assert.h>
#include <signal.h>
#include <dlfcn.h>

#include "hi_common.h"
#include "hi_type.h"
#include "hi_comm_vb.h"
#include "hi_comm_sys.h"
#include "hi_comm_venc.h"
#include "hi_comm_vi.h"
#include "hi_comm_vo.h"

#include "mpi_vb.h"
#include "mpi_sys.h"
#include "mpi_venc.h"
#include "mpi_vi.h"
#include "mpi_vo.h"

#include "hi_comm_isp.h"
#include "mpi_isp.h"

#include "hi_sns_ctrl.h"

#define PANASONIC_34041_1080P		0
#define SONY_IMX036_DC_1080P		1
#define APTINA_9P031_DC_1080P_CONTINUES	2
#define ALTASENS_DC_1080P		3
#define OV_2715_DC_1080P		4

#define APTINA_9M034_DC_720P_CONTINUES	5  // not support in this program
#define APTINA_9P031_DC_1080P_DEFAULT	6  // not support in this program
#define OV_10630_DC_800P		7  // not support in this program

#define SAMPLE_SNS_DL_PATH		"/usr/lib"
#define SAMPLE_SUPPORT_SNS_CNT 		5

struct SAMPLE_SNS_DEF
{
    HI_S32 s32Num;
    HI_CHAR psSnsTypeName[40];
    HI_CHAR psLibName[40];
};

struct SAMPLE_SNS_DEF gstSnsDef[]={
    {PANASONIC_34041_1080P, "PANASONIC_34041_1080P", "libsns_pana.so"}, 
    {SONY_IMX036_DC_1080P, "SONY_IMX036_DC_1080P", "libsns_imx036.so"}, 
    {APTINA_9P031_DC_1080P_CONTINUES, "APTINA_9P031_DC_1080P_CONTINUES", "libsns_aptn.so"}, 
    {ALTASENS_DC_1080P, "ALTASENS_DC_1080P", "libsns_alta.so"}, 
    {OV_2715_DC_1080P, "OV_2715_DC_1080P", "libsns_ov.so"}
};

HI_S32 gs32SnsTypeNum;
static VI_DEV gViDev = 0;
static VI_CHN gViChn = 0;
static VO_DEV gVoDev = 0;
static VO_CHN gVoChn = 0;
static pthread_t gs_IspPid;

/*****************************************************************************
* function : SAMPLE_DL_MPI_Init
*****************************************************************************/
static HI_S32 SAMPLE_DL_MPI_Init()
{
    HI_S32 s32Ret;
    VB_CONF_S struVbConf;
    MPP_SYS_CONF_S struSysConf;

    HI_MPI_SYS_Exit();

    HI_MPI_VB_Exit(); 

    memset(&struVbConf,0,sizeof(VB_CONF_S));
    struVbConf.u32MaxPoolCnt             = 64;
    struVbConf.astCommPool[0].u32BlkSize = 1920*1088*2;
    struVbConf.astCommPool[0].u32BlkCnt  = 25;

    s32Ret = HI_MPI_VB_SetConf(&struVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VB_SetConf failed with %#x\n", s32Ret);
        return s32Ret;
    }

    s32Ret = HI_MPI_VB_Init();
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VB_Init failed with %#x\n", s32Ret);
        return s32Ret;
    }
    struSysConf.u32AlignWidth = 64;
    s32Ret = HI_MPI_SYS_SetConf(&struSysConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_SYS_SetConf: failed with %#x\n",s32Ret);
        (HI_VOID)HI_MPI_VB_Exit();
        return s32Ret;
    }

    s32Ret = HI_MPI_SYS_Init();
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_SYS_Init failed with %#x\n", s32Ret);
        (HI_VOID)HI_MPI_VB_Exit();
        return s32Ret;
    }
    
    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_StartViDev
*****************************************************************************/
HI_S32 SAMPLE_DL_StartViDev(VI_DEV ViDev, HI_S32 s32SnsTypeNum)
{
    HI_S32 s32Ret;
    VI_DEV_ATTR_S    stViDevAttr;

    switch (s32SnsTypeNum)
    {
        case APTINA_9P031_DC_1080P_CONTINUES:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case APTINA_9M034_DC_720P_CONTINUES:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_LOW;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;

        case APTINA_9P031_DC_1080P_DEFAULT:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH; /* difference */
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case PANASONIC_34041_1080P:
        case ALTASENS_DC_1080P:
        case SONY_IMX036_DC_1080P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFF;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_VALID_SINGAL;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case OV_2715_DC_1080P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_SEPARATE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFFC;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_RGB;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enRgbSeq = VI_DATA_SEQ_GRGR;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_TRUE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1920; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 1080; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        case OV_10630_DC_800P:
            stViDevAttr.enInputMode = VI_MODE_DIGITAL_CAMERA; /* vi input mode */
            stViDevAttr.enCombineMode = VI_COMBINE_COMPOSITE; /* combine mode */
            stViDevAttr.enCompMode = VI_COMP_MODE_SINGLE; /* comp mode */
            stViDevAttr.au32CompMask[0] = 0xFF00;  /* comp mask */
            stViDevAttr.au32CompMask[1] = 0x0;  /* comp mask */
            stViDevAttr.enClkEdge = VI_CLK_EDGE_SINGLE_UP; /* clock edge define */
            stViDevAttr.enScanMode = VI_SCAN_PROGRESSIVE;  /* input scan mode */
            stViDevAttr.enDataType = VI_DATA_TYPE_YUV;    /* Date type (RGB or YUV */
            stViDevAttr.unDataSeq.enYuvSeq = VI_INPUT_DATA_YUYV;   /* input data seq (Bayer patten) */
            stViDevAttr.bUseInterISP = HI_FALSE;         /* inside isp or not */
        
            /* syn timing cfg. BT601/DC interface must config! */
            stViDevAttr.stSynCfg.enVsync = VI_VSYNC_PULSE;
            stViDevAttr.stSynCfg.enVsyncNeg = VI_VSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enHsync = VI_HSYNC_VALID_SINGNAL;
            stViDevAttr.stSynCfg.enHsyncNeg = VI_HSYNC_NEG_HIGH;
            stViDevAttr.stSynCfg.enVsyncValid = VI_VSYNC_NORM_PULSE;
            stViDevAttr.stSynCfg.enVsyncValidNeg = VI_VSYNC_VALID_NEG_HIGH;
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHfb = 0; /* horizontal begin blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncAct = 1280; /* horizontal valid width */
            stViDevAttr.stSynCfg.stTimingBlank.u32HsyncHbb = 0; /* horizontal end blank width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOfb = 0; /* frame or interleaved odd picture's vertical begin blanking heigh */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncOAct = 720; /* frame or interleaved odd picture's vertical valid blanking width */
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncObb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEfb = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEAct = 0;
            stViDevAttr.stSynCfg.stTimingBlank.u32VsyncEbb = 0;
        
            stViDevAttr.stBT656SynCfg.enFixCode = BT656_FIXCODE_1;
            stViDevAttr.stBT656SynCfg.enFieldNeg = BT656_FIELD_NEG_STD;
            break;
        default:
            printf("Sensor Type[%d] is invalid!\n", gs32SnsTypeNum);
            return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_SetDevAttr(ViDev, &stViDevAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_SetDevAttr failed with %#x!\n",\
               __FUNCTION__,  s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_EnableDev(ViDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_VI_EnableDev failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VI_Start
*****************************************************************************/
HI_S32 SAMPLE_DL_VI_Start(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    VI_CHN_BIND_ATTR_S stChnBindAttr;

    VI_CHN_ATTR_S stChnAttr = 
    {
        /*crop_x crop_y crop_w  crop_h  chn_w   chn_h*/  
        {0,     0,     1920,   1080 },  
        VI_CAPSEL_BOTH,
        /*chn_w   chn_h*/
        {1920,  1080},
        PIXEL_FORMAT_YUV_SEMIPLANAR_422,
        /*bMirr  bFilp*/
        0,      0,
    };

    stChnBindAttr.enBindType = VI_CHN_BIND_PHYCHN;
    stChnBindAttr.unBindAttr.stBindPhyChn.s32PhyChn = 0;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViDev = gViDev;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViWay = 0;

    s32Ret = HI_MPI_VI_ChnBind(gViChn, &stChnBindAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Bind VI Channel failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_SetChnAttr(gViChn, &stChnAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Set VI Channel attr failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_EnableChn(gViChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Enable VI Channel failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VI_Stop
*****************************************************************************/
HI_S32 SAMPLE_DL_VI_Stop(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    s32Ret = HI_MPI_VI_DisableChn(gViChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Disable VI Channel failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }
    
    s32Ret = HI_MPI_VI_ChnUnBind(gViChn);
    if (s32Ret != HI_SUCCESS)
    {
        printf("UnBind VI Channel failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VI_DisableDev(gViDev);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Disable VI device failed with %#x !\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VI_Stop
*****************************************************************************/
HI_S32 SAMPLE_DL_VO_Start(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    VO_PUB_ATTR_S stPubAttr;
    VO_VIDEO_LAYER_ATTR_S stLayerAttr;
    VO_CHN_ATTR_S stChnAttr;

    HI_MPI_VO_Disable(gVoDev);

    stPubAttr.enIntfType = VO_INTF_BT1120;
    stPubAttr.enIntfSync = VO_OUTPUT_1080P30;
    stPubAttr.u32BgColor = 0x00FF00;
       
    /* Attr of video layer */
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = 1920;
    stLayerAttr.stDispRect.u32Height  = 1080;
    stLayerAttr.stImageSize.u32Width  = 1920;
    stLayerAttr.stImageSize.u32Height = 1080;
    stLayerAttr.u32DispFrmRt          = 50;
    stLayerAttr.enPixFormat           = PIXEL_FORMAT_YUV_SEMIPLANAR_422;
    stLayerAttr.s32PiPChn             = -1;

    /* Attr of vo chn */    
    stChnAttr.stRect.s32X               = 0;
    stChnAttr.stRect.s32Y               = 0;
    stChnAttr.stRect.u32Width           = 1920;
    stChnAttr.stRect.u32Height          = 1080;
    stChnAttr.bZoomEnable               = HI_TRUE;
    stChnAttr.bDeflicker                = HI_FALSE;
    stChnAttr.u32Priority               = 1;

    /* set public attr of VO*/
    if (HI_SUCCESS != HI_MPI_VO_SetPubAttr(gVoDev, &stPubAttr))
    {
        printf("set VO pub attr failed !\n");
        return HI_FAILURE;
    }

    if (HI_SUCCESS != HI_MPI_VO_Enable(gVoDev))
    {
        printf("enable vo device failed!\n");
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_SetVideoLayerAttr(gVoDev, &stLayerAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("set video layer attr failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    if (HI_SUCCESS != HI_MPI_VO_EnableVideoLayer(gVoDev))
    {
        printf("enable video layer failed!\n");
        return HI_FAILURE;
    }

    /* set channel attr of VO*/
    if (HI_SUCCESS != HI_MPI_VO_SetChnAttr(gVoDev, gVoChn, &stChnAttr))
    {
        printf("set VO Chn attribute failed !\n");
        return HI_FAILURE;
    }

    /* enable VO channel*/
    if (HI_SUCCESS != HI_MPI_VO_EnableChn(gVoDev, gVoChn))
    {
        printf("set VO Chn enable failed !\n");
        return HI_FAILURE;
    }
    
    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VIVO_Bind
*****************************************************************************/
HI_S32 SAMPLE_DL_VIVO_Bind(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = gVoChn;
    stBindDest.s32DevId = gVoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = gViChn;
    stBindSrc.s32DevId = gViDev;
    
    s32Ret = HI_MPI_SYS_Bind(&stBindSrc, &stBindDest);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Vi bind Vo faild with %#x\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VIVO_UnBind
*****************************************************************************/
HI_S32 SAMPLE_DL_VIVO_UnBind(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = gVoChn;
    stBindDest.s32DevId = gVoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = gViChn;
    stBindSrc.s32DevId = gViDev;
    
    s32Ret = HI_MPI_SYS_UnBind(&stBindSrc, &stBindDest);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Vi bind Vo faild with %#x\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/*****************************************************************************
* function : SAMPLE_DL_VO_Stop
*****************************************************************************/
HI_S32 SAMPLE_DL_VO_Stop(void)
{    
    if (HI_SUCCESS != HI_MPI_VO_DisableChn(gVoDev, gVoChn))
    {
        printf("set VO Chn enable failed !\n");
        return HI_FAILURE;
    }

    if (HI_SUCCESS != HI_MPI_VO_DisableVideoLayer(gVoDev))
    {
        printf("Disable video layer failed!\n");
        return HI_FAILURE;
    }

    if (HI_SUCCESS != HI_MPI_VO_Disable(gVoDev))
    {
        printf("Disable vo device failed!\n");
        return HI_FAILURE;
    }    

    return HI_SUCCESS;    
}

/******************************************************************************
* funciton : ISP init
******************************************************************************/
HI_S32 SAMPLE_DL_IspInit(void)
{
    HI_S32 s32Ret;
    ISP_IMAGE_ATTR_S stImageAttr;
    ISP_INPUT_TIMING_S stInputTiming;

    /* 1. isp init */
    s32Ret = HI_MPI_ISP_Init();
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_Init failed!\n", __FUNCTION__);
        return s32Ret;
    }

    /* 2. isp set image attributes */
    /* note : different sensor, different ISP_IMAGE_ATTR_S define.
              if the sensor you used is different, you can change 
              ISP_IMAGE_ATTR_S definition */
    if (SONY_IMX036_DC_1080P == gs32SnsTypeNum)
    {
	stImageAttr.enBayer         = BAYER_RGGB;
        stImageAttr.u16FrameRate     = 30;
        stImageAttr.u16Width         = 1920;
        stImageAttr.u16Height         = 1080;
	}
    else if (APTINA_9M034_DC_720P_CONTINUES == gs32SnsTypeNum)
    {
	stImageAttr.enBayer         = BAYER_GRBG;
        stImageAttr.u16FrameRate     = 60;
        stImageAttr.u16Width         = 1280;
        stImageAttr.u16Height         = 720;
    }
	else
    {
        stImageAttr.enBayer         = BAYER_GRBG;
        stImageAttr.u16FrameRate     = 30;
        stImageAttr.u16Width         = 1920;
        stImageAttr.u16Height         = 1080;
    }
    s32Ret = HI_MPI_ISP_SetImageAttr(&stImageAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_SetImageAttr failed with %#x!\n", __FUNCTION__, s32Ret);
        return s32Ret;
    }

    /* 3. isp set timing */
    if (APTINA_9P031_DC_1080P_CONTINUES == gs32SnsTypeNum || OV_2715_DC_1080P == gs32SnsTypeNum)
    {
        stInputTiming.enWndMode = ISP_WIND_NONE;
    }
    else if (PANASONIC_34041_1080P == gs32SnsTypeNum)
    {
        stInputTiming.enWndMode = ISP_WIND_ALL;
        stInputTiming.u16HorWndStart  = 60 ;
        stInputTiming.u16HorWndLength = 1930 ;
        stInputTiming.u16VerWndStart  = 20 ;
        stInputTiming.u16VerWndLength = 1090 ;
    }
    else if (ALTASENS_DC_1080P == gs32SnsTypeNum)
    {
        stInputTiming.enWndMode = ISP_WIND_ALL;
        stInputTiming.u16HorWndStart  = 141;
        stInputTiming.u16HorWndLength = 1930 ;
        stInputTiming.u16VerWndStart  = 45;
        stInputTiming.u16VerWndLength = 1090 ;
    }
    else if (SONY_IMX036_DC_1080P == gs32SnsTypeNum)
    {
        stInputTiming.enWndMode = ISP_WIND_ALL;
        stInputTiming.u16HorWndStart  = 200 ;
        stInputTiming.u16HorWndLength = 1920 ;
        stInputTiming.u16VerWndStart  = 12 ;
        stInputTiming.u16VerWndLength = 1080 ;
    }
    else if (APTINA_9M034_DC_720P_CONTINUES == gs32SnsTypeNum)
    {
        stInputTiming.enWndMode = ISP_WIND_NONE;
    }    
    else
    {
        printf("%s: Sensor Type %d not support!\n", __FUNCTION__, gs32SnsTypeNum);
    }
    s32Ret = HI_MPI_ISP_SetInputTiming(&stInputTiming);    
    if (s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_ISP_SetInputTiming failed with %#x!\n", __FUNCTION__, s32Ret);
        return s32Ret;
    }
    
    return HI_SUCCESS;
}

/******************************************************************************
* funciton : ISP Run
******************************************************************************/
HI_S32 SAMPLE_DL_IspRun()
{
    HI_S32 s32Ret;

    s32Ret = SAMPLE_DL_IspInit();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: ISP init failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    if (0 != pthread_create(&gs_IspPid, 0, (void* (*)(void*))HI_MPI_ISP_Run, NULL))
    {
        printf("%s: create isp running thread failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }
 
    /* load configure file if there is */

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : ISP Stop
******************************************************************************/
HI_S32 SAMPLE_DL_ISP_Stop(void)
{
    HI_MPI_ISP_Exit();
    pthread_join(gs_IspPid, 0);

    return HI_SUCCESS;
}

/******************************************************************************
* funciton : SAMPLE_DL_VI_Prepare
******************************************************************************/
HI_S32 SAMPLE_DL_VI_Prepare(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    HI_CHAR sLibPath[60];
    void *m_psns_lib_handle;
    void (*m_psns_init)();
    int (*m_psns_callback)();
    char *dlsym_error;
    
    sprintf(sLibPath, "%s/%s", SAMPLE_SNS_DL_PATH, gstSnsDef[gs32SnsTypeNum].psLibName);
    printf("libray is [%s]\n", sLibPath);
    m_psns_lib_handle = dlopen(sLibPath, RTLD_LAZY);
    if(NULL == m_psns_lib_handle)
    {
        printf("ERROR : load sns lib error\n");
        return HI_FAILURE;
    }

    m_psns_init = dlsym(m_psns_lib_handle, "sensor_init");
    dlsym_error = dlerror();
    if (dlsym_error)
    {
        printf("ERROR : load fun sensor_init error\n");
        dlclose(m_psns_lib_handle);
        return HI_FAILURE;
    }
    m_psns_callback = dlsym(m_psns_lib_handle, "sensor_register_callback");
    dlsym_error = dlerror();
    if (dlsym_error)
    {
        printf("ERROR : load fun sensor_register_callback error\n");
        dlclose(m_psns_lib_handle);
        return HI_FAILURE;
    }

    /* 1. sensor init */
    //sensor_init();
    m_psns_init();

    /* 2. sensor register callback */
    //s32Ret = sensor_register_callback();
    s32Ret = m_psns_callback();
    if (s32Ret != HI_SUCCESS)
    {
        printf("Sensor register Callback failed with %#x!\n", s32Ret);
        return s32Ret;
    }

    /* 3. configure VI device */
    SAMPLE_DL_StartViDev(gViDev, gs32SnsTypeNum);

    /* 4.  configure & run isp thread */
    s32Ret = SAMPLE_DL_IspRun();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: ISP init failed!\n", __FUNCTION__);
        /* disable videv */
        return HI_FAILURE;
    }


    return HI_SUCCESS;
}

/******************************************************************************
* funciton : SAMPLE_DL_HandleSig
******************************************************************************/
void SAMPLE_DL_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_DL_ISP_Stop();
        SAMPLE_DL_VIVO_UnBind();
        SAMPLE_DL_VO_Stop();
        SAMPLE_DL_VI_Stop();

        /*mpi exit */
        HI_MPI_SYS_Exit();
        HI_MPI_VB_Exit();

        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(HI_FAILURE);
}


/******************************************************************************
* function : show usage
******************************************************************************/
void SAMPLE_DL_Usage(HI_CHAR *sPrgNm)
{
    int i;

    printf("Usage : %s <SensorType>\n", sPrgNm);
    printf("you can use this program to choose the right sensor dynamic library\n");
    printf("you must put the dynamic library to %s!\n", SAMPLE_SNS_DL_PATH);
    printf("you must insmod the right module, before run this program!\n");
    printf("<SensorType>:\n");
    for (i=0; i<SAMPLE_SUPPORT_SNS_CNT; i++)
    {
        printf("\t%d\t%s\t%s\n", gstSnsDef[i].s32Num,\
               gstSnsDef[i].psSnsTypeName, gstSnsDef[i].psLibName);
    }
    return;
}

/******************************************************************************
* function : main
******************************************************************************/
int main(int argc, char *argv[])
{
    HI_S32 s32Ret = HI_SUCCESS;

    if ( (argc < 2) || (atoi(argv[1]) < 0) || (atoi(argv[1]) > SAMPLE_SUPPORT_SNS_CNT))
    {
        SAMPLE_DL_Usage(argv[0]);
        return HI_FAILURE;
    }
    gs32SnsTypeNum = atoi(argv[1]);
    printf("You use [%s].\n", gstSnsDef[gs32SnsTypeNum].psSnsTypeName);

    /******************************************
     step  2: process abnormal case
    ******************************************/
    signal(SIGINT, SAMPLE_DL_HandleSig);
    signal(SIGTERM, SAMPLE_DL_HandleSig);

    
    /* mpi init */
    s32Ret = SAMPLE_DL_MPI_Init();
    if (HI_SUCCESS != s32Ret)
    {
        printf("HI_MPI_VB_SetConf failed\n");
        return s32Ret;
    }
        
    /* configure sensor, ISP and VI device */
    s32Ret = SAMPLE_DL_VI_Prepare();
    if (HI_SUCCESS != s32Ret)
    {
        printf("SAMPLE_DL_VI_Prepare failed\n");
        return s32Ret;
    }

    /* start VI channel to capture */
    s32Ret = SAMPLE_DL_VI_Start();
    if (HI_SUCCESS != s32Ret)
    {
        printf("SAMPLE_DL_VI_Start failed\n");
        return s32Ret;
    }

    /* start VO to preview */
    s32Ret = SAMPLE_DL_VO_Start();
    if (HI_SUCCESS != s32Ret)
    {
        printf("SAMPLE_DL_VO_Start failed\n");
        return s32Ret;
    }

    /* vi bind vo */
    SAMPLE_DL_VIVO_Bind();
    if (HI_SUCCESS != s32Ret)
    {
        printf("SAMPLE_DL_VIVO_Bind failed\n");
        return s32Ret;
    }

    printf("press any key to exit sample!\n");
    getchar();

    /* stop application */
    SAMPLE_DL_VIVO_UnBind();
    SAMPLE_DL_VO_Stop();
    SAMPLE_DL_ISP_Stop();
    SAMPLE_DL_VI_Stop();

    /*mpi exit */
    HI_MPI_SYS_Exit();
    HI_MPI_VB_Exit();

    return HI_SUCCESS;
}
