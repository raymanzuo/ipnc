#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sample_comm.h"

HI_S32 main(HI_S32 argc, HI_CHAR **argv)
{
    HI_CHAR acFileName[200];
    HI_S32  s32Ret;

    if (argc <2)
    {
        strcpy(acFileName, "isp_reg.cfg");
    }
    else
    {
        strcpy(acFileName, argv[1]);
    }
    s32Ret = SAMPLE_COMM_ISP_SaveRegFile(CFG_OPT_SAVE, acFileName);
    if (HI_SUCCESS != s32Ret)
    {
        printf("save file failed!\n");
        return HI_FAILURE;
    }

    printf("save file success!\n");
    return HI_SUCCESS;
}
