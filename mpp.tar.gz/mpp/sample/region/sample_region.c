/******************************************************************************
  A simple program of Hisilicon HI3516 osd implementation.
  the flow as follows:
    1) init mpp system.
    2) start vi ( internal isp, ViDev 0, 2 vichn)                  
    3) start venc
    4) osd process, you can see video from some H264 streams files. the video will show as follows step:
        4.1) create some cover/osd regions
        4.2) display  cover/osd regions ( One Region -- Multi-VencGroup )
        4.3) change all vencGroups Regions' Layer
        4.4) change all vencGroups Regions' position
        4.5) change all vencGroups Regions' color
        4.6) change all vencGroups Regions' alpha (front and backgroud)
        4.7) load bmp form bmp-file to Region-0
        4.8) change BmpRegion-0
    6) stop venc
    7) stop vi and system.
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include "sample_comm.h"
#include "loadbmp.h"

static VB_CONF_S gs_stVbConf ={0};	/* vb config define */
static PAYLOAD_TYPE_E gs_enPayLoad[5];  /* venc payload type */
static PIC_SIZE_E gs_enSize[5];		/* venc picture size */
static HI_U32 gs_s32ChnCnt;		/* vi, venc chn count */
static HI_S32 gs_s32RgnCntCur = 0;
static HI_S32 gs_s32RgnCnt = 0;

#define SAMPLE_OSD_SLEEP_TIME (200*1000)
#define SAMPLE_OSD_LOOP_COUNT 6

#ifndef VI_DEV_A
#define VI_DEV_A 0
#endif

/******************************************************************************
* funciton : osd region change position
******************************************************************************/
HI_S32 SAMPLE_OSD_ChgPosition(RGN_HANDLE RgnHandle, VENC_GRP VencGrp, POINT_S *pstPoint)
{
    MPP_CHN_S stChn;
    RGN_CHN_ATTR_S stChnAttr;
    HI_S32 s32Ret;

    stChn.enModId = HI_ID_GROUP;
    stChn.s32DevId = 0;
    stChn.s32ChnId = VencGrp;

    if (NULL == pstPoint)
    {
        printf("%s: input parameter is null. it is invaild!\n", __FUNCTION__);
        return HI_FAILURE;
    }
        
    s32Ret = HI_MPI_RGN_GetDisplayAttr(RgnHandle, &stChn, &stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_GetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }

    stChnAttr.unChnAttr.stOverlayChn.stPoint.s32X = pstPoint->s32X;
    stChnAttr.unChnAttr.stOverlayChn.stPoint.s32Y = pstPoint->s32Y;
    s32Ret = HI_MPI_RGN_SetDisplayAttr(RgnHandle,&stChn,&stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_SetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }
    
    return HI_SUCCESS;
}

    

/******************************************************************************
* funciton : osd region show or hide
******************************************************************************/
HI_S32 SAMPLE_OSD_ShowOrHide(RGN_HANDLE RgnHandle, VENC_GRP VencGrp, HI_BOOL bShow)
{
    MPP_CHN_S stChn;
    RGN_CHN_ATTR_S stChnAttr;
    HI_S32 s32Ret;

    stChn.enModId = HI_ID_GROUP;
    stChn.s32DevId = 0;
    stChn.s32ChnId = VencGrp;
        
    s32Ret = HI_MPI_RGN_GetDisplayAttr(RgnHandle, &stChn, &stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_GetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }

    stChnAttr.bShow = bShow;
    
    s32Ret = HI_MPI_RGN_SetDisplayAttr(RgnHandle,&stChn,&stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_SetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }
    
    return HI_SUCCESS;
}
    
/******************************************************************************
* funciton : osd region change color
******************************************************************************/
HI_S32 SAMPLE_OSD_ChgColor(RGN_HANDLE RgnHandle, HI_U32 u32Color)
{
    RGN_ATTR_S stRgnAttr;
    HI_S32 s32Ret;

    s32Ret = HI_MPI_RGN_GetAttr(RgnHandle,&stRgnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_GetAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }

    stRgnAttr.unAttr.stOverlay.u32BgColor = u32Color;

    s32Ret = HI_MPI_RGN_SetAttr(RgnHandle,&stRgnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_SetAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}
/******************************************************************************
* funciton : osd region change (bgAlpha, fgAlpha, layer)
******************************************************************************/
HI_S32 SAMPLE_OSD_Change(RGN_HANDLE RgnHandle, VENC_GRP VencGrp, SAMPLE_OSD_CHANGE_TYPE_EN enChangeType, HI_U32 u32Val)
{
    MPP_CHN_S stChn;
    RGN_CHN_ATTR_S stChnAttr;
    HI_S32 s32Ret;

    stChn.enModId = HI_ID_GROUP;
    stChn.s32DevId = 0;
    stChn.s32ChnId = VencGrp;
    s32Ret = HI_MPI_RGN_GetDisplayAttr(RgnHandle,&stChn,&stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_GetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }

    switch (enChangeType)
    {
        case OSD_CHANGE_TYPE_FGALPHA:
            stChnAttr.unChnAttr.stOverlayChn.u32FgAlpha = u32Val;
            break;
        case OSD_CHANGE_TYPE_BGALPHA:
            stChnAttr.unChnAttr.stOverlayChn.u32BgAlpha = u32Val;
            break;
        case OSD_CHANGE_TYPE_LAYER:
            stChnAttr.unChnAttr.stOverlayChn.u32Layer = u32Val;
            break;
        default:
            printf("%s: input paramter invaild!\n", __FUNCTION__);
            return HI_FAILURE;
    }
    s32Ret = HI_MPI_RGN_SetDisplayAttr(RgnHandle,&stChn,&stChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_RGN_SetDisplayAttr (%d)) failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }
    return HI_SUCCESS;
}
 
/******************************************************************************
* funciton : load bmp from file
******************************************************************************/
HI_S32 SAMPLE_OSD_LoadBmp(const HI_CHAR *filename, BITMAP_S *pstBitmap)
{
    OSD_SURFACE_S Surface;
    OSD_BITMAPFILEHEADER bmpFileHeader;
    OSD_BITMAPINFO bmpInfo;

    if(GetBmpInfo(filename,&bmpFileHeader,&bmpInfo) < 0)
    {
		printf("GetBmpInfo err!\n");
        return HI_FAILURE;
    }

    Surface.enColorFmt = OSD_COLOR_FMT_RGB1555;
    
    pstBitmap->pData = malloc(2*(bmpInfo.bmiHeader.biWidth)*(bmpInfo.bmiHeader.biHeight));
	
    if(NULL == pstBitmap->pData)
    {
        printf("malloc osd memroy err!\n");        
        return HI_FAILURE;
    }

    CreateSurfaceByBitMap(filename,&Surface,(HI_U8*)(pstBitmap->pData));
	
    pstBitmap->u32Width = Surface.u16Width;
    pstBitmap->u32Height = Surface.u16Height;
    pstBitmap->enPixelFormat = PIXEL_FORMAT_RGB_1555;		 
	//printf("line:%d\n",__LINE__);
    return HI_SUCCESS;
}

#define START_POINT_X_OFFSET 520
#define START_POINT_Y_OFFSET 320

/******************************************************************************
  function : overlay process                
             1) create some overlay regions
             2) display overlay regions ( One Region -- Multi-VencGroup )
             3) change all vencGroups Regions' Layer
             4) change all vencGroups Regions' position
             5) change all vencGroups Regions' color
             6) load bmp form bmp-file to Region-0 
             7) change all vencGroups Regions' front alpha 
             8) change all vencGroups Regions' backgroud alpha
             9) update bitmap(not support now)
             10) show or hide overlay regions
             11) Detach overlay regions from chn
             12) Detroy overlay regions
******************************************************************************/
HI_S32 SAMPLE_Overlay_Process()
{
    HI_S32 i, j;
    HI_S32 s32Ret = HI_FAILURE;
    RGN_HANDLE RgnHandle;
    RGN_ATTR_S stRgnAttr;
    MPP_CHN_S stChn;
    VENC_GRP VencGrp;
    RGN_CHN_ATTR_S stChnAttr;
    HI_U32 u32Layer;
    HI_U32 u32Color;
    HI_U32 u32Alpha;
    POINT_S stPoint;
    BITMAP_S stBitmap;
    SAMPLE_OSD_CHANGE_TYPE_EN enChangeType;
    HI_BOOL bShow = HI_FALSE;

    /****************************************
     step 1: create overlay regions
    ****************************************/
    for (i=0; i<gs_s32RgnCnt; i++)
    {
        stRgnAttr.enType = OVERLAY_RGN;
        stRgnAttr.unAttr.stOverlay.enPixelFmt = PIXEL_FORMAT_RGB_1555;
        stRgnAttr.unAttr.stOverlay.stSize.u32Width  = 180;
        stRgnAttr.unAttr.stOverlay.stSize.u32Height = 144;
        stRgnAttr.unAttr.stOverlay.u32BgColor = 0x7c00*(i%2) + ((i+1)%2)*0x1f;

        RgnHandle = i;

        s32Ret = HI_MPI_RGN_Create(RgnHandle, &stRgnAttr);
        if(HI_SUCCESS != s32Ret)
        {
            printf("%s: HI_MPI_RGN_Create (%d) failed with %#x!\n", \
                   __FUNCTION__, RgnHandle, s32Ret);
            HI_MPI_RGN_Destroy(RgnHandle);
            return HI_FAILURE;
        }
        gs_s32RgnCntCur ++;
        printf("the handle:%d,creat success!\n",RgnHandle);
    }
    
    /*********************************************
     step 2: display overlay regions to venc groups
    *********************************************/
    for (i=0; i<gs_s32RgnCnt; i++)
    {
        RgnHandle = i;

        for (j=0; j<gs_s32ChnCnt; j++)
        {
            VencGrp = j;
            stChn.enModId = HI_ID_GROUP;
            stChn.s32DevId = 0;
            stChn.s32ChnId = VencGrp;

            stChnAttr.bShow = HI_TRUE;
            stChnAttr.enType = OVERLAY_RGN;
            stChnAttr.unChnAttr.stOverlayChn.stPoint.s32X =(i%3) * 200 + START_POINT_X_OFFSET;
            stChnAttr.unChnAttr.stOverlayChn.stPoint.s32Y =(i/3)*160 + START_POINT_Y_OFFSET;
            stChnAttr.unChnAttr.stOverlayChn.u32BgAlpha = 128;
            stChnAttr.unChnAttr.stOverlayChn.u32FgAlpha = 128;
            stChnAttr.unChnAttr.stOverlayChn.u32Layer = i;

            stChnAttr.unChnAttr.stOverlayChn.stQpInfo.bAbsQp = HI_FALSE;
            stChnAttr.unChnAttr.stOverlayChn.stQpInfo.s32Qp  = 0;

            s32Ret = HI_MPI_RGN_AttachToChn(RgnHandle, &stChn, &stChnAttr);
            if(HI_SUCCESS != s32Ret)
            {
                printf("%s: HI_MPI_RGN_AttachToChn (%d) failed with %#x!\n",\
                       __FUNCTION__, RgnHandle, s32Ret);
                return HI_FAILURE;
            }
        }
    }
    
    usleep(SAMPLE_OSD_SLEEP_TIME*5);
    printf("display region to chn success!\n");

    /*********************************************
     step 3: change overlay regions' position
    *********************************************/
    RgnHandle = 1;

    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencGrp = i;
        stPoint.s32X = 60 + START_POINT_X_OFFSET;
        stPoint.s32Y = 0 + START_POINT_Y_OFFSET;
        s32Ret = SAMPLE_OSD_ChgPosition(RgnHandle, VencGrp, &stPoint);
        if(HI_SUCCESS != s32Ret)
        {
            printf("%s: change region(%d) position failed with %#x!\n",\
                   __FUNCTION__, RgnHandle, s32Ret);
            return HI_FAILURE;
        }
    }
    
    printf("handle:%d,change point success,new point(x:%d,y:%d) !\n", 
           RgnHandle,stPoint.s32X,stPoint.s32Y);
    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*********************************************
     step 4: change layer
    *********************************************/
    RgnHandle = 0;
    enChangeType = OSD_CHANGE_TYPE_LAYER;

    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencGrp = i;
        u32Layer = 2;
        s32Ret = SAMPLE_OSD_Change(RgnHandle, VencGrp, enChangeType, u32Layer);
        if(HI_SUCCESS != s32Ret)
        {
            printf("%s: change region(%d) layer failed with %#x!\n",\
                   __FUNCTION__, RgnHandle, s32Ret);
            return HI_FAILURE;
        }
    }

    printf("handle:%d,change layer success,new layer(%d) !\n",RgnHandle,u32Layer);

    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*********************************************
     step 5: change color
    *********************************************/
    RgnHandle = 2;

    u32Color = 0x7fff;
    s32Ret = SAMPLE_OSD_ChgColor(RgnHandle, u32Color);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: change region(%d) color failed with %#x!\n",\
               __FUNCTION__, RgnHandle, s32Ret);
        return HI_FAILURE;
    }

    printf("handle:%d,change color success,new bg color(0x%x)\n",RgnHandle,u32Color);

    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*********************************************
     step 6: show bitmap
    *********************************************/
    RgnHandle = 0;
    
    s32Ret = SAMPLE_OSD_LoadBmp("mm.bmp", &stBitmap);
    if(HI_SUCCESS != s32Ret)
    {
        printf("%s: load bmp failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_RGN_SetBitMap(RgnHandle,&stBitmap);
    if(s32Ret != HI_SUCCESS)
    {
        printf("%s: HI_MPI_RGN_SetBitMap failed with %#x!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }
    
    if (NULL != stBitmap.pData)
    {
        free(stBitmap.pData);
        stBitmap.pData = NULL;
    }

    usleep(SAMPLE_OSD_SLEEP_TIME*5);
    printf("handle:%d,load bmp success!\n",RgnHandle);
    
    /*********************************************
     step 7: change front alpha
    *********************************************/
    RgnHandle = 0;
    enChangeType = OSD_CHANGE_TYPE_FGALPHA;

    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencGrp = i;
        u32Alpha = 32;
        s32Ret = SAMPLE_OSD_Change(RgnHandle, VencGrp, enChangeType, u32Alpha);
        if(HI_SUCCESS != s32Ret)
        {
            printf("%s: change region(%d) f-alpha failed with %#x!\n",\
                   __FUNCTION__, RgnHandle, s32Ret);
            return HI_FAILURE;
        }
    }

    printf("handle:%d,change front alpha success,the new alpha:%d\n", RgnHandle,u32Alpha);

    usleep(SAMPLE_OSD_SLEEP_TIME*5);
    
    /*********************************************
     step 8: change backgroud alpha
    *********************************************/
    RgnHandle = 0;
    enChangeType = OSD_CHANGE_TYPE_BGALPHA;

    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencGrp = i;
        u32Alpha = 32;
        s32Ret = SAMPLE_OSD_Change(RgnHandle, VencGrp, enChangeType, u32Alpha);
        if(HI_SUCCESS != s32Ret)
        {
            printf("%s: change region(%d) f-alpha failed with %#x!\n",\
                   __FUNCTION__, RgnHandle, s32Ret);
            return HI_FAILURE;
        }
    }

    printf("handle:%d,change backgroud alpha success,the new alpha:%d\n", RgnHandle,u32Alpha);

    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*********************************************
     step 9: update bitmap
    *********************************************/
    /*not support now*/

    /*********************************************
     step 10: show or hide overlay regions
    *********************************************/
    RgnHandle = 4;
    bShow = HI_FALSE;
    
    for (i=0; i<SAMPLE_OSD_LOOP_COUNT; i++)
    {
        for (j=0; j<gs_s32ChnCnt; j++)
        {
            VencGrp = j;
            
            s32Ret = SAMPLE_OSD_ShowOrHide(RgnHandle, VencGrp, bShow);
            if(HI_SUCCESS != s32Ret)
            {
                printf("%s:  region(%d) show failed with %#x!\n",\
                       __FUNCTION__, RgnHandle, s32Ret);
                return HI_FAILURE;
            }
        }

        bShow = !bShow;

        usleep(SAMPLE_OSD_SLEEP_TIME*5);
    }

    printf("handle:%d,show or hide osd success\n", RgnHandle);

    /*********************************************
     step 11: Detach osd from chn
    *********************************************/   
    for (i=0; i<gs_s32RgnCnt; i++)
    {
        RgnHandle = i;

        for (j=0; j<gs_s32ChnCnt; j++)
        {
            VencGrp = j;
            stChn.enModId = HI_ID_GROUP;
            stChn.s32DevId = 0;
            stChn.s32ChnId = VencGrp;

            s32Ret = HI_MPI_RGN_DetachFrmChn(RgnHandle, &stChn);
            if(HI_SUCCESS != s32Ret)
            {
                printf("%s: HI_MPI_RGN_DetachFrmChn (%d) failed with %#x!\n",\
                       __FUNCTION__, RgnHandle, s32Ret);
                return HI_FAILURE;
            }
        }

         printf("Detach handle:%d from chn success\n", RgnHandle);

         usleep(SAMPLE_OSD_SLEEP_TIME*5);
    }

    /*********************************************
     step 12: destory region
    *********************************************/
    for (i=0; i<gs_s32RgnCnt; i++)
    {
        RgnHandle = i;
        s32Ret = HI_MPI_RGN_Destroy(RgnHandle);
        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: HI_MPI_RGN_Destroy [%d] failed with %#x\n",\
                    __FUNCTION__, RgnHandle, s32Ret);
        }
    }
    printf("destory all region success!\n");
    return HI_SUCCESS;
}


/******************************************************************************
  function : region process                
             1) enable vpp, but disable IE
             2) create an cover region and attach it to vi chn0
             3) create an overlay region and attach it to venc group chn0
             4) change the cover's position,size, color and layer
             5) change the overlay's position and layer
             6) change the overlay's alpha (front and backgroud) 
             7) hide the cover and the overlay
             8) release resource
******************************************************************************/
HI_S32 SAMPLE_Region_Process()
{
    HI_S32 s32Ret = HI_FAILURE;
    GROUP_VPP_CFG_S stGrpVppAttr;
    
    RGN_HANDLE coverHandle;
    RGN_ATTR_S stCoverAttr;
    MPP_CHN_S stCoverChn;
    RGN_CHN_ATTR_S stCoverChnAttr;
    
    RGN_HANDLE overlayHandle;
    RGN_ATTR_S stOverlayAttr;
    MPP_CHN_S stOverlayChn;
    RGN_CHN_ATTR_S stOverlayChnAttr;
    VENC_GRP VencGrp;
    VI_CHN ViChn;

    HI_U32 u32Alpha;
    BITMAP_S stBitmap;
    SAMPLE_OSD_CHANGE_TYPE_EN enChangeType;
    HI_BOOL bShow = HI_FALSE;

    /***************************************************
     step 1: enable vpp because overlay needs it, disable 
     IE because the histinfo has been invalid after cover
    ****************************************************/ 
    HI_MPI_VENC_GetVppCfg(0, &stGrpVppAttr);
    stGrpVppAttr.stVppCfg.bVppEn = HI_TRUE;   
    if (HI_MPI_VENC_SetVppCfg(0, &stGrpVppAttr))
    {
        return HI_FAILURE;
    }
    
    printf("enable vpp success --- no cover or overlay\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*******************************************************
     step 2: create an cover region and attach it to vi chn0
    ********************************************************/ 
    ViChn = 0;
    coverHandle = 0;
    stCoverAttr.enType = VICOVER_RGN;
    s32Ret = HI_MPI_RGN_Create(coverHandle, &stCoverAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        return HI_FAILURE;
    }

    stCoverChn.enModId = HI_ID_VIU;
    stCoverChn.s32ChnId = ViChn;
    stCoverChn.s32DevId = VI_DEV_A;

    stCoverChnAttr.bShow = HI_TRUE;
    stCoverChnAttr.enType = VICOVER_RGN;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.s32X = 12;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.s32Y = 12;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.u32Width = 160;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.u32Height = 160;
    stCoverChnAttr.unChnAttr.stVicoverChn.u32Color = 0xff;
    stCoverChnAttr.unChnAttr.stVicoverChn.u32Layer = 0;       
    s32Ret = HI_MPI_RGN_AttachToChn(coverHandle, &stCoverChn, &stCoverChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
       goto AttachCover_failed;
    }
    
    printf("create an cover region and attach it to vi chn0\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*****************************************************************
     step 3: create an overlay region and attach it to venc group chn0
    ******************************************************************/
    s32Ret = SAMPLE_OSD_LoadBmp("mm.bmp", &stBitmap);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto LoadBitmap_failed;
    }
    VencGrp = 0;
    overlayHandle = 1;
    stOverlayAttr.enType = OVERLAY_RGN;
    stOverlayAttr.unAttr.stOverlay.enPixelFmt = PIXEL_FORMAT_RGB_1555;
    stOverlayAttr.unAttr.stOverlay.stSize.u32Width  = stBitmap.u32Width;
    stOverlayAttr.unAttr.stOverlay.stSize.u32Height = stBitmap.u32Height;
    stOverlayAttr.unAttr.stOverlay.u32BgColor = 0xfc00;     
    s32Ret = HI_MPI_RGN_Create(overlayHandle, &stOverlayAttr);
    if(HI_SUCCESS != s32Ret)
    {
       printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
       goto CreateOverlay_failed;
    }
    
    s32Ret = HI_MPI_RGN_SetBitMap(overlayHandle, &stBitmap);
    if(s32Ret != HI_SUCCESS)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto SetBitMap_failed;
    }

    stOverlayChn.enModId = HI_ID_GROUP;
    stOverlayChn.s32ChnId = VencGrp;
    stOverlayChn.s32DevId = 0;

    stOverlayChnAttr.bShow = HI_TRUE;
    stOverlayChnAttr.enType = OVERLAY_RGN;
    stOverlayChnAttr.unChnAttr.stOverlayChn.stPoint.s32X = 400;
    stOverlayChnAttr.unChnAttr.stOverlayChn.stPoint.s32Y = 400;
    stOverlayChnAttr.unChnAttr.stOverlayChn.u32BgAlpha = 128;
    stOverlayChnAttr.unChnAttr.stOverlayChn.u32FgAlpha = 128;
    stOverlayChnAttr.unChnAttr.stOverlayChn.u32Layer = 0;  
    stOverlayChnAttr.unChnAttr.stOverlayChn.stQpInfo.bAbsQp = HI_FALSE;
    stOverlayChnAttr.unChnAttr.stOverlayChn.stQpInfo.s32Qp  = 0;  
    s32Ret = HI_MPI_RGN_AttachToChn(overlayHandle, &stOverlayChn, &stOverlayChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto AttachOverlay_failed;
    }
    
    printf("create overlay and attach it success\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);
    
    /**********************************************************
      step 4: change the cover's position, size, color and layer
     **********************************************************/
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.s32X = 100;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.s32Y = 82;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.u32Width = 260;
    stCoverChnAttr.unChnAttr.stVicoverChn.stRect.u32Height = 260;
    stCoverChnAttr.unChnAttr.stVicoverChn.u32Color = 0xf800;
    stCoverChnAttr.unChnAttr.stVicoverChn.u32Layer = 1;
    s32Ret = HI_MPI_RGN_SetDisplayAttr(coverHandle, &stCoverChn, &stCoverChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }
    
    /**********************************************
     step 5: change the overlay's position and layer
    ***********************************************/
    stOverlayChnAttr.unChnAttr.stOverlayChn.stPoint.s32X = 280;
    stOverlayChnAttr.unChnAttr.stOverlayChn.stPoint.s32Y = 280;
    stOverlayChnAttr.unChnAttr.stOverlayChn.u32Layer = 2;  
    s32Ret = HI_MPI_RGN_SetDisplayAttr(overlayHandle, &stOverlayChn, &stOverlayChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }
    
    printf("create an overlay region and attach it to venc group chn0\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);

    /*********************************************
     step 6: change the overlay's alpha
    *********************************************/
    enChangeType = OSD_CHANGE_TYPE_FGALPHA;
    u32Alpha = 52;
    s32Ret = SAMPLE_OSD_Change(overlayHandle, VencGrp, enChangeType, u32Alpha);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }

    enChangeType = OSD_CHANGE_TYPE_BGALPHA;
    u32Alpha = 52;
    s32Ret = SAMPLE_OSD_Change(overlayHandle, VencGrp, enChangeType, u32Alpha);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }
    
    printf("change the overlay's alpha success\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);
    
   /*********************************************
     step 7: hide the cover and the overlay
    *********************************************/
    bShow = HI_FALSE;
    s32Ret = SAMPLE_OSD_ShowOrHide(overlayHandle, VencGrp, bShow);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }
    
    stCoverChnAttr.bShow = HI_FALSE;
    s32Ret = HI_MPI_RGN_SetDisplayAttr(coverHandle, &stCoverChn, &stCoverChnAttr);
    if(HI_SUCCESS != s32Ret)
    {
        printf("Fun:%s line:%u failed with %#x!\n", __FUNCTION__, __LINE__, s32Ret);
        goto exit;
    }
    
    printf("hide the cover and the overlay success\n");
    usleep(SAMPLE_OSD_SLEEP_TIME*5);

   /*********************************************
     step 8: release resource
    *********************************************/

exit:
    HI_MPI_RGN_DetachFrmChn(overlayHandle, &stOverlayChn);  
AttachOverlay_failed: 
SetBitMap_failed:
    HI_MPI_RGN_Destroy(overlayHandle);    
CreateOverlay_failed:
    if (NULL != stBitmap.pData)
    {
        free(stBitmap.pData);
        stBitmap.pData = NULL;
    }
LoadBitmap_failed:  
    HI_MPI_RGN_DetachFrmChn(coverHandle, &stCoverChn);
AttachCover_failed:
    HI_MPI_RGN_Destroy(coverHandle);
    return s32Ret;
}


void SAMPLE_OSD_Usage(HI_CHAR *sPrgNm)
{
    printf("Usage : %s <index>\n", sPrgNm);
    printf("index:\n");
    printf("\t 0) HD Venc + Overlay\n");
    printf("\t    DC -> VI-PortA VI-CHN0 -> Overlay Process -> H264 Venc\n");
    printf("\t 1) HD Venc + Cover/Overlay\n");
    printf("\t    DC -> VI-PortA VI-CHN0 -> Cover/Overlay Process -> H264 Venc\n");
    return;
}

/******************************************************************************
* function : check and init global var. 
******************************************************************************/
HI_S32 SAMPLE_OSD_InitPara(int argc, char **argv)
{
    if ( (argc < 2) || (1 != strlen(argv[1])))
    {
        SAMPLE_OSD_Usage(argv[0]);
        return HI_FAILURE;
    }
    switch (*argv[1])
    {
        case '0':
        case '1':     /* fall through */
            gs_s32RgnCnt = OVERLAY_MAX_NUM;
            gs_s32ChnCnt = 1;
            gs_enPayLoad[0] = PT_H264;
            gs_enSize[0] = PIC_HD1080;
            HI_S32 s32Ret;

            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }

            return HI_SUCCESS;
            
        default:
            SAMPLE_OSD_Usage(argv[0]);
            return HI_FAILURE;
    }
    
}

/******************************************************************************
* function : to process abnormal case                                        
******************************************************************************/
void SAMPLE_OSD_HandleSig(HI_S32 signo)
{
    HI_S32 i;
    VENC_CHN VencChn;
    if (SIGINT == signo || SIGTSTP == signo)
    {
        HI_MPI_RGN_Destroy(gs_s32RgnCntCur);
        SAMPLE_COMM_VENC_StopGetStream();
        for (i=0; i<gs_s32ChnCnt; i++)
        {
            VencChn = i;
            SAMPLE_COMM_VENC_StreamStop(VencChn);
        }
        SAMPLE_COMM_VI_StopTypical(gs_s32ChnCnt);
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function    : main() 
* Description : Cover/Overlay + H.264 Venc
*               
******************************************************************************/
int main(int argc, char *argv[])
{
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;
    VENC_CHN VencChn;
    VI_CHN ViChn;

    /******************************************
     step  1: init global  variable 
    ******************************************/
    s32Ret = SAMPLE_OSD_InitPara(argc, argv);
    if (HI_SUCCESS != s32Ret)
    {
        return HI_FAILURE;
    }
    
    /******************************************
     step  2: process abnormal case 
    ******************************************/
    signal(SIGINT, SAMPLE_OSD_HandleSig);
    signal(SIGTERM, SAMPLE_OSD_HandleSig);

    /******************************************
     step  3: mpp system init. note: in this case, vb cfg is ineffective. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&gs_stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step  4: start vi dev & chn to capture
    ******************************************/
    s32Ret = SAMPLE_COMM_VI_StartTypical(gs_s32ChnCnt, gs_enSize);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Vi failed!\n", __FUNCTION__);
        goto END4;
    }

    /******************************************
     step  5: start venc 
    ******************************************/
    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencChn = i;
        ViChn = i;
        s32Ret = SAMPLE_COMM_VENC_StreamStart(VencChn, ViChn, gs_enPayLoad[i],\
                                       gs_enSize[i], HI_FALSE, SAMPLE_RC_FIXQP);

        if (HI_SUCCESS != s32Ret)
        {
            printf("%s: Start Venc failed!\n", __FUNCTION__);
            goto END3;
        }
    }

    /******************************************
     step  6: venc process 
    ******************************************/
    s32Ret = SAMPLE_COMM_VENC_StartGetStream(gs_s32ChnCnt);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Venc failed!\n", __FUNCTION__);
        goto END2;
    }

    /******************************************
     step  7: osd process
    ******************************************/
    switch (*argv[1])
    {
        case '0':
            s32Ret = SAMPLE_Overlay_Process();
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: osd process failed!\n", __FUNCTION__);
            }
            break;
            
        case '1':
            s32Ret = SAMPLE_Region_Process();
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: overlay process failed!\n", __FUNCTION__);
            }
            break;
            
        default:
            break;
    }
 
    /******************************************
     step  8: stop venc 
    ******************************************/
    SAMPLE_COMM_VENC_StopGetStream();
END2:
    for (i=0; i<gs_s32ChnCnt; i++)
    {
        VencChn = i;
        SAMPLE_COMM_VENC_StreamStop(VencChn);
    }

    /******************************************
     step  9: stop vi & sys
    ******************************************/
END3:
    SAMPLE_COMM_VI_StopTypical(gs_s32ChnCnt);
END4:
    SAMPLE_COMM_SYS_Exit();
    
    if (HI_SUCCESS != s32Ret)
    {
	printf("program exit abnormally!\n");
    }
    else
    {
        printf("program exit normally!\n");
    }
    return s32Ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
