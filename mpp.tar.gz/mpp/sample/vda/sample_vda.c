/******************************************************************************
  A simple program of Hisilicon HI3516 vda implementation.
  the flow as follows:
    1) init mpp system.
    2) start vi( internal isp, ViDev 0, vichn0) and vo (HD)                  
    3) vda md & od start & print information
    4) stop vi vo and system.
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

#include "sample_comm.h"
#include "loadbmp.h"

/******************************************************************************
* function : to process abnormal case                                        
******************************************************************************/
void SAMPLE_VDA_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function      : main() 
* Description : Vi/VO + VDA(MD&OD)
*               DC -> VI-PortA ViChn0(1080p) -> VO HD
*                              ViChn1(D1)    -> VdaChn0 MD
*                                            -> VdaChn1 OD
******************************************************************************/
int main(int argc, char *argv[])
{
    HI_S32 s32Ret = HI_SUCCESS;
    VI_DEV ViDev = 0;
    VI_CHN ViChn_Vo, ViChn_Md, ViChn_Od;
    VO_DEV VoDev = SAMPLE_VO_DEV_HD;
    VO_CHN VoChn = 0;
    VDA_CHN VdaChn_Md, VdaChn_Od;
    VB_CONF_S stVbConf ={0};	/* vb config define */
    PIC_SIZE_E enSize[5]; 	/* vichn picture size */
    PIC_SIZE_E enSize_Md, enSize_Od; 	/* vda picture size */
    HI_U32 s32ChnCnt ;          /* vi chn count */

    /******************************************
     step  1: system init
    ******************************************/
    /* init var. */
    enSize[0] = PIC_HD1080; /* vichn picture size, vichn0 for preview */
    enSize[1] = PIC_D1;		
    s32ChnCnt = 2; 	              /* vi chn count, vichn1 for vda */

    ViChn_Vo = 0;
    ViChn_Md = 1;
    ViChn_Od = 1;

    VdaChn_Md = 0;
    VdaChn_Od = 1;

    enSize_Md = PIC_D1;
    enSize_Od = PIC_D1;

    /* signal process */
    signal(SIGINT, SAMPLE_VDA_HandleSig);
    signal(SIGTERM, SAMPLE_VDA_HandleSig);

    /* mpp init */
    s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_SYS_DefVb(2, 3, PIC_D1, &stVbConf);
    if (HI_FAILURE == s32Ret)
    {
        return HI_FAILURE;
    }
    s32Ret = SAMPLE_COMM_SYS_Init(&stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step  2: start vi & vo
    ******************************************/
    /* start vi */
    s32Ret = SAMPLE_COMM_VI_StartTypical(s32ChnCnt, enSize);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start Vi failed!\n", __FUNCTION__);
        goto END5;
    }

    /* start vo */
    s32Ret = SAMPLE_COMM_VO_Start(VoDev);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start VO failed!\n", __FUNCTION__);
        goto END4;
    }

    /* vi bind vo_hd */
    s32Ret = SAMPLE_COMM_VI_BindViVo(ViDev, ViChn_Vo, VoDev, VoChn);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: vichn vochn bind failed!\n", __FUNCTION__);
        goto END3;
    }

    /******************************************
     step  3: VDA process
    ******************************************/
    s32Ret = SAMPLE_COMM_VDA_MdStart(VdaChn_Md, ViChn_Md, enSize_Md);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: VDA Md Start failed!\n", __FUNCTION__);
        goto END2;
    }
    s32Ret = SAMPLE_COMM_VDA_OdStart(VdaChn_Od, ViChn_Od, enSize_Od);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: VDA OD Start failed!\n", __FUNCTION__);
        goto END1;
    }

    printf("Press any key to stop!");
    getchar();

    SAMPLE_COMM_VDA_OdStop(VdaChn_Od, ViChn_Od);
END1:
    SAMPLE_COMM_VDA_MdStop(VdaChn_Md, ViChn_Md);
    /******************************************
     step  4: stop vi vo & sys
    ******************************************/
END2:
    SAMPLE_COMM_VI_UnBindViVo(ViDev, ViChn_Vo, VoDev, VoChn);
END3:
    SAMPLE_COMM_VO_Stop(SAMPLE_VO_DEV_HD);
END4:
    SAMPLE_COMM_VI_StopTypical(s32ChnCnt);
END5:
    SAMPLE_COMM_SYS_Exit();
    
    if (HI_SUCCESS != s32Ret)
    {
	printf("program exit abnormally!\n");
    }
    else
    {
        printf("program exit normally!\n");
    }
    return s32Ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
