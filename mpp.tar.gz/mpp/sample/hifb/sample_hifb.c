/******************************************************************************

  Copyright (C), 2001-2011, Hisilicon Tech. Co., Ltd.

 ******************************************************************************
  File Name     : sample_hifb.c
  Version       : Initial Draft
  Author        : Hisilicon multimedia software group
  Created       : 2011/06/15
  Description   : 
  History       :
  1.Date        : 2011/06/15
    Author      : j00169368
    Modification: Created file

******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <sys/time.h>
#include <sys/mman.h>   //mmap
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <assert.h>
#include <signal.h>

#include "hi_common.h"
#include "hi_type.h"
#include "hi_comm_vb.h"
#include "hi_comm_sys.h"
#include "hi_comm_venc.h"
#include "hi_comm_vi.h"
#include "hi_comm_vo.h"
#include "hi_comm_group.h"
#include "hi_comm_region.h"

#include "mpi_vb.h"
#include "mpi_sys.h"
#include "mpi_venc.h"
//#include "mpi_md.h"
#include "mpi_vi.h"
#include "mpi_vo.h"
#include "mpi_region.h"

#include "hi_comm_isp.h"
#include "mpi_isp.h"

#include "hi_sns_ctrl.h"

#include <linux/fb.h>
#include "hifb.h"

#include "loadbmp.h"

static VI_DEV ViDev = 0;
static VI_CHN ViChn = 0;
static VO_DEV VoDev = 0;
static VO_CHN VoChn = 0;

static pthread_t isp_pid;

static HI_S32 SAMPLE_HIFB_MPI_Init()
{
	HI_S32 s32ret;
	VB_CONF_S struVbConf;
	MPP_SYS_CONF_S struSysConf;

    HI_MPI_SYS_Exit();

    HI_MPI_VB_Exit(); 

	memset(&struVbConf,0,sizeof(VB_CONF_S));
#if 1
	struVbConf.u32MaxPoolCnt             = 64;
	struVbConf.astCommPool[0].u32BlkSize = 1920*1088*2;
	struVbConf.astCommPool[0].u32BlkCnt  = 25;
#endif

    s32ret = HI_MPI_VB_SetConf(&struVbConf);


	if (HI_SUCCESS != s32ret)
	{
		printf("HI_MPI_VB_SetConf\n");
		return s32ret;
	}
	s32ret = HI_MPI_VB_Init();
	if (HI_SUCCESS != s32ret)
	{
		printf("HI_MPI_VB_Init\n");
		return s32ret;
	}
	struSysConf.u32AlignWidth = 64;
	s32ret = HI_MPI_SYS_SetConf(&struSysConf);

	if (HI_SUCCESS != s32ret)
	{
		printf("HI_MPI_SYS_SetConf:0x%x\n",s32ret);
		(HI_VOID)HI_MPI_VB_Exit();
		return s32ret;
	}
	s32ret = HI_MPI_SYS_Init();

	if (HI_SUCCESS != s32ret)
	{
		printf("HI_MPI_SYS_Init\n");
		(HI_VOID)HI_MPI_VB_Exit();
		return s32ret;
	}
    
    return 0;
}

HI_S32 SAMPLE_HIFB_VI_Start_Dev(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
	VI_DEV_ATTR_S stDevAttr[2] = 
	{
		{
	        VI_MODE_DIGITAL_CAMERA,
	        VI_COMBINE_SEPARATE,
	        VI_COMP_MODE_SINGLE,
	        {0xFFF,    0x0},
	        VI_CLK_EDGE_SINGLE_UP,
	        VI_SCAN_PROGRESSIVE,
	        VI_DATA_TYPE_RGB,
	        {VI_DATA_SEQ_GRGR},
	         HI_TRUE,
	         
	        {
	        /*port_vsync   port_vsync_neg     port_hsync        port_hsync_neg        */
            #if 0
            VI_VSYNC_PULSE, VI_VSYNC_NEG_LOW, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
	        #else
            VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_VALID_SINGAL,VI_VSYNC_VALID_NEG_HIGH,
            #endif
	        /*hsync_hfb    hsync_act    hsync_hhb*/
	        {0,            1920,        0,
	        /*vsync0_vhb vsync0_act vsync0_hhb*/
	         0,            1080,        0,
	        /*vsync1_vhb vsync1_act vsync1_hhb*/ 
	         0,            0,            0}
	        },
	        {
	         BT656_FIXCODE_1,BT656_FIELD_NEG_STD
	        }
		},
		
		{
		    VI_MODE_DIGITAL_CAMERA,
		    VI_COMBINE_SEPARATE,
		    VI_COMP_MODE_SINGLE,
		    /* r_mask    g_mask    b_mask*/
		    {0xFFC,    0x0},
		    VI_CLK_EDGE_SINGLE_UP,
		    VI_SCAN_PROGRESSIVE,
		    VI_DATA_TYPE_RGB,
		    {VI_DATA_SEQ_GRGR},
		     HI_TRUE,
		     
		    {
		    /*port_vsync   port_vsync_neg     port_hsync        port_hsync_neg        */
		    VI_VSYNC_PULSE, VI_VSYNC_NEG_HIGH, VI_HSYNC_VALID_SINGNAL,VI_HSYNC_NEG_HIGH,VI_VSYNC_NORM_PULSE,VI_VSYNC_VALID_NEG_HIGH,
		    
		    /*hsync_hfb    hsync_act    hsync_hhb*/
		    {0,            1920,        0,
		    /*vsync0_vhb vsync0_act vsync0_hhb*/
		     0,            1080,        0,
		    /*vsync1_vhb vsync1_act vsync1_hhb*/ 
		     0,            0,            0}
		    },
		    {
		     BT656_FIXCODE_1,BT656_FIELD_NEG_STD
		    }
		}		
	};

	s32Ret = HI_MPI_VI_SetDevAttr(ViDev, &stDevAttr[0]);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Set VI device attribute failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

	s32Ret = HI_MPI_VI_EnableDev(ViDev);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Enable VI device failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

    return HI_SUCCESS;
}

HI_S32 SAMPLE_HIFB_VI_Start(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
	VI_CHN_BIND_ATTR_S stChnBindAttr;

	VI_CHN_ATTR_S stChnAttr = 
    {
        /*crop_x crop_y crop_w  crop_h  chn_w   chn_h*/  
        {0,     0,     1920,   1080 },  
        VI_CAPSEL_BOTH,
        /*chn_w   chn_h*/
        {1920,  1080},
        PIXEL_FORMAT_YUV_SEMIPLANAR_422,
        /*bMirr  bFilp*/
        0,      0,
	};

	stChnBindAttr.enBindType = VI_CHN_BIND_PHYCHN;
	stChnBindAttr.unBindAttr.stBindPhyChn.s32PhyChn = 0;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViDev = ViDev;
    stChnBindAttr.unBindAttr.stBindPhyChn.ViWay = 0;

	s32Ret = HI_MPI_VI_ChnBind(ViChn, &stChnBindAttr);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Bind VI Channel failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

	s32Ret = HI_MPI_VI_SetChnAttr(ViChn, &stChnAttr);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Set VI Channel attr failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

	s32Ret = HI_MPI_VI_EnableChn(ViChn);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Enable VI Channel failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

    return HI_SUCCESS;
}

HI_S32 SAMPLE_HIFB_VI_Stop(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
	s32Ret = HI_MPI_VI_DisableChn(ViChn);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Disable VI Channel failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}
	
	s32Ret = HI_MPI_VI_ChnUnBind(ViChn);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("UnBind VI Channel failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

	s32Ret = HI_MPI_VI_DisableDev(ViDev);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Disable VI device failed with %#x !\n", s32Ret);
	    return HI_FAILURE;
	}

    return HI_SUCCESS;
}


HI_S32 SAMPLE_HIFB_VO_Start(void)
{
#define HIFB_HD_WIDTH  1280
#define HIFB_HD_HEIGHT 720

    HI_S32 s32Ret = HI_SUCCESS;
    
    VO_PUB_ATTR_S stPubAttr;
    VO_VIDEO_LAYER_ATTR_S stLayerAttr;
    VO_CHN_ATTR_S stChnAttr;

    HI_MPI_VO_Disable(VoDev);

    stPubAttr.enIntfType = VO_INTF_BT1120;
    stPubAttr.enIntfSync = VO_OUTPUT_720P60;
    stPubAttr.u32BgColor = 0x00FF00;
       
    /* Attr of video layer */
    stLayerAttr.stDispRect.s32X       = 0;
    stLayerAttr.stDispRect.s32Y       = 0;
    stLayerAttr.stDispRect.u32Width   = HIFB_HD_WIDTH;
    stLayerAttr.stDispRect.u32Height  = HIFB_HD_HEIGHT;
    stLayerAttr.stImageSize.u32Width  = HIFB_HD_WIDTH;
    stLayerAttr.stImageSize.u32Height = HIFB_HD_HEIGHT;
    stLayerAttr.u32DispFrmRt          = 50;
    stLayerAttr.enPixFormat           = PIXEL_FORMAT_YUV_SEMIPLANAR_422;
    stLayerAttr.s32PiPChn             = 0;

    /* Attr of vo chn */    
    stChnAttr.stRect.s32X               = 0;
    stChnAttr.stRect.s32Y               = 0;
    stChnAttr.stRect.u32Width           = HIFB_HD_WIDTH;
    stChnAttr.stRect.u32Height          = HIFB_HD_HEIGHT;
    stChnAttr.bZoomEnable               = HI_TRUE;
    stChnAttr.bDeflicker                = HI_FALSE;
    stChnAttr.u32Priority               = 1;

    
    /* set public attr of VO*/
    if (HI_SUCCESS != HI_MPI_VO_SetPubAttr(VoDev, &stPubAttr))
    {
        printf("set VO pub attr failed !\n");
        return -1;
    }

    if (HI_SUCCESS != HI_MPI_VO_Enable(VoDev))
    {
        printf("enable vo device failed!\n");
        return -1;
    }

	s32Ret = HI_MPI_VO_SetVideoLayerAttr(VoDev, &stLayerAttr);
    if (s32Ret != HI_SUCCESS)
    {
        printf("set video layer attr failed with %#x!\n", s32Ret);
        return -1;
    }

    if (HI_SUCCESS != HI_MPI_VO_EnableVideoLayer(VoDev))
    {
        printf("enable video layer failed!\n");
        return -1;
    }

    /* set channel attr of VO*/
    if (HI_SUCCESS != HI_MPI_VO_SetChnAttr(VoDev, VoChn, &stChnAttr))
    {
        printf("set VO Chn attribute failed !\n");
        return -1;
    }

    /* enable VO channel*/
    if (HI_SUCCESS != HI_MPI_VO_EnableChn(VoDev, VoChn))
    {
        printf("set VO Chn enable failed !\n");
        return -1;
    }
    
    return 0;
}

HI_S32 SAMPLE_HIFB_VIVO_Bind(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = VoChn;
    stBindDest.s32DevId = VoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = ViChn;
    stBindSrc.s32DevId = ViDev;
    
    s32Ret = HI_MPI_SYS_Bind(&stBindSrc, &stBindDest);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Vi bind Vo faild with %#x\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

HI_S32 SAMPLE_HIFB_VIVO_UnBind(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
    MPP_CHN_S stBindSrc;
    MPP_CHN_S stBindDest;
    
    stBindDest.enModId = HI_ID_VOU;
    stBindDest.s32ChnId = VoChn;
    stBindDest.s32DevId = VoDev;
    stBindSrc.enModId = HI_ID_VIU;
    stBindSrc.s32ChnId = ViChn;
    stBindSrc.s32DevId = ViDev;
    
    s32Ret = HI_MPI_SYS_UnBind(&stBindSrc, &stBindDest);
    if (s32Ret != HI_SUCCESS)
    {
        printf("Vi bind Vo faild with %#x\n", s32Ret);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

HI_S32 SAMPLE_HIFB_VO_Stop(void)
{    
    if (HI_SUCCESS != HI_MPI_VO_DisableChn(VoDev, VoChn))
    {
        printf("set VO Chn enable failed !\n");
        return -1;
    }

    if (HI_SUCCESS != HI_MPI_VO_DisableVideoLayer(VoDev))
    {
        printf("Disable video layer failed!\n");
        return -1;
    }

    if (HI_SUCCESS != HI_MPI_VO_Disable(VoDev))
    {
        printf("Disable vo device failed!\n");
        return -1;
    }    

    return 0;    
}


HI_S32 SAMPLE_HIFB_ISP_Run(void *param)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
	ISP_IMAGE_ATTR_S stImageAttr;
	ISP_INPUT_TIMING_S stInputTiming;

	/* 1. isp init                                                             */
	s32Ret = HI_MPI_ISP_Init();
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Isp init failed!\n");
	    return s32Ret;
	}

	/* 2. isp set image attributes                                             */
	stImageAttr.enBayer 		= BAYER_GRBG;
	stImageAttr.u16FrameRate 	= 30;
	stImageAttr.u16Width 		= 1920;
	stImageAttr.u16Height 		= 1080;
	s32Ret = HI_MPI_ISP_SetImageAttr(&stImageAttr);
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Set Isp image attr failed with %#x!\n", s32Ret);
	    return s32Ret;
	}

	/* 3. isp set timing                                                       */
	stInputTiming.enWndMode = ISP_WIND_ALL;
	s32Ret = HI_MPI_ISP_SetInputTiming(&stInputTiming);	
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Set Isp timing failed with %#x!\n", s32Ret);
	    return s32Ret;
	}

	/* 4. load configure file if there is                                      */
	
	/* 5. Run loop, exit until HI_MPI_ISP_Exit() been called!				   */
	s32Ret = HI_MPI_ISP_Run();
	if (s32Ret != HI_SUCCESS)
	{
	    printf("ISP firmware abnormally exit with %#x!\n", s32Ret);
	    return s32Ret;
	}

	return HI_SUCCESS;
}

HI_S32 SAMPLE_HIFB_ISP_Stop(void)
{   
	HI_MPI_ISP_Exit();
	pthread_join(isp_pid, 0);

    return 0;
}

HI_S32 SAMPLE_HIFB_VI_Prepare(void)
{
    HI_S32 s32Ret = HI_SUCCESS;
    
	/* 1. sensor init                                                          */
	sensor_init();

	/* 2. sensor register callback                                             */
	s32Ret = sensor_register_callback();
	if (s32Ret != HI_SUCCESS)
	{
	    printf("Sensor register Callback failed with %#x!\n", s32Ret);
	    return s32Ret;
	}

	/* 3. configure VI device                                                  */
	SAMPLE_HIFB_VI_Start_Dev();

	/* 4. create isp thread                                                    */
	if (0 != pthread_create(&isp_pid, 0, (void*)SAMPLE_HIFB_ISP_Run, HI_NULL))
	{
	    printf("create isp running thread failed!\n");
	    return HI_FAILURE;
	}    

	return HI_SUCCESS;
}

#define SAMPLE_IMAGE_WIDTH     184
#define SAMPLE_IMAGE_HEIGHT    144
#define SAMPLE_IMAGE_SIZE      (184*144*2)
#define SAMPLE_IMAGE_NUM       14
#define SAMPLE_IMAGE_PATH		"./res/%d.bmp"

#define SAMPLE_VIR_SCREEN_WIDTH	    SAMPLE_IMAGE_WIDTH			/*virtual screen width*/
#define SAMPLE_VIR_SCREEN_HEIGHT	SAMPLE_IMAGE_HEIGHT*2		/*virtual screen height*/

static struct fb_bitfield g_r16 = {10, 5, 0};
static struct fb_bitfield g_g16 = {5, 5, 0};
static struct fb_bitfield g_b16 = {0, 5, 0};
static struct fb_bitfield g_a16 = {15, 1, 0};

typedef struct hiPTHREAD_HIFB_SAMPLE
{
    int fd;
    int layer;
    int ctrlkey;
}PTHREAD_HIFB_SAMPLE_INFO;

HI_S32 SAMPLE_HIFB_LoadBmp(const char *filename, HI_U8 *pAddr)
{
    OSD_SURFACE_S Surface;
    OSD_BITMAPFILEHEADER bmpFileHeader;
    OSD_BITMAPINFO bmpInfo;

    if(GetBmpInfo(filename,&bmpFileHeader,&bmpInfo) < 0)
    {
		printf("GetBmpInfo err!\n");
        return HI_FAILURE;
    }
    
    Surface.enColorFmt = OSD_COLOR_FMT_RGB1555;

    CreateSurfaceByBitMap(filename,&Surface,pAddr);
    
    return HI_SUCCESS;
}


HI_VOID *SAMPLE_HIFB_PTHREAD_RunHiFB(void *pData)
{
    HI_S32 i;
    struct fb_fix_screeninfo fix;
    struct fb_var_screeninfo var;
    HI_U32 u32FixScreenStride = 0;
    unsigned char *pShowScreen;
    unsigned char *pHideScreen;
    HIFB_ALPHA_S stAlpha;
    HIFB_POINT_S stPoint = {40, 112};
    char file[12] = "/dev/fb0";

    char image_name[128];
	HI_U8 *pDst = NULL;

    HI_BOOL bShow;
    PTHREAD_HIFB_SAMPLE_INFO *pstInfo;

    if(HI_NULL == pData)
    {
        return HI_NULL;
    }

    pstInfo = (PTHREAD_HIFB_SAMPLE_INFO *)pData;

    switch (pstInfo->layer)
    {
        case 0 :
            strcpy(file, "/dev/fb0");
            break;
        case 1 :
            strcpy(file, "/dev/fb1");
            break;
        case 2 :
            strcpy(file, "/dev/fb2");
            break;
        case 3 :
            strcpy(file, "/dev/fb3");
            break;
        case 4 :
            strcpy(file, "/dev/fb4");
            break;
        case 5 :
            strcpy(file, "/dev/fb5");
            break;
        case 6 :
            strcpy(file, "/dev/fb6");
            break;
        case 7 :
            strcpy(file, "/dev/fb7");
            break;
        default:
            strcpy(file, "/dev/fb0");
            break;
    }

    /* 1. open framebuffer device overlay 0 */
    pstInfo->fd = open(file, O_RDWR, 0);
    if(pstInfo->fd < 0)
    {
        printf("open %s failed!\n",file);
        return HI_NULL;
    } 

    /* 2. set the screen original position */
    switch(pstInfo->ctrlkey)
    {
        case 0:
        {
            stPoint.u32PosX = 100;
            stPoint.u32PosY = 100;
        }
        break;
        
        case 1:
        {
            stPoint.u32PosX = 150;
            stPoint.u32PosY = 350;
        }
        break;
        
        case 2:
        {
            stPoint.u32PosX = 384;
            stPoint.u32PosY = 100;
        }
        break;
        
        default:
        {
        }
    }
    
    if (ioctl(pstInfo->fd, FBIOPUT_SCREEN_ORIGIN_HIFB, &stPoint) < 0)
    {
        printf("set screen original show position failed!\n");
        return HI_NULL;
    }

    /* 3.set alpha */
    stAlpha.bAlphaEnable = HI_FALSE;
    stAlpha.bAlphaChannel = HI_FALSE;
    stAlpha.u8Alpha0 = 0xff;
    stAlpha.u8Alpha1 = 0x8f;
    stAlpha.u8GlobalAlpha = 0x80;
    if (ioctl(pstInfo->fd, FBIOPUT_ALPHA_HIFB,  &stAlpha) < 0)
    {
        printf("Set alpha failed!\n");
        return HI_NULL;
    }

    /* 4. get the variable screen info */
    if (ioctl(pstInfo->fd, FBIOGET_VSCREENINFO, &var) < 0)
    {
        printf("Get variable screen info failed!\n");
        return HI_NULL;
    }

    /* 5. modify the variable screen info
          the screen size: IMAGE_WIDTH*IMAGE_HEIGHT
          the virtual screen size: VIR_SCREEN_WIDTH*VIR_SCREEN_HEIGHT
          (which equals to VIR_SCREEN_WIDTH*(IMAGE_HEIGHT*2))
          the pixel format: ARGB1555
    */
    usleep(4*1000*1000);
    switch(pstInfo->ctrlkey)
    {
        case 0:
        {
            var.xres_virtual = 104;
            var.yres_virtual = 200;
            var.xres = 104;
            var.yres = 100;
        }
        break;
        
        case 1:
        {
            var.xres_virtual = 100;
            var.yres_virtual = 100;
            var.xres = 100;
            var.yres = 100;
        }
        break;
        
        case 2:
        {
            var.xres_virtual = SAMPLE_VIR_SCREEN_WIDTH;
            var.yres_virtual = SAMPLE_VIR_SCREEN_HEIGHT;
            var.xres = SAMPLE_IMAGE_WIDTH;
            var.yres = SAMPLE_IMAGE_HEIGHT;
        }
        break;
        
        default:
        {
            var.xres_virtual = 98;
            var.yres_virtual = 128;
            var.xres = 98;
            var.yres = 64;
        }
    }

    var.transp= g_a16;
    var.red = g_r16;
    var.green = g_g16;
    var.blue = g_b16;
    var.bits_per_pixel = 16;
    var.activate = FB_ACTIVATE_FORCE;
    
    /* 6. set the variable screeninfo */
    if (ioctl(pstInfo->fd, FBIOPUT_VSCREENINFO, &var) < 0)
    {
        printf("Put variable screen info failed!\n");
        return HI_NULL;
    }

    /* 7. get the fix screen info */
    if (ioctl(pstInfo->fd, FBIOGET_FSCREENINFO, &fix) < 0)
    {
        printf("Get fix screen info failed!\n");
        return HI_NULL;
    }
    u32FixScreenStride = fix.line_length;   /*fix screen stride*/

    /* 8. map the physical video memory for user use */
    pShowScreen = mmap(HI_NULL, fix.smem_len, PROT_READ|PROT_WRITE, MAP_SHARED, pstInfo->fd, 0);
    if(MAP_FAILED == pShowScreen)
    {
        printf("mmap framebuffer failed!\n");
        return HI_NULL;
    }
    
    memset(pShowScreen, pstInfo->layer*0x1F, fix.smem_len);

    /* 9.time to paly*/
    bShow = HI_TRUE;
    if (ioctl(pstInfo->fd, FBIOPUT_SHOW_HIFB, &bShow) < 0)
    {
        printf("FBIOPAN_DISPLAY failed!\n");
        munmap(pShowScreen, fix.smem_len);
        return HI_NULL;
    }
    
    switch(pstInfo->ctrlkey)
    {
        case 0:
        {
            /*change color*/
            pHideScreen = pShowScreen + u32FixScreenStride*var.yres;
            memset(pHideScreen, 0x7c00, u32FixScreenStride*var.yres);
            memset(pShowScreen, 0x0,  u32FixScreenStride*var.yres);
            
            for(i=0; i<SAMPLE_IMAGE_NUM; i++) //IMAGE_NUM
            {
                if(i%2)
                {
                    var.yoffset = 0;
                }
                else
                {
                    var.yoffset = var.yres;
                }

                if (ioctl(pstInfo->fd, FBIOPAN_DISPLAY, &var) < 0)
                {
                    printf("FBIOPAN_DISPLAY failed!\n");
                    munmap(pShowScreen, fix.smem_len);
                    return HI_NULL;
                }

                usleep(1000*1000);
            }
        }
        break;
        
        case 1:
        {
            /*move*/
            HI_U32 u32PosXtemp;
            u32PosXtemp = stPoint.u32PosX;
            for(i=0;i<200;i++)
            {
                if(i > 100)
                {
                    stPoint.u32PosX = u32PosXtemp + i%20;
                    stPoint.u32PosY--;
                }
                else
                {
                    stPoint.u32PosX = u32PosXtemp - i%20;
                    stPoint.u32PosY++;
                }

                
                if(ioctl(pstInfo->fd, FBIOPUT_SCREEN_ORIGIN_HIFB, &stPoint) < 0)
                {
                    printf("set screen original show position failed!\n");
                    return HI_NULL;
                }

                usleep(70*1000);
            }
        }
        break;
        
        case 2:
        {
            /*change bmp*/
            pHideScreen = pShowScreen + u32FixScreenStride*SAMPLE_IMAGE_HEIGHT;
            memset(pShowScreen, 0, u32FixScreenStride*SAMPLE_IMAGE_HEIGHT*2);
            
            for(i = 0; i < SAMPLE_IMAGE_NUM; i++)
            {
                sprintf(image_name, SAMPLE_IMAGE_PATH, i%2);

                pDst = (HI_U8 *)pHideScreen;

                SAMPLE_HIFB_LoadBmp(image_name,pDst);

                if(i%2)
                {
                    var.yoffset = 0;
                    pHideScreen = pShowScreen + u32FixScreenStride*SAMPLE_IMAGE_HEIGHT;
                }
                else
                {
                    var.yoffset = SAMPLE_IMAGE_HEIGHT;
                    pHideScreen = pShowScreen;
                }

                if (ioctl(pstInfo->fd, FBIOPAN_DISPLAY, &var) < 0)
                {
                    printf("FBIOPAN_DISPLAY failed!\n");
                    munmap(pShowScreen, fix.smem_len);
                    return HI_NULL;
                }
        		usleep(1000*1000);
            }
        }
        break;

        default:
        {
        }
    }
    

    /* 10.unmap the physical memory */
    munmap(pShowScreen, fix.smem_len);

    bShow = HI_FALSE;
    if (ioctl(pstInfo->fd, FBIOPUT_SHOW_HIFB, &bShow) < 0)
    {
        printf("FBIOPAN_DISPLAY failed!\n");
        return HI_NULL;
    }
    
    return HI_NULL;

}


int main(int argc, char *argv[])
{
    pthread_t phifb0;
    pthread_t phifb1;
    pthread_t phifb2;
    PTHREAD_HIFB_SAMPLE_INFO stInfo0;
    PTHREAD_HIFB_SAMPLE_INFO stInfo1;
    PTHREAD_HIFB_SAMPLE_INFO stInfo2;
    
    /*mpi init */
    SAMPLE_HIFB_MPI_Init();
        
    /* configure sensor, ISP and VI device                                     */
    SAMPLE_HIFB_VI_Prepare();

    /* start VI channel to capture                                             */
    SAMPLE_HIFB_VI_Start();

    /* start VO to preview                                                     */
    SAMPLE_HIFB_VO_Start();

    /* vi bind vo                                                              */
    SAMPLE_HIFB_VIVO_Bind();

    /*start hifb                                                               */
    stInfo0.layer   =  0;
    stInfo0.fd      = -1;
    stInfo0.ctrlkey =  0;

    pthread_create(&phifb0,0,SAMPLE_HIFB_PTHREAD_RunHiFB,(void *)(&stInfo0));

    stInfo1.layer   =  1;
    stInfo1.fd      = -1;
    stInfo1.ctrlkey =  1;

    pthread_create(&phifb1,0,SAMPLE_HIFB_PTHREAD_RunHiFB,(void *)(&stInfo1));

    stInfo2.layer   =  2;
    stInfo2.fd      = -1;
    stInfo2.ctrlkey =  2;

    pthread_create(&phifb2,0,SAMPLE_HIFB_PTHREAD_RunHiFB,(void *)(&stInfo2));

    printf("press any key to exit!!\n");
    getchar();

    pthread_join(phifb0,0);
    pthread_join(phifb1,0);
    pthread_join(phifb2,0);

    /*close hifb                                                               */
    printf("%d,%d,%d\n",stInfo0.fd,stInfo1.fd,stInfo2.fd);
    close(stInfo0.fd);
    close(stInfo1.fd);
    close(stInfo2.fd);

    /* stop application                                                        */
    SAMPLE_HIFB_ISP_Stop();
    SAMPLE_HIFB_VIVO_UnBind();
    SAMPLE_HIFB_VO_Stop();
    SAMPLE_HIFB_VI_Stop();

    /*mpi exit */
	HI_MPI_SYS_Exit();
	HI_MPI_VB_Exit();

    return 0;
}





