#ifndef _ASMARM_SCATTERLIST_H
#define _ASMARM_SCATTERLIST_H

#include <asm/memory.h>
#include <asm/types.h>
#include <asm-generic/scatterlist.h>

#endif /* _ASMARM_SCATTERLIST_H */
