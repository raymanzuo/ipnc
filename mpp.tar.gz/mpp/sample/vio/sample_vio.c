/******************************************************************************
  A simple program of Hisilicon HI3516 video input and output implementation.
  the normal flow as follows:
    1) init global parameters according user's choose
    2) init mpp system.
    3) start vi
       3.1) init sensor
       3.2) enable vi dev
       3.3) create isp thread (init isp & isp run)
       3.4) start vi chn
    4) start vo
    5) bind vo chn and vi chn. we first display vi-ch0
    6) user press any key to switch display vi-chn
      ( re-bind vi-chn and vo-chn ) 
    7) stop
  Copyright (C), 2010-2011, Hisilicon Tech. Co., Ltd.
 ******************************************************************************
    Modification:  2011-2 Created
******************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* End of #ifdef __cplusplus */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include "sample_comm.h"
//#include "fpga.h"
//#include "ccd_sensor.h"
//#include <linux/pci.h>



#define SAMPLE_VPP_PAUSE {printf("press 'q' to exit sample! peress ENTER to switch vpp mode!\n");if('q' == getchar()) return HI_SUCCESS;}

static HI_S32 gs_s32ViDevFlg[2];        /* vi dev(0,1) enable flag */
static HI_S32 gs_s32ViChnCnt;           /* Vi Chn Count (1-5)*/
static SAMPLE_VI_DEV_TYPE_E  gs_enViDevType[2];    /* vicap input mode */
static VI_DEV gs_ViChnBndDev[5];      /* vi chn bind vi dev id */
static PIC_SIZE_E gs_enViChnSize[5];  /* Vi Chn stDestSize */

static HI_S32 gs_s32VoDevFlg[2];        /* vo-dev enable flag: 0- HD, 1-SD */

static VB_CONF_S gs_stVbConf ={0};

static VI_DEV gs_ViDevBndCurr;/* which vi-dev is binded to vo-chn, currently.*/
static VI_CHN gs_ViChnBndCurr;/* which vi-chn is binded to vo-chn, currently.*/

/* vo dev 0-hd 2-sd  1-invaild */
#define SAMPLE_VIO_GET_VO_DEV(x)    ((0==x)?0:2)
/******************************************************************************
* function : colse vi dev. according global var to open the right vi dev & chn 
******************************************************************************/
void SAMPLE_VIO_DisViDevAll()
{
    VI_DEV ViDev;
    HI_S32 i;
    HI_S32 s32Ret = HI_FAILURE;

    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32ViDevFlg[i])
        {
            ViDev = i;

            s32Ret = SAMPLE_COMM_VI_StopDev(ViDev);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s, SAMPLE_COMM_VI_StopDev [%d] failed with %#x!\n",\
                        __FUNCTION__, i, s32Ret);
                return;
            }
        }
    }
    return;
}
/******************************************************************************
* function : start vi. according global var to open the right vi dev & chn 
******************************************************************************/
HI_S32 SAMPLE_VIO_StartViAll(void)
{
    HI_S32 i, s32Ret;
    VI_DEV ViDev;
    VI_CHN ViChn;
    SAMPLE_VI_CHN_SET_E enViChnSet = VI_CHN_SET_NORMAL;

    /******************************************
     step 1: configure sensor.
     note: you can jump over this step, if you do not use Hi3516 interal isp. 
    ******************************************/
    s32Ret = SAMPLE_COMM_ISP_SensorInit();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Sensor init failed!\n", __FUNCTION__);
        return HI_FAILURE;
    }

    /******************************************************
     step 2 : config & start vicap dev - port A & B
    ******************************************************/
    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32ViDevFlg[i])
        {
            ViDev = i;
            s32Ret = SAMPLE_COMM_VI_StartDev(ViDev, gs_enViDevType[i]);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: start vi dev[%d] failed!\n", __FUNCTION__, i);
                return HI_FAILURE;
            }
        }
    }

    /******************************************
     step 3: configure & run isp thread 
     note: you can jump over this step, if you do not use Hi3516 interal isp. 
     note: isp run must at this step -- after vi dev enable, before vi chn enable 
    ******************************************/
    s32Ret = SAMPLE_COMM_ISP_IspRun();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: ISP init failed!\n", __FUNCTION__);
	/* disable videv */
        SAMPLE_VIO_DisViDevAll();
        return HI_FAILURE;
    }
    /******************************************************
    * Step 2: config & start vicap chn (max 5) 
    ******************************************************/
    for (i=0; i<5; i++)
    {
        /*************************************************
         we want to show scale, flip, mirror. so we set:
         vi-chn0: normal
         vi-chn1: mirror enable
         vi-chn2: filp enable
        *************************************************/
        if (SAMPLE_NOUSE != gs_ViChnBndDev[i])
        {       
              ViChn = i;

		s32Ret = SAMPLE_COMM_VI_StartBaseChn(gs_ViChnBndDev[i], ViChn,\
		                 gs_enViDevType[gs_ViChnBndDev[i]], gs_enViChnSize[i], enViChnSet);

		if (HI_SUCCESS != s32Ret)
		{
		    printf("%s: start vi chn[%d,%d] failed!\n", __FUNCTION__,\
		           gs_ViChnBndDev[i], ViChn);
		    SAMPLE_VIO_DisViDevAll();
		    SAMPLE_COMM_ISP_IspStop();
		    return HI_FAILURE;
		}
        }	
    }

    return HI_SUCCESS; 
}

/******************************************************************************
* function : start vo. according global var to open the right vo dev 
******************************************************************************/
HI_S32 SAMPLE_VIO_StartVoAll(void)
{
    VO_DEV VoDev;
    HI_S32 i;

    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32VoDevFlg[i])
        {
            VoDev = SAMPLE_VIO_GET_VO_DEV(i);
            if (SAMPLE_COMM_VO_Start(VoDev))
            {
                printf("%s: start vo failed!(dev=[%d])\n", \
                       __FUNCTION__, VoDev);
                return HI_FAILURE;
            }
        }
    }

    return HI_SUCCESS; 
}

/******************************************************************************
* function : bind vi vo. according global var to bind vi to the right vo chn 
******************************************************************************/
HI_S32 SAMPLE_VIO_BindViVoAll(VI_DEV ViDev, VI_CHN ViChn)
{
    HI_S32 i;
    VO_DEV VoDev;
    VO_CHN VoChn;
    HI_S32 s32Ret;

    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32VoDevFlg[i])
        {
            VoDev = SAMPLE_VIO_GET_VO_DEV(i);
            VoChn = 0;
            s32Ret = SAMPLE_COMM_VI_BindViVo(ViDev, ViChn, VoDev, VoChn);
	    printf("%s: vichn(%d,%d) vochn(%d,%d) binded \n",
                    __FUNCTION__, ViDev, ViChn, VoDev, VoChn);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: vichn(%d,%d) vochn(%d,%d) bind faild with %#x!\n",
                    __FUNCTION__, ViDev, ViChn, VoDev, VoChn, s32Ret);
                return HI_FAILURE;
            }
        }
    }
    return HI_SUCCESS; 
}

/******************************************************************************
* function : unbind vi vo. according global var unto bind vi 
*         to the right vo chn 
******************************************************************************/
HI_S32 SAMPLE_VIO_UnBindViVoAll(VI_DEV ViDev, VI_CHN ViChn)
{
    HI_S32 i;
    VO_DEV VoDev;
    VO_CHN VoChn;
    HI_S32 s32Ret;

    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32VoDevFlg[i])
        {
            VoDev = SAMPLE_VIO_GET_VO_DEV(i);
            VoChn = 0;
            s32Ret = SAMPLE_COMM_VI_UnBindViVo(gs_ViDevBndCurr,\
			 gs_ViChnBndCurr, VoDev, VoChn);
            if (HI_SUCCESS != s32Ret)
            {
                printf("%s: vichn(%d,%d) vochn(%d,%d) unbind failed with %#x!\n", __FUNCTION__, s32Ret, ViDev, ViChn, VoDev, VoChn);
                return s32Ret;
            }
        }
    }
    return HI_SUCCESS; 
}

/******************************************************************************
* function : Stop all used vo
******************************************************************************/
void SAMPLE_VIO_StopVoAll()
{
    HI_S32 i;
    VO_DEV VoDev;

    for (i=0; i<2; i++)
    {
        if (SAMPLE_ENABLE == gs_s32VoDevFlg[i])
        {
            VoDev = SAMPLE_VIO_GET_VO_DEV(i);
            SAMPLE_COMM_VO_Stop(VoDev);
        }
    }
    return;
}

/******************************************************************************
* function : Stop all used vi
******************************************************************************/
void SAMPLE_VIO_StopViAll()
{
    HI_S32 i;
    VI_CHN ViChn;

    /******************************************
     step 1: stop vi chn
    ******************************************/
    for (i=0; i<gs_s32ViChnCnt; i++)
    {
        ViChn = i;
        SAMPLE_COMM_VI_StopChn(ViChn);
    }

    /******************************************
     step 2: stop ISP thread
    ******************************************/
    SAMPLE_COMM_ISP_IspStop();

    /******************************************
     step 3: stop vi dev
    ******************************************/
    SAMPLE_VIO_DisViDevAll();

    return;
}
/******************************************************************************
* function : show usage
******************************************************************************/
void SAMPLE_VIO_Usage(HI_CHAR *sPrgNm)
{
    printf("Usage : %s <index>\n", sPrgNm);
    printf("index:\n");
    printf("\t 0) embeded isp one channel preview\n");
    printf("\t    DC(1080p) -> VI-PortA Vi-CHN0 -> VO HD\n");
    printf("\t 1) external isp one channel preview\n");
    printf("\t    BT1120(720p) -> VI-PortB VI-CHN0 -> VO HD\n");
    printf("\t 2) standard definition one channel preview\n");
    printf("\t    BT656(D1) -> VI-PortB VI-CHN0 -> VO CVBS (FPGA version not support)\n");
    printf("\t 3) VI mutli-channel preview\n");
    printf("\t    DC(1080p) -> VI-PortA Multi-VI-CHN -> VO HD\n");
    printf("\t 4) embeded isp one channel + vpp preview\n");
    printf("\t    DC(1080p) -> VI-PortA VI-CHN0 -> VO HD\n");
    printf("\t 5) embeded isp one channel preview\n");
    printf("\t    DC(1080p) -> VI-PortA VI-CHN0 -> VO CVBS and VO HD\n");
    return;
}

/******************************************************************************
* function : check and init global var. 
******************************************************************************/
HI_S32 SAMPLE_VIO_InitPara(HI_S32 argc, HI_CHAR **argv)
{
    HI_S32 s32Ret;

    switch (*argv[1])
    {
        case '0':
        /****************************************************************
         0) embeded isp one channel preview
         DC(1080p) -> VI-PortA Vi-CHN0 -> VO HD
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_ENABLE;
            gs_s32ViDevFlg[1] = SAMPLE_DISABLE;
            /* vicap input type */
            gs_enViDevType[0] = OV_2715_DC_1080P; /* SENSOR_TYPE defined in Makefile.para */
            gs_enViDevType[1] = SAMPLE_NOUSE;
            /* vi chn total count */
            gs_s32ViChnCnt = 1;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = 0;
            gs_ViChnBndDev[1] = SAMPLE_NOUSE;
            gs_ViChnBndDev[2] = SAMPLE_NOUSE;
            gs_ViChnBndDev[3] = SAMPLE_NOUSE;
            gs_ViChnBndDev[4] = SAMPLE_NOUSE;
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = PIC_HD1080;
            if (APTINA_9M034_DC_720P_CONTINUES == SENSOR_TYPE)
            {
                gs_enViChnSize[0] = PIC_HD720;
            }
            if (APTINA_AR0331_DC_3M_20FPS == SENSOR_TYPE)
            {
                gs_enViChnSize[0] = PIC_QXGA;
            }
            gs_enViChnSize[1] = SAMPLE_NOUSE;
            gs_enViChnSize[2] = SAMPLE_NOUSE;
            gs_enViChnSize[3] = SAMPLE_NOUSE;
            gs_enViChnSize[4] = SAMPLE_NOUSE;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, gs_enViChnSize[0], &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;
        case '1':
        /****************************************************************
         1) external isp one channel preview
         BT1120(720p) -> VI-PortB VI-CHN0 -> VO HD
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_DISABLE;
            gs_s32ViDevFlg[1] = SAMPLE_ENABLE;
            /* vicap input type */
            gs_enViDevType[0] = SAMPLE_NOUSE;
            gs_enViDevType[1] = BT1120_720P;
            /* vi chn total count */
            gs_s32ViChnCnt = 1;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = 1;
            gs_ViChnBndDev[1] = SAMPLE_NOUSE;
            gs_ViChnBndDev[2] = SAMPLE_NOUSE;
            gs_ViChnBndDev[3] = SAMPLE_NOUSE;
            gs_ViChnBndDev[4] = SAMPLE_NOUSE;
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = PIC_HD720;
            gs_enViChnSize[1] = SAMPLE_NOUSE;
            gs_enViChnSize[2] = SAMPLE_NOUSE;
            gs_enViChnSize[3] = SAMPLE_NOUSE;
            gs_enViChnSize[4] = SAMPLE_NOUSE;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD720, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;
        case '2':
        /****************************************************************
         2) standard definition one channel preview
         BT656(D1) -> VI-PortB VI-CHN0 -> VO CVBS (FPGA version not support)
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_ENABLE; //SAMPLE_DISABLE;
            gs_s32ViDevFlg[1] = SAMPLE_DISABLE; // ENABLE;
            /* vicap input type */
            gs_enViDevType[0] = OV_2715_DC_1080P; //SAMPLE_NOUSE;
            gs_enViDevType[1] = SAMPLE_NOUSE; //BT656_D1P;
            /* vi chn total count */
            gs_s32ViChnCnt = 1;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = 0;
            gs_ViChnBndDev[1] = SAMPLE_NOUSE;
            gs_ViChnBndDev[2] = SAMPLE_NOUSE;
            gs_ViChnBndDev[3] = SAMPLE_NOUSE;
            gs_ViChnBndDev[4] = SAMPLE_NOUSE;
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = PIC_D1;
            gs_enViChnSize[1] = SAMPLE_NOUSE;
            gs_enViChnSize[2] = SAMPLE_NOUSE;
            gs_enViChnSize[3] = SAMPLE_NOUSE;
            gs_enViChnSize[4] = SAMPLE_NOUSE;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_D1, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;
        case '3':
        /****************************************************************
         3) VI mutli-channel preview
         DC(1080p) -> VI-PortA Multi-VI-CHN -> VO HD
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_ENABLE;
            gs_s32ViDevFlg[1] = SAMPLE_DISABLE;
            /* vicap input type */
            gs_enViDevType[0] = OV_2715_DC_1080P; //SENSOR_TYPE; /* SENSOR_TYPE defined in Makefile.para */
            gs_enViDevType[1] = SAMPLE_NOUSE;
            /* vi chn total count */
            gs_s32ViChnCnt = 5;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = 0;
            gs_ViChnBndDev[1] = 0;
            gs_ViChnBndDev[2] = 0;
            gs_ViChnBndDev[3] = 0;
            gs_ViChnBndDev[4] = 0;
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = PIC_HD1080;
            gs_enViChnSize[1] = PIC_HD720;
            gs_enViChnSize[2] = PIC_D1;
            gs_enViChnSize[3] = PIC_CIF;
            gs_enViChnSize[4] = PIC_QCIF;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE; //DISABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            s32Ret = SAMPLE_COMM_SYS_DefVb(2, 3, PIC_HD720, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            s32Ret = SAMPLE_COMM_SYS_DefVb(4, 5, PIC_D1, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }

			/* If enPicSize is PIC_QCIF, VB pool uses PIC_CIF's,
			   because VB max common pool number is limited by VB_MAX_COMM_POOLS.
			 */
           s32Ret = SAMPLE_COMM_SYS_DefVb(6, 7, PIC_CIF, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }

            break;
        case '4':
        /****************************************************************
         4) embeded isp one channel + vpp preview
         DC(1080p) -> VI-PortA Vi-CHN0 -> VO HD
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_ENABLE;
            gs_s32ViDevFlg[1] = SAMPLE_DISABLE;
            /* vicap input type */
            gs_enViDevType[0] = OV_2715_DC_1080P; /* SENSOR_TYPE defined in Makefile.para */
            gs_enViDevType[1] = SAMPLE_NOUSE;
            /* vi chn total count */
            gs_s32ViChnCnt = 1;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = 0;
            gs_ViChnBndDev[1] = SAMPLE_NOUSE;
            gs_ViChnBndDev[2] = SAMPLE_NOUSE;
            gs_ViChnBndDev[3] = SAMPLE_NOUSE;
            gs_ViChnBndDev[4] = SAMPLE_NOUSE;
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = PIC_HD1080;
            gs_enViChnSize[1] = SAMPLE_NOUSE;
            gs_enViChnSize[2] = SAMPLE_NOUSE;
            gs_enViChnSize[3] = SAMPLE_NOUSE;
            gs_enViChnSize[4] = SAMPLE_NOUSE;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_HD1080, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
            break;
            
        case '5':
        /****************************************************************
         5) embeded isp one channel preview
         DC(1080p) -> VI-PortA Vi-CHN1 -> VO CVBS
        ****************************************************************/
            gs_s32ViDevFlg[0] = SAMPLE_ENABLE;
            gs_s32ViDevFlg[1] = SAMPLE_DISABLE;
            /* vicap input type */
            gs_enViDevType[0] = OV_2715_DC_1080P; //SENSOR_TYPE; /* SENSOR_TYPE defined in Makefile.para */
            gs_enViDevType[1] = SAMPLE_NOUSE;
            /* vi chn total count */
            gs_s32ViChnCnt = 1;
            /* vi chn bind vi dev */
            gs_ViChnBndDev[0] = SAMPLE_NOUSE;
            gs_ViChnBndDev[1] = 0;
            gs_ViChnBndDev[2] = SAMPLE_NOUSE;
            gs_ViChnBndDev[3] = SAMPLE_NOUSE;
            gs_ViChnBndDev[4] = SAMPLE_NOUSE;
            
            /* Vi Chn stDestSize */
            gs_enViChnSize[0] = SAMPLE_NOUSE;
            gs_enViChnSize[1] = PIC_D1;
            gs_enViChnSize[2] = SAMPLE_NOUSE;
            gs_enViChnSize[3] = SAMPLE_NOUSE;
            gs_enViChnSize[4] = SAMPLE_NOUSE;
            /* vo dev */
            gs_s32VoDevFlg[0] = SAMPLE_ENABLE; //ENABLE;
            gs_s32VoDevFlg[1] = SAMPLE_ENABLE;
            /* vb define */
            s32Ret = SAMPLE_COMM_SYS_DefVb(0, 1, PIC_D1, &gs_stVbConf);
            if (HI_FAILURE == s32Ret)
            {
                return HI_FAILURE;
            }
          
            break;
                        
        default:
            printf("the index is invaild!\n");
            SAMPLE_VIO_Usage(argv[0]);
            return HI_FAILURE;
    }

    return HI_SUCCESS;
}

/******************************************************************************
* function : to process abnormal case                                        
******************************************************************************/
HI_S32 SAMPLE_VIO_VppProcess(VI_DEV ViDev, VI_CHN ViChn)
{
    VI_VPP_CFG_S  stVppCfg;
    VI_CSC_ATTR_S stCscAttr;
    HI_S32 s32Ret;

    SAMPLE_VPP_PAUSE;
    /*****************************************
     step1: adjust csc
    *****************************************/
    printf("adjust csc\n");
    
    s32Ret = HI_MPI_VI_GetCscAttr(ViDev, 0, &stCscAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_GetCscAttr failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    stCscAttr.enViCscType = VI_CSC_TYPE_601;
    stCscAttr.u32ContrVal = 80;
    stCscAttr.u32HueVal = 80;
    stCscAttr.u32LumaVal = 80;
    stCscAttr.u32SatuVal = 80;
    
    s32Ret = HI_MPI_VI_SetCscAttr(ViDev, 0, &stCscAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetCscAttr failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /*****************************************
     step2: adjust csc to normal
    *****************************************/
    printf("please enter any key to resume csc normal value\n");
    SAMPLE_VPP_PAUSE;
    printf("resume csc normal value\n");

    s32Ret = HI_MPI_VI_GetCscAttr(ViDev, 0, &stCscAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_GetCscAttr failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }
    
    stCscAttr.enViCscType = VI_CSC_TYPE_601;
    stCscAttr.u32ContrVal = 50;
    stCscAttr.u32HueVal = 50;
    stCscAttr.u32LumaVal = 50;
    stCscAttr.u32SatuVal = 50;
    
    s32Ret = HI_MPI_VI_SetCscAttr(ViDev, 0, &stCscAttr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetCscAttr failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /*****************************************
     step3: adjust vpp
    *****************************************/
    /* step 3.1 enable Dn */
    printf("please enter any key to vpp DnEn\n");
    SAMPLE_VPP_PAUSE;
    printf("vpp DnEn = TRUE; SpEn = FALSE\n");

    s32Ret = HI_MPI_VI_GetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_GetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    stVppCfg.VppJobMaxW = 1920;
    stVppCfg.VppJobMaxH = 1080;
    stVppCfg.stVppCfg.bVppEn = HI_TRUE;  /* vpp global enable */
    stVppCfg.stVppCfg.bDnEn = HI_TRUE;   /* De-Noise enable */
    stVppCfg.stVppCfg.bSpEn = HI_FALSE;   /* shapen enable */
    stVppCfg.stVppCfg.bIencEn = HI_FALSE; /* not support now */

    stVppCfg.stVppCfg.s32DnSfCosSth = 2;
    stVppCfg.stVppCfg.s32DnSfIncSth = 200;
    stVppCfg.stVppCfg.s32DnTfSth = 2;
    stVppCfg.stVppCfg.s32SpSth = -3;

    s32Ret = HI_MPI_VI_SetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* step 3.2 enable sp */
    printf("please enter any key to vpp SpEn\n");
    SAMPLE_VPP_PAUSE;
    printf("vpp SpSth = 0\n");

    stVppCfg.stVppCfg.bVppEn = HI_TRUE;  /* vpp global enable */
    stVppCfg.stVppCfg.bDnEn = HI_TRUE;   /* De-Noise enable */
    stVppCfg.stVppCfg.bSpEn = HI_TRUE;   /* shapen enable */
    stVppCfg.stVppCfg.bIencEn = HI_FALSE; /* not support now */

    stVppCfg.stVppCfg.s32DnSfCosSth = 0;
    stVppCfg.stVppCfg.s32DnSfIncSth = 16;
    stVppCfg.stVppCfg.s32DnTfSth = 0;
    stVppCfg.stVppCfg.s32SpSth = 0;
    s32Ret = HI_MPI_VI_SetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* step 3.3 enhance Sp */
    printf("please enter any key to vpp SpEn\n");
    SAMPLE_VPP_PAUSE;
    printf("vpp SpSth = 5\n");

    stVppCfg.stVppCfg.bVppEn = HI_TRUE;  /* vpp global enable */
    stVppCfg.stVppCfg.bDnEn = HI_TRUE;   /* De-Noise enable */
    stVppCfg.stVppCfg.bSpEn = HI_TRUE;   /* shapen enable */
    stVppCfg.stVppCfg.bIencEn = HI_FALSE; /* not support now */

    stVppCfg.stVppCfg.s32DnSfCosSth = 0;
    stVppCfg.stVppCfg.s32DnSfIncSth = 16;
    stVppCfg.stVppCfg.s32DnTfSth = 0;
    stVppCfg.stVppCfg.s32SpSth = 5;
    s32Ret = HI_MPI_VI_SetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /* step 3.4 enhance Dn. */
    printf("please enter any key to vpp IeEn & Dn\n");
    SAMPLE_VPP_PAUSE;
    printf("vpp DnSfCosSth = 2; DnSfIncSth = 200; DnTfSth = 2\n");

    s32Ret = HI_MPI_VI_GetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_GetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    stVppCfg.stVppCfg.bVppEn = HI_TRUE;  /* vpp global enable */
    stVppCfg.stVppCfg.bDnEn = HI_TRUE;   /* De-Noise enable */
    stVppCfg.stVppCfg.bSpEn = HI_TRUE;   /* shapen enable */
    stVppCfg.stVppCfg.bIencEn = HI_FALSE; /* not support now */
    
    stVppCfg.stVppCfg.s32DnSfCosSth = 2;
    stVppCfg.stVppCfg.s32DnSfIncSth = 200;
    stVppCfg.stVppCfg.s32DnTfSth = 2;
    stVppCfg.stVppCfg.s32SpSth = 5;
    s32Ret = HI_MPI_VI_SetVppCfg(ViChn, &stVppCfg);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: HI_MPI_VI_SetVppCfg failed with %#x!\n",\
                __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    printf("please enter any key to vpp show over.\n");
    SAMPLE_VPP_PAUSE;
    printf("vpp show over.\n");
    
    return HI_SUCCESS;
}
/******************************************************************************
* function : to process abnormal case                                        
******************************************************************************/
void SAMPLE_VIO_HandleSig(HI_S32 signo)
{
    if (SIGINT == signo || SIGTSTP == signo)
    {
        SAMPLE_VIO_UnBindViVoAll(gs_ViDevBndCurr, gs_ViChnBndCurr);
        SAMPLE_VIO_StopVoAll();
        SAMPLE_VIO_StopViAll();
        SAMPLE_COMM_SYS_Exit();
        printf("\033[0;31mprogram exit abnormally!\033[0;39m\n");
    }

    exit(0);
}

/******************************************************************************
* function    : main() 
* Description : multi video input and multi video output 
*        0) embeded isp one channel preview
*           DC(1080p) -> VI-PortA Vi-CHN0 -> VO HD(fpga-720p, chip-1080p)
*        1) external isp one channel preview
*           BT1120(720p) -> VI-PortB VI-CHN0 -> VO HD(fpga-720p, chip-1080p)
*        2) standard definition one channel preview
*           BT656(D1) -> VI-PortB VI-CHN0 -> VO CVBS (FPGA version not support)
*        3) VI mutli-channel preview
*           DC(1080p) -> VI-PortA Multi-VI-CHN -> VO HD(fpga-720p, chip-1080p)
*        4) embeded isp one channel + vpp preview
*           DC(1080p) -> VI-PortA VI-CHN0 -> VO HD
******************************************************************************/
HI_S32 main(HI_S32 argc, HI_CHAR *argv[])
{
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;
    HI_CHAR ch;
/*    void *bridge_config_addr_va;
   void *fpga_config_addr_va;

   bridge_config_addr_va = phys_to_virt(0x40100004);
   fpga_config_addr_va = phys_to_virt(0x40210004);
   writel(0x00100157,bridge_config_addr_va);
   writel(0x04000157,fpga_config_addr_va);
    fgpa_init();
   ccd_sensor_init();*/
    if ( (argc < 2) || (1 != strlen(argv[1])) || (atoi(argv[1]) < 0) || (atoi(argv[1]) > 5))
    {
        SAMPLE_VIO_Usage(argv[0]);
        return HI_FAILURE;
    }

    /******************************************
     step  1: init global  variable 
    ******************************************/
    s32Ret = SAMPLE_VIO_InitPara(argc, argv);
    if (HI_SUCCESS != s32Ret)
    {
        printf("func:%s,line:%d err(0x%x)!!!!\n",__FUNCTION__,__LINE__,s32Ret);
        return HI_FAILURE;
    }
    
    /******************************************
     step  2: process abnormal case 
    ******************************************/
    signal(SIGINT, SAMPLE_VIO_HandleSig);
    signal(SIGTERM, SAMPLE_VIO_HandleSig);

    /******************************************
     step 3: mpp system init. 
    ******************************************/
    s32Ret = SAMPLE_COMM_SYS_Init(&gs_stVbConf);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: system init failed with %d!\n", __FUNCTION__, s32Ret);
        return HI_FAILURE;
    }

    /******************************************
     step 4: start vi dev & chn to capture 
    ******************************************/
    s32Ret = SAMPLE_VIO_StartViAll();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: start vi failed!\n", __FUNCTION__);
        goto END3;
    }

    /******************************************
     step 5: start VO to preview 
    ******************************************/
    s32Ret = SAMPLE_VIO_StartVoAll();
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: Start VO failed!\n", __FUNCTION__);
        goto END2;
    }

    /******************************************
     step 6: vi bind vo (hd & sd). first bind vi chn0
    ******************************************/
    gs_ViDevBndCurr = ((1==gs_s32ViDevFlg[0])?0:1);

    for (i = 0; i < 5; i++)	
    {
        if (SAMPLE_NOUSE != gs_ViChnBndDev[i])
        {
            gs_ViChnBndCurr = i;  /* bind the first used channel */
            break;
        }	
    }
	
    s32Ret = SAMPLE_VIO_BindViVoAll(gs_ViDevBndCurr, gs_ViChnBndCurr);
    if (HI_SUCCESS != s32Ret)
    {
        printf("%s: vichn vochn bind failed!\n", __FUNCTION__);
        goto END1;
    }

    /******************************************
     step 7: vpp process ( only for the No.4 choise)
    ******************************************/
    if ('4' == *argv[1]) /* enable vpp */
    {
        s32Ret = SAMPLE_VIO_VppProcess(gs_ViDevBndCurr, gs_ViChnBndCurr);

        goto END0;
    }
    /******************************************
     step 7: vicap chn display switch. bind switch (No.0/1/2/3 choise)
    ******************************************/
    if (gs_s32ViChnCnt <= 1)
    {
        printf("press any key to exit sample!\n");
        getchar();
    }
    else /* if vi cnt > 1, vo can switch vi chn */
    {
        printf("press 'q' to exit sample!\nperess ENTER to switch vo\n");
        i = 0;
        while ((ch = getchar()) != 'q')
        {
            i ++;
            if ( i >= gs_s32ViChnCnt)
                i = 0; 
            printf("switch to vicap chn[%d].\n", i);
            s32Ret = SAMPLE_VIO_UnBindViVoAll(gs_ViDevBndCurr,\
                                              gs_ViChnBndCurr);
            if(HI_SUCCESS != s32Ret)
            {
                printf("%s, vo switch (unbind) failed!\n", __FUNCTION__);
                break;
            }
            gs_ViDevBndCurr = gs_ViChnBndDev[i];
            gs_ViChnBndCurr = i;
            s32Ret = SAMPLE_VIO_BindViVoAll(gs_ViDevBndCurr, gs_ViChnBndCurr);
            if(HI_SUCCESS != s32Ret)
            {
                printf("%s: vo switch (bind) failed!\n", __FUNCTION__);
                break;
            }
        }
    }

    /******************************************
     step 8: stop application
    ******************************************/
END0:
    SAMPLE_VIO_UnBindViVoAll(gs_ViDevBndCurr, gs_ViChnBndCurr);
END1:
    SAMPLE_VIO_StopVoAll();
END2:
    SAMPLE_VIO_StopViAll();
END3:	
    SAMPLE_COMM_SYS_Exit();
    
    if (HI_SUCCESS != s32Ret)
    {
	printf("program exit abnormally!\n");
    }
    else
    {
        printf("program exit normally!\n");
    }
    return s32Ret;
}

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* End of #ifdef __cplusplus */
