/* init fpga for memio access */
 #define BRIDGE_CONFIG_CTRL_ADDR 0x40100004;
 #define FPGA_CONFIG_CTRL_ADDR  0X40210004;
 #define FPGA_MEMIO_BASE	0x30100000;
 #define FPGA_SPI0_BASE		0x00010000;
 #define FPGA_SPI0_CSCTL	0X00010004;
 #define FPGA_SPI0_DATA		0X00010008;
 int FPGA_access_enable(void)
{
   void *bridge_config_addr_va;
   void *fpga_config_addr_va;
   bridge_config_addr_va = phys_to_virt(BRIDGE_CONFIG_CTRL_ADDR);
   fpga_config_addr_va = phys_to_virt(FPGA_CONFIG_CTRL_ADDR);
   writel(0x00100157,bridge_config_addr_va);
   writel(0x04000157,FPGA_config_addr_va);
    	
