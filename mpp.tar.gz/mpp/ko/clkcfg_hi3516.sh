clk_close()
{
    #himm 0x2005001c 0x200           # DDR High 16Bit PowerDown (periphctrl0) Boot and Hardware need modify.
    himm 0x20050084 0x400000        # USB Phy PowerDown        (periphctrl21)
    
    himm 0x20030034 0x1             # SIO0 reset and clock close (PERI_CRG13)
    himm 0x20030038 0x1             # SIO1 reset and clock close (PERI_CRG14)
    himm 0x2003003C 0x8001          # SIO2/codec reset and clock close (PERI_CRG15)   
    
    himm 0x20030040 0x7             # VIU reset and clock close(PERI_CRG16)
    himm 0x20030044 0x81            # VOU reset and clock close, DAC PowerDown (PERI_CRG17)        

    himm 0x20030048 0x0             # VEDU reset and clock close (PERI_CRG18)  
    himm 0x2003004C 0x0             # JPEG reset and clock close (PERI_CRG19)
    himm 0x20030050 0x1             # MDU reset and clock close (PERI_CRG20)
    himm 0x20030058 0x1             # IVE reset and clock close (PERI_CRG22)
    himm 0x2003005C 0x1             # TDE reset and clock close (PERI_CRG23)
    himm 0x2003006C 0x1             # DMAC reset and clock close (PERI_CRG27)       
    himm 0x20030070 0x1             # SPI0 reset and clock close (PERI_CRG28)
    himm 0x2003007C 0x1             # PCIE reset and clock close (PERI_CRG31)
    himm 0x20030080 0x11            # SDIO reset and clock close (PERI_CRG32)
    himm 0x20030088 0x1             # UART1 reset and clock close (PERI_CRG34)
    himm 0x2003008C 0x1             # UART2 reset and clock close (PERI_CRG35)
    himm 0x20030090 0x1             # UART3 reset and clock close (PERI_CRG36)
    himm 0x20030094 0x1             # I2C reset and clock close (PERI_CRG37)
    himm 0x20030098 0x15            # IR/RTC/Cipher reset and clock close (PERI_CRG38)
    himm 0x2003009C 0xE             # PCIE PHY PowerDown / SENSE CLKOUT 37.125M (PERI_CRG39)
}

clk_cfg()
{
    #himm 0x20030034 0x2             # SIO0 clk (PERI_CRG13)
    #himm 0x20030038 0x2             # SIO1 clk (PERI_CRG14)
    #himm 0x2003003C 0x2             # SIO2/codec clk (PERI_CRG15)   

    #himm 0x20030040 0x0001bfc8      # VIU clk (PERI_CRG16)
    himm 0x20030044 0x0000000ef     # VOU clk (PERI_CRG17)
    himm 0x20030048 0x3             # VEDU clk (PERI_CRG18)
    himm 0x2003004C 0x3             # JPEG clk (PERI_CRG19)
    himm 0x20030050 0x2             # MDU clk (PERI_CRG20)
    himm 0x20030058 0x2             # IVE clk (PERI_CRG22)	
    himm 0x2003005C 0x2             # TDE clk (PERI_CRG23)	
    
    himm 0x2003006C 0x2             # DMAC clk (PERI_CRG27)     
    himm 0x20030070 0x2             # SPI0 clk (PERI_CRG28)
    himm 0x20030094 0x2             # I2C clk (PERI_CRG37)
    himm 0x2003009C 0x2             # SENSE clk (PERI_CRG39)
    himm 0x20030068 0x22            # PWM unreset and clk enable
}

#clk_close	# clock have closed in uboot
clk_cfg
