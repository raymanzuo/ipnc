# pin set of vi1/gpio/vo0/sdio1	;muxctrl_reg4-muxctrl_reg22
pinmux_vi1_vo0=2
if [ $# -ge 1 ]; then
    pinmux_vi1_vo0=$1
fi
himm 0x200F0010	$pinmux_vi1_vo0
himm 0x200F0014	$pinmux_vi1_vo0
himm 0x200F0018	$pinmux_vi1_vo0
himm 0x200F001C	$pinmux_vi1_vo0
himm 0x200F0020	$pinmux_vi1_vo0
himm 0x200F0024	$pinmux_vi1_vo0
himm 0x200F0028	$pinmux_vi1_vo0
himm 0x200F002C	$pinmux_vi1_vo0
himm 0x200F0030	$pinmux_vi1_vo0
himm 0x200F0034	$pinmux_vi1_vo0
himm 0x200F0038	$pinmux_vi1_vo0
himm 0x200F003C	$pinmux_vi1_vo0
himm 0x200F0040	$pinmux_vi1_vo0
himm 0x200F0044	$pinmux_vi1_vo0
himm 0x200F0048	$pinmux_vi1_vo0
himm 0x200F004C	$pinmux_vi1_vo0
himm 0x200F0050	$pinmux_vi1_vo0
himm 0x200F0054	$pinmux_vi1_vo0
himm 0x200F0058	$pinmux_vi1_vo0
if [ $pinmux_vi1_vo0 -eq 2 ]; then
    himm 0x200F0088	2	#muxctrl_reg34
fi

# pin set of gpio/sio0/spi1	;muxctrl_reg23-muxctrl_reg29
pinmux_sio0=1
if [ $# -ge 2 ]; then
    pinmux_sio0=$2
fi
himm 0x200F005C	$pinmux_sio0
himm 0x200F0060	$pinmux_sio0
himm 0x200F0064	$pinmux_sio0
himm 0x200F0068	$pinmux_sio0
himm 0x200F006C	$pinmux_sio0
himm 0x200F0070	$pinmux_sio0
himm 0x200F0074	$pinmux_sio0

# pin set of gpio/vo1/sio1	;muxctrl_reg69-muxctrl_reg77
pinmux_vo1_sio1=1
if [ $# -ge 3 ]; then
    pinmux_vo1_sio1=$3
fi
#himm 0x200f0114 $pinmux_vo1_sio1
himm 0x200F0118	$pinmux_vo1_sio1
himm 0x200F011C	$pinmux_vo1_sio1
himm 0x200F0120	$pinmux_vo1_sio1
himm 0x200F0124	$pinmux_vo1_sio1
himm 0x200F0128	$pinmux_vo1_sio1
himm 0x200F012C	$pinmux_vo1_sio1
himm 0x200F0130	$pinmux_vo1_sio1
himm 0x200F0134	$pinmux_vo1_sio1

#----------------------------------------------------------------------
# pin set of gpio/i2c	;muxctrl_reg35-muxctrl_reg36
pinmux_i2c=0
if [ $# -ge 4 ]; then
    pinmux_i2c=$4
fi
himm 0x200F008C	$pinmux_i2c
himm 0x200F0090	$pinmux_i2c

# pin set of gpio/spi0	;muxctrl_reg30-muxctrl_reg33
pinmux_spi0=1
if [ $# -ge 5 ]; then
    pinmux_spi0=$5
fi
himm 0x200F0078	$pinmux_spi0
himm 0x200F007C	$pinmux_spi0
himm 0x200F0080	$pinmux_spi0
himm 0x200F0084	$pinmux_spi0

# undo sio2 mute for DEMO boad
# if you use IR,set 0x200F00B0 0x0,and modify resistance R273
himm 0x200F00B0 0x01	# muxctrl_reg44(0:IR_IN 1:GPIO6_4)
himm 0x201B0400 0x10	# GPIO6_4
