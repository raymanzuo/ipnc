#!/bin/sh

# mddrc pri&timeout setting
himm 0x20110110  0x03ff7         #USB
himm 0x20110114  0x03ff7         #NANDC
himm 0x20110118  0x03ff6         #DMAC2-mem
himm 0x2011011C  0x03ff6         #SDIO
himm 0x20110120  0x03ff3         #DAMC1-p
himm 0x20110124  0x03ff1         #GMAC
himm 0x20110128  0x03ff3         #PCIE
himm 0x2011012C  0x03ff3         #A9
himm 0x20110130  0x03ff5         #reserve
himm 0x20110134  0x03ff5         #IVE
himm 0x20110138  0x03ff4         #TDE
himm 0x2011013C  0x03ff4         #MDU/JPEG
#himm 0x20110140 0x03ff3         #VENC       old
himm 0x20110140  0x00643         #VENC
#himm 0x20110144 0x10012         #VDP        old
himm 0x20110144  0x10112         #VDP
#himm 0x20110148 0x10011         #VICAP-HIS  old
himm 0x20110148  0x101d1         #VICAP-HIS
#himm 0x2011014C 0x10010         #VICAP      old
himm 0x2011014C  0x101d0         #VICAP

#mddrc order control
himm 0x20110100 0x20077777      #mddrc order enable


#mddrc idmap_mode
himm 0x20110104 0x13210   #mddrc idmap mode select

himm 0x2005007c 0x7             #sysctl vicap vdp order enable, other disable

#outstanding
himm 0x20659004 0x1             #vicap 1
himm 0x20640000 0x40111         #vdp 1, graph first
himm 0x206000a4 0x5             #venc 4  vedu_hal.c line:176 pAllReg->VEDU_OUTSTD.u32 = 0x7;

#vicap intra channel pri
himm 0x20659000  0x514514a     #

#vicap sample disable
himm 0x20641140 0x04010040

#enable fpga pci memory access
himm 0x40100004 0x00100157
himm 0x40210004 0x04000157



